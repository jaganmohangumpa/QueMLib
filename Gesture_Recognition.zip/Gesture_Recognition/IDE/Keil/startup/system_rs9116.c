/**
 * @file       system_rs9116.c
 * @version    0.9
 * @date       20 Dec 2016
 *
 * Copyright(C) Redpine Signals 2016
 * All rights reserved by Redpine Signals.
 *
 * @section License
 * This program should be used on your own responsibility.
 * Redpine Signals assumes no responsibility for any losses
 * incurred by customers or third parties arising from the use of this file.
 *
 * @brief CMSIS Device System Source File for RS9116 device
 *
 * @section Description
 * CMSIS Device System Source File for RS9116 device
 *
 */


/**
 * Includes
 */


#include <stdint.h>
#include "system_rs9116.h"
#include "rsi_error.h"
#include "rsi_reg_spi.h"
#ifdef ROM_WIRELESS
#include "rs9116.h"
#include "rsi_chip.h"
#endif
/*----------------------------------------------------------------------------
  Define clocks
 *----------------------------------------------------------------------------*/

#ifndef SIM_9118
#define __SYSTEM_CLOCK 32000000 // 250Mhz

#else
#define __SYSTEM_CLOCK 80000000 // 250Mhz
#endif 

/*Cortex-m4 FPU registers*/
#define FPU_CPACR           0xE000ED88
#define SCB_MVFR0           0xE000EF40
#define SCB_MVFR0_RESET     0x10110021
#define SCB_MVFR1           0xE000EF44
#define SCB_MVFR1_RESET     0x11000011
/*----------------------------------------------------------------------------
  Clock Variable definitions
 *----------------------------------------------------------------------------*/
uint32_t SystemCoreClock = __SYSTEM_CLOCK;/*!< System Clock Frequency (Core Clock)*/

uint32_t npssIntrState =0;
uint32_t __sp;
uint32_t nvic_enable[8]={0};
#define MAX_NVIC_REGS    4
/*----------------------------------------------------------------------------
  Clock functions
 *----------------------------------------------------------------------------*/

#if   defined ( __CC_ARM ) /*------------------ARM CC Compiler -----------------*/
/*==================================================================================================*/
/**
 * @fn           void RSI_PS_SaveCpuContext(void)
 * @brief        This API is used to save the CPU status register into RAM, this API should be used when sleep with RET is required
 * @param[in]    none
 * @param[out]   none
 * @return       none
 ==================================================================================================*/
__asm void RSI_PS_SaveCpuContext(void)
{
	IMPORT __sp
	PUSH {r0};
	PUSH {r1};
	PUSH {r2};
	PUSH {r3};
	PUSH {r4};
	PUSH {r5};
	PUSH {r6};
	PUSH {r7};
	PUSH {r8};
	PUSH {r9};
	PUSH {r10};
	PUSH {r11};
	PUSH {r12};
	PUSH {r14};
	LDR r0, =__sp;
	MRS r1, msp;
	STR  r1, [r0];
	WFI;
}

/*==================================================================================================*/
/**
 * @fn           void RSI_PS_RestoreCpuContext(void)
 * @brief        This API is used to restore the current CPU processing content from (POP) stack
 * @param[in]    none
 * @param[out]   none
 * @return       none
 ==================================================================================================*/
__asm void RSI_PS_RestoreCpuContext(void)
{
	IMPORT  __sp;
	LDR r0, =__sp;
	LDR sp , [r0 , #0];
	POP {r14};
	POP {r12};
	POP {r11};
	POP {r10};
	POP {r9};
	POP {r8};
	POP {r7};
	POP {r6};
	POP {r5};
	POP {r4};
	POP {r3};
	POP {r2};
	POP {r1};
	POP {r0};
	BX   LR;
}
#endif /*------------------ARM CC Compiler -----------------*/

#if defined ( __GNUC__ ) /*------------------ GNU Compiler ---------------------*/
/*==================================================================================================*/
/**
 * @fn           void RSI_PS_SaveCpuContext(void)
 * @brief        This API is used to save the CPU status register into RAM, this API should be used when sleep with RET is required
 * @param[in]    none
 * @param[out]   none
 * @return       none
 ==================================================================================================*/

void RSI_PS_SaveCpuContext(void)
{
	__asm("push {r0}");
	__asm("push {r1}");
	__asm("push {r2}");
	__asm("push {r3}");
	__asm("push {r4}");
	__asm("push {r5}");
	__asm("push {r6}");
	__asm("push {r7}");
	__asm("push {r8}");
	__asm("push {r9}");
	__asm("push {r10}");
	__asm("push {r11}");
	__asm("push {r12}");
	__asm("push {r14}");

	/*R13 Stack pointer */
	__asm ("mov %0, sp\n\t"
			: "=r" (__sp) );
	__asm("WFI");
}

/*==================================================================================================*/
/**
 * @fn           void RSI_PS_RestoreCpuContext(void)
 * @brief        This API is used to restore the current CPU processing content from (POP) stack
 * @param[in]    none
 * @param[out]   none
 * @return       none
 ==================================================================================================*/

void RSI_PS_RestoreCpuContext(void)
{
	__asm ("ldr r0 , =__sp");
	__asm("ldr sp , [r0 , #0]");
	__asm ("pop {r14}");
	__asm ("pop {r12}");
	__asm ("pop {r11}");
	__asm ("pop {r10}");
	__asm ("pop {r9}");
	__asm ("pop {r8}");
	__asm ("pop {r7}");
	__asm ("pop {r6}");
	__asm ("pop {r5}");
	__asm ("pop {r4}");
	__asm ("pop {r3}");
	__asm ("pop {r2}");
	__asm ("pop {r1}");
	__asm ("pop {r0}");
}
#endif /*------------------ GNU Compiler ---------------------*/

#if defined(__ICCARM__)  /*------------------ IAR Compiler ---------------------*/
//TODO: Check IAR compilation errors
#endif  /*------------------ IAR Compiler ---------------------*/



void SystemCoreClockUpdate (void)            /* Get Core Clock Frequency      */
{
	/*Configure the PLL to 250Mhz*/
	//RSI_CLK_SetSocPllFreq(M4CLK , __SYSTEM_CLOCK);
	/*Update the Generic SystemCoreClock variable*/
	SystemCoreClock = __SYSTEM_CLOCK;
#ifndef FPGA_VALIDATION
	/*If M4 soc wants use reference clocks you need to configure the reference clocks before shifting the soc clock mux */
	RSI_CLK_M4ssRefClkConfig(M4CLK , ULP_32MHZ_RC_CLK);

	/**Change the SOC clock source to PLL i.e  250Mz*/
	RSI_CLK_M4SocClkConfig(M4CLK , M4_ULPREFCLK , 0);
#endif	

	return;
}

#define REG_GSPI_BASE  0x24050000 

#define GSPI_CTRL_REG1 *(volatile uint32_t *)(REG_GSPI_BASE + 0x02)
#define SPI_ACTIVE     BIT(8)

/*Enter deep sleep */
#ifdef ROM_WIRELESS
error_t RSI_PS_EnterDeepSleep(SLEEP_TYPE_T sleepType)
{
	volatile int var = 0;

	/*Save the NVIC registers */
	for (var = 0; var < MAX_NVIC_REGS ; ++var) {
		nvic_enable[var] = NVIC->ISER[var];
	}

	/*store the NPSS interrupt mask clear status*/
	npssIntrState = NPSS_INTR_MASK_CLR_REG;

	/*Update the SCB with Deep sleep BIT */
	SCB->SCR = 0x4;

	/*Clear IPMU BITS*/
	ULP_SPI_MEM_MAP(SELECT_BG_CLK) &= ~LATCH_TOP_SPI;
	
	/*Wait for low*/
	while(GSPI_CTRL_REG1 & SPI_ACTIVE);
	
	/*Enter sleep with retention*/
	if(sleepType == SLEEP_WITH_RETENTION){
		/*If retention mode is enabled save the CPU context*/
		RSI_PS_SaveCpuContext();
	}
	else{
		/*do not save CPU context and go to deep sleep */
		__asm("WFI");
	}

	/*SET IPMU BITS*/
	ULP_SPI_MEM_MAP(SELECT_BG_CLK) |= LATCH_TOP_SPI;

	/*Restore NPSS INTERRUPTS*/
	NPSS_INTR_MASK_CLR_REG = ~npssIntrState;

	/*Restore the ARM NVIC registers */
	for (var = 0; var < MAX_NVIC_REGS; ++var) {
		NVIC->ISER[var] = nvic_enable[var];
	}
	return RSI_OK;
}
#endif
/* Early initialization of the FPU */
void fpuInit(void)
{
#if __FPU_PRESENT != 0
	// from arm trm manual:
	//                ; CPACR is located at address 0xE000ED88
	//                LDR.W R0, =0xE000ED88
	//                ; Read CPACR
	//                LDR R1, [R0]
	//                ; Set bits 20-23 to enable CP10 and CP11 coprocessors
	//                ORR R1, R1, #(0xF << 20)
	//                ; Write back the modified value to the CPACR
	//                STR R1, [R0]

	volatile uint32_t *regCpacr = (uint32_t *) FPU_CPACR;
	volatile uint32_t *regMvfr0 = (uint32_t *) SCB_MVFR0;
	volatile uint32_t *regMvfr1 = (uint32_t *) SCB_MVFR1;
	volatile uint32_t Cpacr;
	volatile uint32_t Mvfr0;
	volatile uint32_t Mvfr1;
	char vfpPresent = 0;

	Mvfr0 = *regMvfr0;
	Mvfr1 = *regMvfr1;

	vfpPresent = ((SCB_MVFR0_RESET == Mvfr0) && (SCB_MVFR1_RESET == Mvfr1));

	if (vfpPresent) {
		Cpacr = *regCpacr;
		Cpacr |= (0xF << 20);
		*regCpacr = Cpacr;	// enable CP10 and CP11 for full access
	}
#endif /* __FPU_PRESENT != 0 */
}
/**
 * Initialize the system
 *
 * @param  none
 * @return none
 *
 * @brief  Setup the RS9116 chip
 *         Initialize the System.
 */

void SystemInit (void)
{
	volatile uint16_t impuDummyRead=0;
	/*Enable FPU*/
	fpuInit();

	/*IPMU dummy read to make IPMU block out of RESET*/
	impuDummyRead = ULP_SPI_MEM_MAP(0x144);

	/*Set IPMU BITS*/
	ULP_SPI_MEM_MAP(SELECT_BG_CLK) |= (LATCH_TOP_SPI | LATCH_TRANSPARENT_HF | LATCH_TRANSPARENT_LF);

	/*Update the system core clock*/
	SystemCoreClockUpdate();

	/*Disable WIC based wake up */
	MCU_FSM->MCU_FSM_PERI_CONFIG_REG_b.WICENREQ = 0;

	/*Set ulp_wakeup_por*/
	MCU_AON->MCUAON_KHZ_CLK_SEL_POR_RESET_STATUS_b.MCU_FIRST_POWERUP_POR = 1;

	/*Update the core clock*/
	SystemCoreClock = __SYSTEM_CLOCK;/*!< System Clock Frequency (Core Clock)*/
	return ;
}
