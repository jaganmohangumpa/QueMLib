#ifndef __PACKING_H_
#define __PACKING_H_

#define PRE_PACK    /* Nothing */
#define POST_PACK   /* Nothing */
#define ALIGNED(n) /* Nothing */

#endif /* __PACKING_H_ */
