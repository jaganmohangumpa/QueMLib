/**
 * @file       rsi_ipmu.c
 * @version    0.9
 * @date       20 Dec 2016
 *
 * Copyright(C) Redpine Signals 2016
 * All rights reserved by Redpine Signals.
 *
 * @par License
 * This program should be used on your own responsibility.
 * Redpine Signals assumes no responsibility for any losses
 * incurred by customers or third parties arising from the use of this file.
 *
 * @brief This files contains functions  related to IPMU  peripheral
 *
 * @par Description
 * This file contains the list of function for the IPMU and low level function definitions
 * Following are list of API's which need to be defined in this file.
 *
 */
/**
 * Includes
 */
#include "rsi_chip.h"
#include "rsi_system_config.h"
efuse_ipmu_t global_ipmu_calib_data;

/**
 * @brief   This function reads, modifies & writes to the iPMU registers based on different PMU SPI register type
 * @param   void
 * @return  void
 */
static void RSI_IPMU_UpdateIpmuData(uint32_t reg_addr, uint32_t reg_type, uint32_t data, uint32_t mask)
{
  uint32_t value = 0;
 
  if (reg_type == ULP_SPI) {
    value = PMU_DIRECT_ACCESS(reg_addr);
  } else if (reg_type == PMU_SPI) {
    value = PMU_SPI_DIRECT_ACCESS(reg_addr);
  } else if (reg_type == DIRECT) {
    value = *(volatile uint32_t *)(reg_addr);
  }
  value &= ~mask;
  value |= data;
  if (reg_type == ULP_SPI) {
    PMU_DIRECT_ACCESS(reg_addr) = value;
  } else if (reg_type == PMU_SPI) {
    PMU_SPI_DIRECT_ACCESS(reg_addr) = value;
  } else if (reg_type == DIRECT) {
    *(volatile uint32_t *)(reg_addr) = value;
  }
}

/**
 * @brief   This function prepares the data from the ipmu calib structure content and writes to each specific register
 * @param   void
 * @return  void
 */
void RSI_IPMU_UpdateIpmuCalibData(efuse_ipmu_t *ipmu_calib_data)
{
  uint32_t data;
  uint32_t mask;
	retention_boot_status_word_t *retention_reg = (retention_boot_status_word_t *)MCURET_BOOTSTATUS;
 
	if(retention_reg->product_mode == MCU){
	//ROW 38
  RSI_IPMU_UpdateIpmuData((NWP_AHB_ADDR + 0x604), DIRECT, (ipmu_calib_data->scale_soc_ldo_vref << 31), MASK_BITS(1, 31));
	}
  //ROW 4,5,6
  data = (ipmu_calib_data->trim_0p5na1 << 18) | (ipmu_calib_data->trim_0p5na2 << 19) | (((ipmu_calib_data->bg_r_vdd_ulp >> 3) & 0x1) << 12) | (ipmu_calib_data->resbank_trim << 10);
  mask = MASK_BITS(1, 18) | MASK_BITS(1, 19) | MASK_BITS(1, 12) | MASK_BITS(2, 10);
  RSI_IPMU_UpdateIpmuData(iPMU_SPARE_REG1_OFFSET, ULP_SPI, data, mask);

  //ROW 5
  data = ((ipmu_calib_data->bg_r_vdd_ulp & 0x7) << 16) | (ipmu_calib_data->bg_r_ptat_vdd_ulp << 19);
  mask = MASK_BITS(3, 16) | MASK_BITS(3, 19);
  RSI_IPMU_UpdateIpmuData(BG_SCDC_PROG_REG_1_OFFSET, ULP_SPI, data, mask);

  //ROW 7,17
  RSI_IPMU_UpdateIpmuData(ULPCLKS_32MRC_CLK_REG_OFFSET, ULP_SPI, (ipmu_calib_data->trim_sel << 14), MASK_BITS(7, 14));

  //ROW 9
  RSI_IPMU_UpdateIpmuData(ULPCLKS_DOUBLER_XTAL_REG_OFFSET, ULP_SPI, (ipmu_calib_data->del_2x_sel << 15), MASK_BITS(6, 15));

  //ROW 10
  RSI_IPMU_UpdateIpmuData(ULPCLKS_32KRO_CLK_REG_OFFSET, ULP_SPI, (ipmu_calib_data->freq_trim << 16), MASK_BITS(5, 16));

  //ROW 11
  if (RC_CLK_MODE == 0) {
    data = (ipmu_calib_data->fine_trim_16k << 14);
  } else if(RC_CLK_MODE == 1) {
    data = (ipmu_calib_data->fine_trim_32k << 14);
  } else if(RC_CLK_MODE == 2) {
    data = (ipmu_calib_data->fine_trim_64k << 14);
  }
  mask = MASK_BITS(7, 14);
  RSI_IPMU_UpdateIpmuData(ULPCLKS_32KRC_CLK_REG_OFFSET, ULP_SPI, data, mask);

  //ROW 12
  if (XTAL_SEL == 1) {
    data = ipmu_calib_data->xtal1_trim_32k << 13;
  } else if (XTAL_SEL == 2) {
    data = ipmu_calib_data->xtal2_trim_32k << 13;
  }
  RSI_IPMU_UpdateIpmuData(ULPCLKS_32KXTAL_CLK_REG_OFFSET, ULP_SPI, data, MASK_BITS(4, 13));

  //ROW 13
  RSI_IPMU_UpdateIpmuData(ULPCLKS_HF_RO_CLK_REG_OFFSET, ULP_SPI, (ipmu_calib_data->trim_ring_osc << 14), MASK_BITS(7, 14));

  //ROW 16
  data = (ipmu_calib_data->f2_nominal);
  mask = MASK_BITS(10, 0);
  RSI_IPMU_UpdateIpmuData((TEMP_SENSOR_BASE_ADDRESS + TS_NOMINAL_SETTINGS_OFFSET), DIRECT, data, mask);

  //ROW 18
  data = *(volatile uint32_t *)(ULP_TASS_MISC_CONFIG_REG + 0x34);
  //! For AUX_LDO register access, need to enable ulp_aux_clock
  *(volatile uint32_t *)(ULP_TASS_MISC_CONFIG_REG + 0x34)  = 0x1;
  RSI_IPMU_UpdateIpmuData((AUX_BASE_ADDR + 0x210), DIRECT, ipmu_calib_data->ldo_ctrl, MASK_BITS(4, 0));
  //! restore the reg
  *(volatile uint32_t *)(ULP_TASS_MISC_CONFIG_REG + 0x34) = data;

  //ROW 34
  data = (ipmu_calib_data->set_vref1p3 << 17);
  mask = MASK_BITS(4, 17);
  RSI_IPMU_UpdateIpmuData(PMU_1P3_CTRL_REG_OFFSET, PMU_SPI, data, mask);

  
  //ROW 38
  data = ipmu_calib_data->trim_r1_resistorladder;
  mask = MASK_BITS(4, 0);
  RSI_IPMU_UpdateIpmuData(SPARE_REG_3_OFFSET, PMU_SPI, data, mask);

  //ROW 48
  data = (ipmu_calib_data->dpwm_freq_trim << 13);
  mask = MASK_BITS(4, 13);
  RSI_IPMU_UpdateIpmuData(PMU_ADC_REG_OFFSET, PMU_SPI, data, mask);
}


/**
 * @brief   This function checks for magic byte in efuse/flash, copies the content if valid data present and calls to update the ipmu registers
 * @param   void
 * @return  void
 */
void RSI_IPMU_InitCalibData(void)
{
  if ((*(uint8_t *)(MANF_DATA_BASE_ADDR )) != MAGIC_WORD) {
    //NO CALIB DATA. Return
    return;
  }

  if ((*(uint32_t *)(MANF_DATA_BASE_ADDR + IPMU_VALUES_OFFSET)) == 0x00) {
    //NO CALIB DATA. Return
    return;
  }
   memcpy((void *)&global_ipmu_calib_data, (void *)(MANF_DATA_BASE_ADDR + IPMU_VALUES_OFFSET), sizeof(efuse_ipmu_t));

  //Dummy read
  PMU_SPI_DIRECT_ACCESS(PMU_PFM_REG_OFFSET);

  RSI_IPMU_UpdateIpmuCalibData(&global_ipmu_calib_data);
		
  //Dummy read
  PMU_SPI_DIRECT_ACCESS(PMU_PFM_REG_OFFSET);
}

/**
 * @fn          void RSI_IPMU_PowerGateSet(uint32_t_t mask_vlaue)
 * @brief	    This API is used to power-up the IPMU peripherals.
 * @param[in]   mask_vlaue   : Ored value of peripheral power gate defines
 *                             Possible values for this parameter are the following
 *                             \n CMP_NPSS_PG_ENB
 *                             \n ULP_ANG_CLKS_PG_ENB
 *                             \n ULP_ANG_PWRSUPPLY_PG_ENB
 *                             \n WURX_PG_ENB
 *                             \n WURX_CORR_PG_ENB
 *                             \n AUXADC_PG_ENB
 *                             \n AUXADC_BYPASS_ISO_GEN
 *                             \n AUXADC_ISOLATION_ENABLE
 *                             \n AUXDAC_PG_ENB
 * @return      none.
 */
void RSI_IPMU_PowerGateSet(uint32_t mask_vlaue)
{
	uint32_t impuPowerGate =0 ;
	impuPowerGate = ULP_SPI_MEM_MAP(POWERGATE_REG_WRITE);
	while(GSPI_CTRL_REG1 & SPI_ACTIVE);
	impuPowerGate = (impuPowerGate >> 5);
	impuPowerGate |= mask_vlaue;
	ULP_SPI_MEM_MAP(POWERGATE_REG_WRITE) = impuPowerGate;
	while(GSPI_CTRL_REG1 & SPI_ACTIVE);
	/*Dummy read*/
	impuPowerGate = ULP_SPI_MEM_MAP(POWERGATE_REG_WRITE);
	return ;
}

/**
 * @fn          void RSI_IPMU_PowerGateClr(uint32_t mask_vlaue)
 * @brief	    This API is used to power-down the IPMU peripherals.
 * @param[in]   mask_vlaue   : Ored value of peripheral power gate defines
 *                             Possible values for this parameter are the following
 *                             \n CMP_NPSS_PG_ENB
 *                             \n ULP_ANG_CLKS_PG_ENB
 *                             \n ULP_ANG_PWRSUPPLY_PG_ENB
 *                             \n WURX_PG_ENB
 *                             \n WURX_CORR_PG_ENB
 *                             \n AUXADC_PG_ENB
 *                             \n AUXADC_BYPASS_ISO_GEN
 *                             \n AUXADC_ISOLATION_ENABLE
 *                             \n AUXDAC_PG_ENB
 * @return      none.
 */
void RSI_IPMU_PowerGateClr(uint32_t mask_vlaue)
{
	uint32_t impuPowerGate =0 ;

	if(mask_vlaue & (WURX_CORR_PG_ENB | WURX_PG_ENB))
	{
		ULP_SPI_MEM_MAP(0x141) &= ~BIT(20);
		ULP_SPI_MEM_MAP(0x141) &= ~BIT(21);
	}

	impuPowerGate = ULP_SPI_MEM_MAP(POWERGATE_REG_WRITE);
	while(GSPI_CTRL_REG1 & SPI_ACTIVE);
	impuPowerGate = (impuPowerGate >> 5);
	impuPowerGate &= ~mask_vlaue;
	ULP_SPI_MEM_MAP(POWERGATE_REG_WRITE) = impuPowerGate;
	while(GSPI_CTRL_REG1 & SPI_ACTIVE);
	return ;
}

/**
 * @fn          void RSI_IPMU_ClockMuxSel(uint8_t bg_pmu_clk)
 * @brief	    This API is used to select clock to the BG-PMU
 * @param[in]   bg_pmu_clk : Selects the clock source to the BG-PMU module
 * 			    \n 1: RO 32KHz clock
 * 			    \n 2: MCU FSM clock
 * @return      none.
 */
void RSI_IPMU_ClockMuxSel(uint8_t bg_pmu_clk)
{
	bg_pmu_clk = (bg_pmu_clk - 1);
	ULP_SPI_MEM_MAP(SELECT_BG_CLK) &= ~(BIT(0) | BIT(1));
	while(GSPI_CTRL_REG1 & SPI_ACTIVE);
	ULP_SPI_MEM_MAP(SELECT_BG_CLK) |= BIT(bg_pmu_clk);
	while(GSPI_CTRL_REG1 & SPI_ACTIVE);
	return ;
}

/**
 * @fn          uint32_t RSI_IPMU_32MHzClkClib(void)
 * @brief	    This API is used to auto calibrate the 32MHz RC clock
 * @return      none.
 */
uint32_t RSI_IPMU_32MHzClkClib(void)
{
	volatile int i ,trim_value=0;
	/*Enables RC 32MHz clock and*/
	ULP_SPI_MEM_MAP(0x104) = (0x3FFFFF & 0x41368000);
	/*Enable XTAL 40MHz clock through NPSS*/
	*(volatile uint32_t *)0x41300120 |= BIT(22);
	i = 1000000;
	while(i--);
	/*Selects NPSS reference clock to be CLK-40M_SOC*/
	ULP_SPI_MEM_MAP(0x106) = (0x3FFFFF & 0x41A48000);
	/*Change spi trim select to 0*/
	ULP_SPI_MEM_MAP(0x107) = (0x3FFFFF & 0x41C04A14);
	/*Pointing clks test out 1 to RC 32M clock*/
	ULP_SPI_MEM_MAP(0x10D) = (0x3FFFFF & 0x43600000);
	/*Pointing clks test out to IPMU_TEST_OUT_0 = SOC[8] in mode 5*/
	ULP_SPI_MEM_MAP(0x143) = (0x3FFFFF & 0x50C00610);
	/*Enable the high frequency clock calibration
	 * Enable the clock gate for npss ref clk 
	 * Select the RC32M clock to calibrate
	 * */
	ULP_SPI_MEM_MAP(0x10A) = (0x3FFFFF & 0x42922290);
	i = 100000;
	while(i--);
	do {
		/*wait for calibration done indication*/
	} while (!(ULP_SPI_MEM_MAP(0x30C)) & BIT(20));
	/*Calibrated trim value*/
	trim_value = ULP_SPI_MEM_MAP(0x30C);
	trim_value = (trim_value >> 11);
	trim_value = (trim_value & 0x7F);
	/*Programming the calibrated trim to SPI register.*/
	ULP_SPI_MEM_MAP(0x104) |= (trim_value << 14);
	/*pointing the trim select to SPI*/
	ULP_SPI_MEM_MAP(0x107) = (0x3FFFFF & 0x41C05A14);
	return trim_value;
}

/**
 * @fn          error_t RSI_IPMU_ProgramConfigData(uint32_t *config)
 * @brief	    This API is used to program the any mcu configuration structure
 * @return      execution status.
 */
error_t RSI_IPMU_ProgramConfigData(uint32_t *config)
{
	volatile uint32_t index = 0 , program_len = 0 ,reg_addr = 0 ;
	volatile uint32_t reg_write_data=0 ,clear_cnt=0,cnt=0 ;
	volatile uint32_t reg_read_data=0 , write_mask=0 , write_bit_pos=0;
	volatile uint8_t  msb=0 , lsb=0 ;

	if(config == NULL){
		return INVALID_PARAMETERS;
	}
	/*Compute the number of entries in the array to program*/
	program_len = config[index];
	if(program_len == 0U){
		return INVALID_PARAMETERS;
	}
	for(index =0 ; index < program_len ; index++){
		reg_addr = config[(2U * index) + 1];
		reg_write_data = config[(2U * (index + 1))];

		lsb = ((reg_write_data >> LSB_POSITION) & POSITION_BITS_MASK);
		msb = ((reg_write_data >> MSB_POSITION) & POSITION_BITS_MASK);

		clear_cnt = (msb - lsb) + 1U;
		/*MSB and LSB position counts validation */
		if (clear_cnt > MAX_BIT_LEN) {
			// Return error
			return INVALID_PARAMETERS;
		}
		/*Read register*/
		reg_read_data = *(volatile uint32_t *)reg_addr;
		cnt = lsb ;
		write_mask = 0;
		write_bit_pos = 0;
		do{
			reg_read_data  &= ~BIT(cnt);
			write_mask     |=  BIT(write_bit_pos);
			cnt++;
			write_bit_pos++;
		}while(cnt < (clear_cnt + lsb));
		reg_write_data &= (write_mask);
		/*Write to the hardware register*/
		reg_write_data  = (reg_read_data | (reg_write_data << lsb));
		*(volatile uint32_t *)reg_addr = reg_write_data;
	}
	return RSI_OK;
}

/**
 * @fn          error_t RSI_IPMU_CommonConfig(void)
 * @brief	    This API is used to program the default system start-up IPMU hardware programming.
 * @return      execution status.
 */
error_t RSI_IPMU_CommonConfig(void)
{
	return RSI_IPMU_ProgramConfigData(ipmu_common_config);
}

/**
 * @fn          error_t RSI_PMU_CommonConfig(void)
 * @brief	    This API is used to program the default system start-up PMU hardware programming.
 * @return      execution status.
 */
error_t RSI_IPMU_PMUCommonConfig(void)
{
	return RSI_IPMU_ProgramConfigData(pmu_common_config);
} 

/**
 * @fn          error_t RSI_IPMU_M20rc_OscTrimEfuse(void)
 * @brief	    This API is used to program the trim value for 32Mhz RC oscillator .
 * @return      execution status.
 */
error_t RSI_IPMU_M32rc_OscTrimEfuse(void)
{
	return RSI_IPMU_ProgramConfigData(m32rc_osc_trim_efuse);
} 


/**
 * @fn          error_t RSI_IPMU_M20rc_OscTrimEfuse(void)
 * @brief	    This API is used to program the trim value for 20Mhz RC oscillator .
 * @return      execution status.
 */
error_t RSI_IPMU_M20rcOsc_TrimEfuse(void)
{
	return RSI_IPMU_ProgramConfigData(m20rc_osc_trim_efuse);
} 

/**
 * @fn          error_t RSI_IPMU_M20rc_OscTrimEfuse(void)
 * @brief	    This API is used to program DBLR 32MHz trim value  .
 * @return      execution status.
 */
error_t RSI_IPMU_DBLR32M_TrimEfuse(void)
{
	return RSI_IPMU_ProgramConfigData(dblr_32m_trim_efuse);
} 

/**
 * @fn          error_t RSI_IPMU_M20rc_OscTrimEfuse(void)
 * @brief	    This API is used to program the trim value for 20Mhz RO oscillator .
 * @return      execution status.
 */
error_t RSI_IPMU_M20roOsc_TrimEfuse(void)
{
	return RSI_IPMU_ProgramConfigData(m20ro_osc_trim_efuse);
} 

/**
 * @fn          error_t RSI_IPMU_RO32khz_TrimEfuse(void)
 * @brief	    This API is used to program the trim value for 32KHz RO oscillator .
 * @return      execution status.
 */
error_t RSI_IPMU_RO32khz_TrimEfuse(void)
{
	return RSI_IPMU_ProgramConfigData(ro_32khz_trim_efuse);
} 

/**
 * @fn          error_t RSI_IPMU_RC16khz_TrimEfuse(void)
 * @brief	    This API is used to program the trim value for 16KHz RC oscillator .
 * @return      execution status.
 */
error_t RSI_IPMU_RC16khz_TrimEfuse(void)
{
	return RSI_IPMU_ProgramConfigData(rc_16khz_trim_efuse);
} 

/**
 * @fn          error_t RSI_IPMU_RC16khz_TrimEfuse(void)
 * @brief	    This API is used to program the trim value for 64KHz RC oscillator .
 * @return      execution status.
 */
error_t RSI_IPMU_RC64khz_TrimEfuse(void)
{
	return RSI_IPMU_ProgramConfigData(rc_64khz_trim_efuse);
} 

/**
 * @fn          error_t RSI_IPMU_RC32khz_TrimEfuse(void)
 * @brief	    This API is used to program the trim value for 32KHz RC oscillator .
 * @return      execution status.
 */
error_t RSI_IPMU_RC32khz_TrimEfuse(void)
{
	return RSI_IPMU_ProgramConfigData(rc_32khz_trim_efuse);
} 

/**
 * @fn          error_t RSI_IPMU_RO_TsEfuse(void)
 * @brief	    This API is used to program the RO Ts slope .
 * @return      execution status.
 */
error_t RSI_IPMU_RO_TsEfuse(void)
{
	return RSI_IPMU_ProgramConfigData(ro_ts_efuse);
} 


/**
 * @fn          error_t RSI_IPMU_Vbattstatus_TrimEfuse(void)
 * @brief	    This API is used to program the trim value for Vbatt status .
 * @return      execution status.
 */
error_t RSI_IPMU_Vbattstatus_TrimEfuse(void)
{
	return RSI_IPMU_ProgramConfigData(vbatt_status_trim_efuse);
} 


/**
 * @fn          error_t RSI_IPMU_Vbg_Tsbjt_Efuse(void)
 * @brief	    This API is used to program The slope value for BJT temperature sensor  .
 * @return      execution status.
 */
error_t RSI_IPMU_Vbg_Tsbjt_Efuse(void)
{
	return RSI_IPMU_ProgramConfigData(vbg_tsbjt_efuse);
} 

/**
 * @fn          error_t RSI_IPMU_Auxadcoff_DiffEfuse(void)
 * @brief	    This API is used to program The offset value for AUX ADC differential mode .
 * @return      execution status.
 */
error_t RSI_IPMU_Auxadcoff_DiffEfuse(void)
{
	return RSI_IPMU_ProgramConfigData(auxadc_off_diff_efuse);
} 


/**
 * @fn          error_t RSI_IPMU_Auxadcgain_DiffEfuse(void)
 * @brief	    This API is used to program The gain value for AUX ADC differential mode   .
 * @return      execution status.
 */
error_t RSI_IPMU_Auxadcgain_DiffEfuse(void)
{
	return RSI_IPMU_ProgramConfigData(auxadc_gain_diff_efuse);
} 

/**
 * @fn          error_t RSI_IPMU_Auxadcgain_DiffEfuse(void)
 * @brief	    This API is used to program The offset value for AUX ADC single mode    .
 * @return      execution status.
 */
error_t RSI_IPMU_Auxadcoff_SeEfuse(void)
{
	return RSI_IPMU_ProgramConfigData(auxadc_off_se_efuse);
} 

/**
 * @fn          error_t RSI_IPMU_Auxadcgain_SeEfuse(void)
 * @brief	    This API is used to program The gain value for AUX ADC single mode    .
 * @return      execution status.
 */
error_t RSI_IPMU_Auxadcgain_SeEfuse(void)
{
	return RSI_IPMU_ProgramConfigData(auxadc_gain_se_efuse);
} 


/**
 * @fn          error_t RSI_IPMU_Auxadcgain_SeEfuse(void)
 * @brief	    This API is used to program BG trim value.
 * @return      execution status.
 */
error_t RSI_IPMU_Bg_TrimEfuse(void)
{
	return RSI_IPMU_ProgramConfigData(bg_trim_efuse);
} 

/**
 * @fn          error_t RSI_IPMU_Blackout_TrimEfuse(void)
 * @brief	    This API is used to program	BLACKOUT thresholds .
 * @return      execution status.
 */
error_t RSI_IPMU_Blackout_TrimEfuse(void)
{
	return RSI_IPMU_ProgramConfigData(blackout_trim_efuse);
} 

/**
 * @fn          error_t RSI_IPMU_POCbias_Efuse(void)
 * @brief	    This API is used to program	 .
 * @return      execution status.
 */
error_t RSI_IPMU_POCbias_Efuse(void)
{
	return RSI_IPMU_ProgramConfigData(poc_bias_efuse);
} 

/**
 * @fn          error_t RSI_IPMU_Buck_TrimEfuse(void)
 * @brief	    This API is used to program	BUCK value .
 * @return      execution status.
 */
error_t RSI_IPMU_Buck_TrimEfuse(void)
{
	return RSI_IPMU_ProgramConfigData(buck_trim_efuse);
} 

/**
 * @fn          error_t RSI_IPMU_Ldosoc_TrimEfuse(void)
 * @brief	    This API is used to program	LDO SOC value .
 * @return      execution status.
 */
error_t RSI_IPMU_Ldosoc_TrimEfuse(void)
{
	return RSI_IPMU_ProgramConfigData(ldosoc_trim_efuse);
} 

/**
 * @fn          error_t RSI_IPMU_Dpwmfreq_TrimEfuse(void)
 * @brief	    This API is used to program	DPWM frequency value .
 * @return      execution status.
 */
error_t RSI_IPMU_Dpwmfreq_TrimEfuse(void)
{
	return RSI_IPMU_ProgramConfigData(dpwm_freq_trim_efuse);
} 

/**
 * @fn          error_t RSI_IPMU_Delvbe_Tsbjt_Efuse(void)
 * @brief	    This API is used to program	 .
 * @return      execution status.
 */
error_t RSI_IPMU_Delvbe_Tsbjt_Efuse(void)
{
	return RSI_IPMU_ProgramConfigData(delvbe_tsbjt_efuse);
} 


/**
 * @fn          error_t RSI_IPMU_Xtal1bias_Efuse(void)
 * @brief	    This API is used to program	Xtal1 bias value .
 * @return      execution status.
 */
error_t RSI_IPMU_Xtal1bias_Efuse(void)
{
	return RSI_IPMU_ProgramConfigData(xtal1_bias_efuse);
} 

/**
 * @fn          error_t RSI_IPMU_Xtal2bias_Efuse(void)
 * @brief	    This API is used to program	Xtal2 bias value .
 * @return      execution status.
 */
error_t RSI_IPMU_Xtal2bias_Efuse(void)
{
	return RSI_IPMU_ProgramConfigData(xtal2_bias_efuse);
} 





/**
 * @fn          error_t RSI_IPMU_BOD_ClksCommonconfig1(void)
 * @brief	    This API is used to enable bias currents to BOD.
 * @return      execution status.
 */
error_t RSI_IPMU_BOD_ClksCommonconfig1(void)
{
	return RSI_IPMU_ProgramConfigData(ipmu_bod_clks_common_config1);
}

/**
 * @fn          error_t RSI_IPMU_BOD_ClksCommonconfig2(void)
 * @brief	    This API is used to disable bias currents to BOD.
 * @return      execution status.
 */
error_t RSI_IPMU_BOD_ClksCommonconfig2(void)
{
	return RSI_IPMU_ProgramConfigData(ipmu_bod_clks_common_config2);
}


/**
 * @fn          error_t RSI_IPMU_BOD_Cmphyst(void)
 * @brief	    This API is used to set the comparator hysteresis.
 * @return      execution status.
 */
error_t RSI_IPMU_BOD_Cmphyst(void)
{
	return RSI_IPMU_ProgramConfigData(bod_cmp_hyst);
}


