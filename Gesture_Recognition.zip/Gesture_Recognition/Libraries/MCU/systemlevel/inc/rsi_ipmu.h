/**
 * @file       rsi_ipmu.h
 * @version    0.9
 * @date       20 Dec 2016
 *
 * Copyright(C) Redpine Signals 2016
 * All rights reserved by Redpine Signals.
 *
 * @section License
 * This program should be used on your own responsibility.
 * Redpine Signals assumes no responsibility for any losses
 * incurred by customers or third parties arising from the use of this file.
 *
 * @brief This file contains functions prototypes related to IPMU
 *
 * @section Description
 * This file contains the list of function prototypes for the IPMU and low level function definitions
 * Following are list of API's which need to be defined in this file.
 *
 */


/**
 * Includes
 */
#ifndef __RSI_IPMU_H__
#define __RSI_IPMU_H__

#ifdef __cplusplus
extern "C" {
#endif


#include "RS1xxxx.h"
#include "rsi_error.h"

#define REG_GSPI_BASE  0x24050000

#define MCURET_BOOTSTATUS 0x24048604	

//! This structure contains format for retention_boot_status_word_0
typedef struct retention_boot_status_word_s {
#define  SDIO_USB_WITH_TA           3
#define  SDIO_WITH_TA_USB_WITH_M4   2
#define  SDIO_WITH_M4_USB_WITH_TA   1 
#define  SDIO_USB_WITH_M4           0
  uint32_t m4_present : 1;
  uint32_t m4_flash_present : 1;
  uint32_t m4_flash_pinset : 4;
  uint32_t m4_flash_address_width_valid : 1;
  uint32_t m4_flash_address_width : 2;
  uint32_t select_host_inf_with_m4_valid : 1;
  uint32_t select_host_inf_with_m4 : 2; 
  uint32_t m4_secure_boot_enable : 1;
  uint32_t m4_encrypt_firmware : 1;
  uint32_t host_if_with_ta : 1;
  uint32_t mcu_wdt_hw_timer : 1;
#define NONE_MODE            0
#define NLINK                1 
#define WISECONNECT          2
#define WCPLUS               3
#define MCU                  4
#define WISEMCU              5
#define ACCELARATOR          6
#define WC_SIMULATANEOUS     7 
  uint32_t product_mode : 4;
  uint32_t m4_flash_type : 4;
  uint32_t m4_dual_flash : 1;
  uint32_t m4_csum : 1;
  uint32_t wise_aoc_mode : 1;
  uint32_t wise_aoc_from_m4_rom : 1;
  uint32_t m4_image_format        : 1;
  uint32_t clean_ulp_wakeup       : 1;
#define M4_IMAGE_VALID_IND      BIT(30)
  uint32_t m4_image_valid         : 1;
  uint32_t reserved : 1; /* one bit is reserved for hardware */
} retention_boot_status_word_t;


/*IPMU power gates */
#define CMP_NPSS_PG_ENB		                BIT(16)/*Power gate enable for BOD CORE*/
#define ULP_ANG_CLKS_PG_ENB		            BIT(15)/*Power gate enable for CLKS CORE*/
#define ULP_ANG_PWRSUPPLY_PG_ENB	        BIT(14)/*Power gate enable for BG SPI*/
#define WURX_PG_ENB		                    BIT(13)/*Power gate enable for WURX*/
#define WURX_CORR_PG_ENB	                BIT(12)/*Power gate enable for WURX CORRELATION BLOCK*/
#define AUXADC_PG_ENB		                  BIT(11)/*Power gate enable for AUXADC*/
#define AUXADC_BYPASS_ISO_GEN	            BIT(10)/*power gate bypass for AUXADC*/
#define AUXADC_ISOLATION_ENABLE	          BIT(9) /*power gate isolation for AUXADC*/
#define AUXDAC_PG_ENB		                  BIT(8) /*Power gate enable for AUXDAC*/
#define AUXDAC_BYPASS_ISO_GEN	            BIT(7) /*power gate bypass for AUXDAC*/
#define AUXDAC_ISOLATION_ENABLE		        BIT(6) /*power gate isolation for AUXDAC*/
#define AUX_SUPPLY_ISOLATION_ENABLE	      BIT(5) /*Given to analog peripherals indicating the supply state*/
#define PMU_ANA_BYPASS_PWRGATE_EN_N	      BIT(4) /*To ON or OFF analog blocks in PMU when pwr manager is bypassed*/
#define PMU_SPI_BYPASS_ISO_GEN	          BIT(3) /*Bypass power manager for PMU_SPI*/
#define PMU_SPI_ISOLATION_ENABLE	        BIT(2) /*Bypass isoaltion enable signal for PMU_SPI isoaltion cells*/
#define PMU_BUCK_BYPASS_ISO_GEN	          BIT(1) /*Bypass power  manager for PMU BUCK*/
#define PMU_BUCK_BYPASS_ISOLATION_ENABLE	BIT(0) /*Bypass isoaltion enable signal for PMU_BUCK isoaltion cells*/

/*IPMU configuration defines*/
#define LATCH_TOP_SPI        BIT(4)
#define LATCH_TRANSPARENT_HF BIT(3)
#define LATCH_TRANSPARENT_LF BIT(2)

/*Registers */
#define SELECT_BG_CLK        0x144
#define BG_SCDC_PROG_REG_2   0x128
//#define WURX_CORR_CALIB_REG  0x088
#define POWERGATE_REG_WRITE  0x142
//#define ULPCLKS_REFCLK_REG   0x106
//#define WURX_CORR_CALIB_REG  0x088

#define GSPI_CTRL_REG1                    *(volatile uint32_t *)(REG_GSPI_BASE + 0x02)
#define SPI_ACTIVE     BIT(8)

#define POSITION_BITS_MASK  0x1F
#define LSB_POSITION        22
#define MSB_POSITION        27
#define MAX_BIT_LEN         22

typedef struct efuse_ipmu_s {
  uint32_t trim_0p5na1                  : 1;
  uint32_t trim_0p5na2                  : 1;
  uint32_t bg_r_vdd_ulp                 : 4;
  uint32_t bg_r_ptat_vdd_ulp            : 3;
  uint32_t resbank_trim                 : 2;
  uint32_t trim_sel                     : 7;
  uint32_t del_2x_sel                   : 6;
  uint32_t freq_trim                    : 5;
  uint32_t coarse_trim_16k              : 2;
  uint32_t fine_trim_16k                : 7;
  uint32_t coarse_trim_64k              : 2;
  uint32_t fine_trim_64k                : 7;
  uint32_t coarse_trim_32k              : 2;
  uint32_t fine_trim_32k                : 7;
  uint32_t xtal1_trim_32k               : 4;
  uint32_t xtal2_trim_32k               : 4;
  uint32_t trim_ring_osc                : 7;
  uint32_t vbatt_status_1               : 6;
  uint32_t str_temp_slope               : 10;
  uint32_t f2_nominal                   : 10;
  uint32_t str_nominal_temp             : 7;
  uint32_t str_bjt_temp_sense_off       : 16;
  uint32_t str_bjt_temp_sense_slope     : 16;
  uint32_t reserved1                    : 20;
  uint32_t ldo_ctrl                     : 4;
  uint32_t reserved2                    : 16;
  uint32_t auxadc_offset_diff           : 12;
  uint32_t auxadc_invgain_diff_int      : 2;
  uint32_t auxadc_invgain_diff_frac     : 14;
  uint32_t auxadc_offset_single         : 12;
  uint32_t auxadc_invgain_single_int    : 2;
  uint32_t auxadc_invgain_single_frac   : 14;
  uint32_t set_vref1p3                  : 4;
  uint32_t set_vref_isense1p3           : 2;
  uint32_t set_vref_adc                 : 2;
  uint32_t vtrim_ldosoc                 : 2;
  uint32_t trim_r1_resistorladder       : 4;
  uint32_t enable_undershoot_reduction  : 1;
  uint32_t select_vref_comp             : 2;
  uint32_t pwr_gd_threshold_sel         : 1;
  uint32_t sel_overshoot_control        : 1;
  uint32_t ptat_load_ctrl               : 3;
  uint32_t ctrl_soc                     : 4;
  uint32_t pt_gate_ctrl                 : 3;
  uint32_t default_mode_ctrl            : 1;
  uint32_t ptat_load_enable             : 1;
  uint32_t ldosoc_outputpulldown_sel    : 1;
  uint32_t ldosoc_outputpulldown        : 1;
  uint32_t scale_soc_ldo_vref           : 1;
  uint32_t ctrl_rf                      : 4;
  uint32_t default_mode                 : 1;
  uint32_t test_ldopulldown_sel         : 1;
  uint32_t test_ldopulldown             : 1;
  uint32_t drive_n                      : 2;
  uint32_t drive_p                      : 2;
  uint32_t deadtime_ctrl_n2p            : 4;
  uint32_t deadtime_ctrl_p2n            : 4;
  uint32_t revi_offset_prog             : 3;
  uint32_t tran_lo_ctr                  : 2;
  uint32_t tran_hi_ctr                  : 2;
  uint32_t tran_und_shoot_ctr           : 3;
  uint32_t dpwm_freq_trim               : 4;
  uint32_t pfmro_freq_trim              : 3;
  uint32_t test_revi_delay              : 1;
  uint32_t sel_sleep_nmos_ctrl          : 1;
  uint32_t p_1p3                        : 13;
  uint32_t i_steady_state1p3            : 13;
  uint32_t d_1p3                        : 15;
  uint32_t i_soft_start1p3              : 13;
  uint32_t dither_en1p3                 : 1;
  uint32_t auto_mode_tran_disable       : 1;
  uint32_t pfm_pon_time_sel             : 4;
  uint32_t pfm_non_time_sel             : 3;
  uint32_t pwm_cont_prog                : 3;
  uint32_t pfm_clk_up_del_sel           : 3;
  uint32_t pwm_to_pfm_pulse_count_prog  : 2;
  uint32_t pfm_to_pwm_pulse_count_prog  : 2;
  uint32_t pfm_to_pwm_cur_prog          : 3;
  uint32_t pwm_to_pfm_cur_prog          : 3;
  uint32_t max_duty_cycle_threshold     : 3;
  uint32_t min_duty_cycle_threshold     : 3;
  uint32_t bypass_pfm_to_pwm_counter_1  : 1;
  uint32_t no_of_pfm_clk                : 4;
  uint32_t adc_op_thresh_sel            : 2;
  uint32_t reserved3                    : 4;
  uint32_t reserved4[2];
	uint16_t reserved5;
}__attribute__((__packed__)) efuse_ipmu_t;


extern efuse_ipmu_t global_ipmu_calib_data;
extern efuse_ipmu_t *global_ipmu_calib_data_p;

#define MAX_RESP_BUF_FOR_IAP                  3
#define MANF_DATA_BASE_ADDR                   0x04000000
#define BASE_OFFSET_BB_RF_IN_FLASH            424


#define PMU_SPI_BASE_ADDR                     0x24050000

//! PMU 
#define PMU_SPI_DIRECT_ACCESS(_x)             *(volatile uint32_t *)(PMU_SPI_BASE_ADDR + 0x8000 + ((_x) << 2))
//! IPMU
#define PMU_DIRECT_ACCESS(_x)                 *(volatile uint32_t *)(PMU_SPI_BASE_ADDR + 0xA000 + ((_x) << 2))
#define PMU_SPI                               1

#define RC_CLK_MODE                           1

#define XTAL_SEL                              1



#define TS_SLOPE_SET_OFFSET                   0x04

#define PMU_PID_REG1_OFFSET                   0x1D3

#define PMU_PTAT_REG_OFFSET                   0x1D5

#define PMU_LDO_REG_OFFSET                    0x1D6
#define PMU_PWRTRAIN_REG_OFFSET               0x1D8
#define SPARE_REG_2_OFFSET                    0x1DD
#define SPARE_REG_1_OFFSET                    0x1DC 
#define PMU_TEST_MODES_OFFSET                 0x1DA
#define PMU_PFM_REG_OFFSET                    0x1D1
#define PMU_TESTMUX_REG1_OFFSET               0x1D9





//FLASH OFFSET
#define __CALIB_DATA_OFFSET_                  1024
#define IPMU_VALUES_OFFSET                    (__CALIB_DATA_OFFSET_ + 168)



/* After changes */
#define MAGIC_WORD                            0x5a

#define PMU_ADC_REG_OFFSET                    0x1D2
#define SPARE_REG_3_OFFSET                    0x1DF
#define NWP_AHB_ADDR              	          0x41300000
#define PMU_1P3_CTRL_REG_OFFSET               0x1D0
#define ULP_TASS_MISC_CONFIG_REG              0x24041400
#define AUX_BASE_ADDR                         0x24043800
#define TEMP_SENSOR_BASE_ADDRESS              0x24048500
#define TS_NOMINAL_SETTINGS_OFFSET            0x08
#define DIRECT                                2
#define ULPCLKS_HF_RO_CLK_REG_OFFSET          0x105
#define MASK_BITS(A, B) (((1U << A) - 1) << B)
#define ULP_SPI                               0
#define ULPCLKS_32KXTAL_CLK_REG_OFFSET        0x10E
#define ULPCLKS_32KRC_CLK_REG_OFFSET          0x103
#define ULPCLKS_32KRO_CLK_REG_OFFSET          0x102
#define ULPCLKS_DOUBLER_XTAL_REG_OFFSET       0x101
#define ULPCLKS_32MRC_CLK_REG_OFFSET          0x104
#define BG_SCDC_PROG_REG_1_OFFSET             0x127
#define iPMU_SPARE_REG1_OFFSET                0x140	


/**
 * \ingroup   RSI_SPECIFIC_DRIVERS
 * \defgroup  RSI_IPMU_DRIVERS RSI:RS1xxxx IPMU 
 *  @{
 *
 */
 error_t RSI_IPMU_Xtal2bias_Efuse(void) ;
 error_t RSI_IPMU_Xtal1bias_Efuse(void) ;
 error_t RSI_IPMU_Delvbe_Tsbjt_Efuse(void) ;
 error_t RSI_IPMU_Dpwmfreq_TrimEfuse(void) ;
 error_t RSI_IPMU_Ldosoc_TrimEfuse(void) ;
 error_t RSI_IPMU_Buck_TrimEfuse(void) ;
 error_t RSI_IPMU_POCbias_Efuse(void) ;
error_t RSI_IPMU_Blackout_TrimEfuse(void) ;
error_t RSI_IPMU_Bg_TrimEfuse(void) ;
error_t RSI_IPMU_Auxadcgain_SeEfuse(void) ;
error_t RSI_IPMU_Auxadcoff_SeEfuse(void) ;
error_t RSI_IPMU_Auxadcoff_DiffEfuse(void) ;
error_t RSI_IPMU_Auxadcgain_DiffEfuse(void);
error_t RSI_IPMU_Vbg_Tsbjt_Efuse(void) ;
error_t RSI_IPMU_RO_TsEfuse(void) ;
error_t RSI_IPMU_Vbattstatus_TrimEfuse(void) ;
error_t RSI_IPMU_RC32khz_TrimEfuse(void) ;
error_t RSI_IPMU_RC64khz_TrimEfuse(void) ;
error_t RSI_IPMU_RC16khz_TrimEfuse(void) ;
error_t RSI_IPMU_RO32khz_TrimEfuse(void) ;
error_t RSI_IPMU_M20roOsc_TrimEfuse(void) ;
error_t RSI_IPMU_DBLR32M_TrimEfuse(void) ;
error_t RSI_IPMU_M20rcOsc_TrimEfuse(void) ;
error_t RSI_IPMU_PMUCommonConfig(void) ;
error_t RSI_IPMU_M32rc_OscTrimEfuse(void) ;
void RSI_IPMU_PowerGateSet(uint32_t mask_vlaue);
void RSI_IPMU_PowerGateClr(uint32_t mask_vlaue);
error_t RSI_IPMU_CommonConfig(void);
void RSI_IPMU_ClockMuxSel(uint8_t bg_pmu_clk);
uint32_t RSI_IPMU_32MHzClkClib(void);
error_t RSI_IPMU_ProgramConfigData(uint32_t *config);
void RSI_IPMU_InitCalibData(void);
void RSI_IPMU_UpdateIpmuCalibData(efuse_ipmu_t *ipmu_calib_data);

/**
 * @} end of RSI_IPMU_DRIVERS 
 */
/* @} end of RSI_IPMU_DRIVERS  */

#ifdef __cplusplus
}
#endif
#endif // RSI_PLL_H
 

