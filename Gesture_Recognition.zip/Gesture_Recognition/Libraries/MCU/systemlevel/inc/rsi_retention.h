/**
 * @file       rsi_retention.h
 * @version    0.1
 * @date       4 Apr 2016
 *
 * Copyright(C) Redpine Signals 2016
 * All rights reserved by Redpine Signals.
 *
 * @section License
 * This program should be used on your own responsibility.
 * Redpine Signals assumes no responsibility for any losses
 * incurred by customers or third parties arising from the use of this file.
 *
 * @brief This files contains functions prototypes related to retention in NPSS
 *
 * @section Description
 * This file contains the list of function prototypes for the retention in NPSS
 * Following are list of API's which need to be defined in this file.
 *
 */


/**
 * Includes
 */

#ifndef  __RSI_RETENTION_H__
#define  __RSI_RETENTION_H__
#include "RS1xxxx.h"

#ifdef __cplusplus
extern "C" {
#endif

/*NPSS GPIO PIN MUX VALEUS*/
#define NPSS_GPIO_STATUS                    (*(volatile uint32_t *)( NPSS_INTR_BASE + 0x14))
#define NPSS_GPIO_CONFIG_REG                (*(volatile uint32_t *)( NPSS_INTR_BASE + 0x10))

/*NPSS GPIO PIN MUX VALEUS*/
#define NPSSGPIO_PIN_MUX_MODE0              0
#define NPSSGPIO_PIN_MUX_MODE1              1
#define NPSSGPIO_PIN_MUX_MODE2              2
#define NPSSGPIO_PIN_MUX_MODE3              3
#define NPSSGPIO_PIN_MUX_MODE4              4
#define NPSSGPIO_PIN_MUX_MODE5              5
#define NPSSGPIO_PIN_MUX_MODE6              6
#define NPSSGPIO_PIN_MUX_MODE7              7
/*@note : Please refer to pin MUX excel to configure in desired mode
 * */
/*EDGE INTERRUPT MODE */
#define RISING_EDGE                         0
#define FALLING_EDGE                        1
#define BOTH_FALL_RISE_EDGE                 3

/*NPSS GPIO pin interrupt edge configuration */
#define NPSS_INTR_RISING_EDGE               1
#define NPSS_INTR_FALLING_EDGE              0

/*NPSS GPIO pin direction */
#define NPSS_GPIO_DIR_INPUT                 1
#define NPSS_GPIO_DIR_OUTPUT                0

/*NPSS GPIO pin interrupt levels*/
#define NPSS_GPIO_INTR_HIGH                 1
#define NPSS_GPIO_INTR_LOW                  0

/*NPSS GPIO pin defines */
#define NPSS_GPIO_0                         0
#define NPSS_GPIO_1                         1
#define NPSS_GPIO_2                         2
#define NPSS_GPIO_3                         3
#define NPSS_GPIO_4                         4

/*NPSS GPIO Interrupt defines */
#define NPSS_GPIO_0_INTR                    BIT(0)
#define NPSS_GPIO_1_INTR                    BIT(1)
#define NPSS_GPIO_2_INTR                    BIT(2)
#define NPSS_GPIO_3_INTR                    BIT(3)
#define NPSS_GPIO_4_INTR                    BIT(4)

/**
 * \ingroup   RSI_SPECIFIC_DRIVERS
 * \defgroup RSI_NPSSGPIO RSI:RS1xxxx NPSSGPIO 
 *  @{
 *
 */

/**
* @brief         This API is used to set the NPSS GPIO pin MUX (mode)
 *@param[in]  pin: is NPSS GPIO pin number (0...4)
 *@param[in]  mux : is NPSS GPIO  MUX value
 *@return  : none
 * */
STATIC INLINE void RSI_NPSSGPIO_SetPinMux(uint8_t pin, uint8_t mux)
{
	MCU_RET->NPSS_GPIO_CNTRL[pin].NPSS_GPIO_CTRLS_b.NPSS_GPIO_MODE = mux;
}

/**
 * @fn         void RSI_NPSSGPIO_InputBufferEn(uint8_t pin , boolean_t enable)
* @brief        This API is used to enable/disable NPSS GPIO input buffer
 *@param[in] pin: is NPSS GPIO pin number (0...4)
 *@param[in]  enable: is enable / disable NPSS GPIO input buffer
 *           1- Enable
 *           0- Disable
 *@return  : none
 * */
STATIC INLINE void RSI_NPSSGPIO_InputBufferEn(uint8_t pin , boolean_t enable)
{
	MCU_RET->NPSS_GPIO_CNTRL[pin].NPSS_GPIO_CTRLS_b.NPSS_GPIO_REN = enable;
}

/**
 * @brief    This API is used to set the direction of the NPSS GPIO
 *@param[in]  pin: is NPSS GPIO pin number (0...4)
 *@param[in]  dir: is direction value (Input / Output)
 *           1- Input Direction
 *           0- Output Direction
 *@return  : none
 * */
STATIC INLINE void RSI_NPSSGPIO_SetDir(uint8_t pin, boolean_t dir)
{
	MCU_RET->NPSS_GPIO_CNTRL[pin].NPSS_GPIO_CTRLS_b.NPSS_GPIO_OEN = dir;
}

/**
 * @brief    This API is used to Get the direction of the NPSS GPIO
 *@param[in]  pin: is NPSS GPIO pin number (0...4)
 * @return  : returns the GPIO pin direction
 * */
STATIC INLINE boolean_t RSI_NPSSGPIO_GetDir(uint8_t pin)
{
	return MCU_RET->NPSS_GPIO_CNTRL[pin].NPSS_GPIO_CTRLS_b.NPSS_GPIO_OEN;
}

/**
 * @brief         This API is used to set the NPSS GPIO pin value
 *@param[in]  pin: is NPSS GPIO pin number (0...4)
 *@param[in]  val: is NPSS GPIO pin value 0 or 1
 * @return    none
 */
STATIC INLINE void RSI_NPSSGPIO_SetPin(uint8_t pin, boolean_t val)
{
	MCU_RET->NPSS_GPIO_CNTRL[pin].NPSS_GPIO_CTRLS_b.NPSS_GPIO_OUT = val;
}

/**
 * @brief         This API is used to Get the NPSS GPIO pin value
 *@param[in]  pin: is NPSS GPIO pin number (0...4)
 * @return    returns the pin logical state of pin
 */
STATIC INLINE boolean_t RSI_NPSSGPIO_GetPin(uint8_t pin)
{
	return (NPSS_GPIO_STATUS >> pin) & 0x01 ;
}

/**
* @brief        This API is used to select  NPSS GPIO wake up detection when in sleep
 *@param[in] pin: is NPSS GPIO pin number (0...4)
 *@param[in] level :Gpio polarity to wake up from sleep
 *           1 - When signal is High
 *           0 - When signal is Low
 *@return  : none
 * */
STATIC INLINE void RSI_NPSSGPIO_SetPolarity(uint8_t pin , boolean_t level)
{
	MCU_RET->NPSS_GPIO_CNTRL[pin].NPSS_GPIO_CTRLS_b.NPSS_GPIO_POLARITY = level;
}

/**
 * @brief         This API is used to set the GPIO to wake from deep sleep
 * @param[in]   npssGpioPinIntr: OR'ed values of the NPSS GPIO interrupts
 * @return    none
 */
STATIC INLINE void RSI_NPSSGPIO_SetWkpGpio(uint8_t npssGpioPinIntr)
{
	MCU_FSM->GPIO_WAKEUP_REGISTER |= npssGpioPinIntr;
}

/**
 * @brief         This API is used to clear the GPIO to wake from deep sleep
 * @param[in]   npssGpioPinIntr: OR'ed values of the NPSS GPIO interrupts
 * @return    none
 */
STATIC INLINE void RSI_NPSSGPIO_ClrWkpGpio(uint8_t npssGpioPinIntr)
{
	MCU_FSM->GPIO_WAKEUP_REGISTER &= ~npssGpioPinIntr;
}

/**
 * @brief         This API is used to mask the NPSS GPIO interrupt
 * @param[in]   npssGpioPinIntr: OR'ed values of the NPSS GPIO interrupts
 * @return    none
 */
STATIC INLINE void RSI_NPSSGPIO_IntrMask(uint8_t npssGpioPinIntr)
{
	NPSS_INTR_MASK_SET_REG = (npssGpioPinIntr << 1);
}

/**
 * @brief         This API is used to un mask the NPSS GPIO interrupt
 * @param[in]   npssGpioPinIntr: OR'ed values of the NPSS GPIO interrupts
 * @return    none
 */
STATIC INLINE void RSI_NPSSGPIO_IntrUnMask(uint8_t npssGpioPinIntr)
{
	NPSS_INTR_MASK_CLR_REG = (npssGpioPinIntr << 1);
}

/**
 * @brief         This API is used to un mask the NPSS GPIO interrupt
 * @param[in]   npssGpioPinIntr: OR'ed values of the NPSS GPIO interrupts
 * @return    none
 */
STATIC INLINE void RSI_NPSSGPIO_SetIntFallEdgeEnable(uint8_t npssGpioPinIntr)
{
	NPSS_GPIO_CONFIG_REG |= (npssGpioPinIntr << 8);
}

/**
 * @brief         This API is used to un mask the NPSS GPIO interrupt
 * @param[in]   npssGpioPinIntr: OR'ed values of the NPSS GPIO interrupts
 * @return    none
 */
STATIC INLINE void RSI_NPSSGPIO_ClrIntFallEdgeEnable(uint8_t npssGpioPinIntr)
{
	NPSS_GPIO_CONFIG_REG &= ~(npssGpioPinIntr << 8);
}

/**
 * @brief         This API is used to Set the rise edge interrupt detection for NPSS GPIO
 * @param[in]   npssGpioPinIntr: OR'ed values of the NPSS GPIO interrupts
 * @return    none
 */
STATIC INLINE void RSI_NPSSGPIO_SetIntRiseEdgeEnable(uint8_t npssGpioPinIntr)
{
	NPSS_GPIO_CONFIG_REG |= (npssGpioPinIntr << 0);
}

/**
 * @brief         This API is used to  Enable rise edge interrupt detection for NPSS GPIO
 * @param[in]   npssGpioPinIntr: OR'ed values of the NPSS GPIO interrupts
 * @return    none
 */
STATIC INLINE void RSI_NPSSGPIO_ClrIntRiseEdgeEnable(uint8_t npssGpioPinIntr)
{
	NPSS_GPIO_CONFIG_REG &= ~(npssGpioPinIntr << 0);
}

/**
 * @brief     This API is used to un mask the NPSS GPIO interrupt
 * @param[in]   npssGpioPinIntr: OR'ed values of the NPSS GPIO interrupts
 * @return    none
 */
STATIC INLINE void RSI_NPSSGPIO_SetIntLevelHighEnable(uint8_t npssGpioPinIntr)
{
	NPSS_GPIO_CONFIG_REG |= (npssGpioPinIntr << 24);
}

/**
 * @brief         This API is used to un mask the NPSS GPIO interrupt
 * @param[in]   npssGpioPinIntr: OR'ed values of the NPSS GPIO interrupts
 * @return    none
 */
STATIC INLINE void RSI_NPSSGPIO_ClrIntLevelHighEnable(uint8_t npssGpioPinIntr)
{
	NPSS_GPIO_CONFIG_REG &= ~(npssGpioPinIntr << 24);
}

/**
 * @brief         This API is used to un mask the NPSS GPIO interrupt
 * @param[in]   npssGpioPinIntr: OR'ed values of the NPSS GPIO interrupts
 * @return    none
 */
STATIC INLINE void RSI_NPSSGPIO_SetIntLevelLowEnable(uint8_t npssGpioPinIntr)
{
	NPSS_GPIO_CONFIG_REG |= (npssGpioPinIntr << 16);
}

/**
 * @brief         This API is used clear the interrupt low level enable
 * @param[in]   npssGpioPinIntr: OR'ed values of the NPSS GPIO interrupts
 * @return    none
 */
STATIC INLINE void RSI_NPSSGPIO_ClrIntLevelLowEnable(uint8_t npssGpioPinIntr)
{
	NPSS_GPIO_CONFIG_REG &= ~(npssGpioPinIntr << 16);
}

/**
 * @brief         This API is used to clear NPSS GPIO interrupt
 * @param[in]   npssGpioPinIntr: OR'ed values of the NPSS GPIO interrupts
 * @return    none
 */
STATIC INLINE void RSI_NPSSGPIO_ClrIntr(uint8_t npssGpioPinIntr)
{
	NPSS_INTR_CLEAR_REG = (npssGpioPinIntr << 1);
}

/**
 * @brief         This API is used to get the NPSS GPIO interrupt status
 * @return    returns the GPIO status
 */
STATIC INLINE uint8_t RSI_NPSSGPIO_GetIntrStatus(void)
{
	return (NPSS_INTR_STATUS_REG >> 1) & 0x1F;
}
/*
 *@}
 */

#ifdef __cplusplus
}
#endif

/*End of file not truncated*/
#endif /*__RSI_RETENTION_H__*/
