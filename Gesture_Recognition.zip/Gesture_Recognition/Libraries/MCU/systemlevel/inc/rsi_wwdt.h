/**
 * @file       rsi_wwdt.h
 * @version    0.1
 * @date       20 jan 2016
 *
 * Copyright(C) Redpine Signals 2016
 * All rights reserved by Redpine Signals.
 *
 * @section License
 * This program should be used on your own responsibility.
 * Redpine Signals assumes no responsibility for any losses
 * incurred by customers or third parties arising from the use of this file.
 *
 * @brief This files contains
 *
 * @section Description
 *
 */


/**
 * Includes
 */
#ifndef __RSI_WDT_H__
#define __RSI_WDT_H__

#ifdef __cplusplus
extern "C" {
#endif


#include "RS1xxxx.h"

/**
 * \ingroup   RSI_SPECIFIC_DRIVERS
 * \defgroup RSI_WWDT RSI:RSIxxxx WWDT 
 *  @{
 *
 */ 
/** 
 * @brief        This API is used to initialize the Watch dog timer
 * @param[in]    pstcWDT : pointer to the WDT register instance
 * @return       None
 */
STATIC INLINE void RSI_WWDT_Init(MCU_WDT_t *pstcWDT)
{
	MCU_FSM->MCU_FSM_CRTL_PDM_AND_ENABLES_b.ENABLE_WDT_IN_SLEEP_b = 1;
}

/**
 * @brief     	This API is used to configure the interrupt timer of the watch dog timer
 * @param[in]  	  pstcWDT 	 			 : pointer to the WDT register instance
 * @param[in]  	  u16IntrTimerVal  : interrupt timer value
 * @return			None
 */
STATIC INLINE void RSI_WWDT_ConfigIntrTimer(MCU_WDT_t *pstcWDT , uint16_t u16IntrTimerVal)
{
	pstcWDT->MCU_WWD_INTERRUPT_TIMER_b.WWD_INTERRUPT_TIMER = u16IntrTimerVal;
}

/**
 * @brief   	 	This API is used to configure the system reset timer of the watch dog timer
 * @param[in]	  pstcWDT 			  : pointer to the WDT register instance
 * @param[in] 	  u16SysRstVal 		: reset value
 * @return			NONE
 */
STATIC INLINE void RSI_WWDT_ConfigSysRstTimer(MCU_WDT_t *pstcWDT , uint16_t u16SysRstVal)
{
	pstcWDT->MCU_WWD_SYSTEM_RESET_TIMER_b.WWD_SYSTEM_RESET_TIMER = u16SysRstVal;
}

/**
 * @brief   	 	This API is used to Disable the Watch dog timer
 * @param[in] 	 	pstcWDT  	:pointer to the WDT register instance
 * @return		 	None
 */
STATIC INLINE void RSI_WWDT_Disable(MCU_WDT_t *pstcWDT)
{
	/*0xF0 to Disable the watch dog */
	pstcWDT->MCU_WWD_MODE_AND_RSTART_b.WWD_MODE_EN_STATUS = 0xF0;
}

/**
 * @brief   		 This API is used to restart the Watch dog timer
 * @param[in]		 pstcWDT  :pointer to the WDT register instance
 * @return 			 None
 */
STATIC INLINE void RSI_WWDT_ReStart(MCU_WDT_t *pstcWDT)
{
	pstcWDT->MCU_WWD_MODE_AND_RSTART_b.WWD_MODE_RSTART =1U;
}

/**
 * @brief      This API is used to unmask the Watch dog timer
 * @return     None
 */
STATIC INLINE void RSI_WWDT_IntrUnMask(void)
{
	NPSS_INTR_MASK_CLR_REG = NPSS_TO_MCU_WDT_INTR;
}

/**
 * @brief   		 This API is used to mask the Watch dog timer
 * @return		   None
 */
STATIC INLINE void RSI_WWDT_IntrMask(void)
{
	NPSS_INTR_MASK_SET_REG = NPSS_TO_MCU_WDT_INTR;
}

/**
 * @fn        void RSI_WWDT_IntrClear(void)
 * @brief    This API is used to set the time out value of the Watch dog timer
 */
void RSI_WWDT_IntrClear(void);

/**
 * @fn        uint8_t RSI_WWDT_GetIntrStatus(void); 
 * @brief    This API is used to set the time out value of the Watch dog timer
 */
uint8_t RSI_WWDT_GetIntrStatus(void);

/**
 * @brief    This API is used to de-initialize the Watch dog timer
 *@param[in] pstcWDT is pointer to the WDT register instance
 * */
void RSI_WWDT_DeInit(MCU_WDT_t *pstcWDT);


/**
 * @brief    This API is used to start the Watch dog timer
 *@param[in] pstcWDT is pointer to the WDT register instance
 * */
void RSI_WWDT_Start(MCU_WDT_t *pstcWDT);

#ifdef __cplusplus
}
#endif


/*End of file not truncated*/
#endif /*__RSI_WDT_H__*/


/* @} end of RSI_WWDT */
