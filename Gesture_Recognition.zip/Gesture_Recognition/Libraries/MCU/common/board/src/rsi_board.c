 /**
 * @file       rsi_board.c
 * @version    1.0
 * @date       1 AUG 2017
 * @brief This files contains function defination related to board
 *
 * @section Description
 * This file contains the list of function defination for the board.
 *
 */

#include "rsi_chip.h"
#include "rsi_board.h"
#include "USART.h"
#include "RTE_Device.h"
#include <stdio.h>

#define ULP_UART_INSTANCE 0U
#define M4_UART_INSTANCE  1U
 
#define SELECT_UART_INSTANCE    M4_UART_INSTANCE //!keep ULP_UART_INSTANCE : 0 in case of ULPSS uart , M4_UART_INSTANCE :1 in case of M4 UART


#define   BOARD_BAUD_VALUE   115200 //UART baud rate
void ARM_UART_SignalEvent(uint32_t event);
/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/
typedef struct {
	uint8_t port;
	uint8_t pin;
} PORT_PIN_T;

static const PORT_PIN_T ledBits[] = {{0, 0}, {0, 2}, {0, 12}};
static const uint32_t ledBitsCnt = sizeof(ledBits) / sizeof(PORT_PIN_T);

#if SELECT_UART_INSTANCE
extern ARM_DRIVER_USART Driver_USART0;
static ARM_DRIVER_USART * USARTdrv   = &Driver_USART0;
#else
extern ARM_DRIVER_USART Driver_ULP_UART;
static ARM_DRIVER_USART * USARTdrv   = &Driver_ULP_UART;
#endif

ARM_USART_CAPABILITIES drv_ulp_capabilities;

volatile uint32_t send_done=0,recv_done=0;

void ARM_UART_SignalEvent(uint32_t event)
{
	switch(event)
	{
	case ARM_USART_EVENT_SEND_COMPLETE:
		//read_tx_cnt=USARTdrv->GetTxCount();
		send_done++;
		break;
	case ARM_USART_EVENT_RECEIVE_COMPLETE:
		recv_done++;
		//read_rx_cnt=USARTdrv->GetRxCount();
		break;
	case ARM_USART_EVENT_TRANSFER_COMPLETE:
		break;
	case ARM_USART_EVENT_TX_COMPLETE:
		break;
	case ARM_USART_EVENT_TX_UNDERFLOW:
		break;
	case ARM_USART_EVENT_RX_OVERFLOW:
		break;
	case ARM_USART_EVENT_RX_TIMEOUT:
		break;
	case ARM_USART_EVENT_RX_BREAK:
		break;
	case ARM_USART_EVENT_RX_FRAMING_ERROR:
		break;
	case ARM_USART_EVENT_RX_PARITY_ERROR:
		break;
	case ARM_USART_EVENT_CTS:
		break;
	case ARM_USART_EVENT_DSR:
		break;
	case ARM_USART_EVENT_DCD:
		break;
	case ARM_USART_EVENT_RI:
		break;
	}
}

/**
 * @fn         void Board_Debug_Init(void)
 * @brief      Initializes board UART for output, required for printf redirection.
 * @return     none
 */
void Board_Debug_Init(void)
{
	/*clock bypass to avoid clock gating*/
 	RSI_CLK_SocPllLockConfig(1,1,0xA4);
 
 	RSI_CLK_M4SocClkConfig(M4CLK,M4_ULPREFCLK,0);
	
	#if SELECT_UART_INSTANCE
	RSI_CLK_SetSocPllFreq(M4CLK,RTE_USART0_BASECLK,40000000);
	#else
	RSI_CLK_SetSocPllFreq(M4CLK,RTE_ULP_UART_BASECLK,40000000);
	#endif
	
	RSI_CLK_M4SocClkConfig(M4CLK,M4_SOCPLLCLK,0);
	
	RSI_ULPSS_ClockConfig(M4CLK,1,0,0);
	
	USARTdrv->Initialize   (ARM_UART_SignalEvent);

	USARTdrv->PowerControl (ARM_POWER_FULL);

	/* Enable Receiver and Transmitter lines */
	USARTdrv->Control (ARM_USART_CONTROL_TX, 1);

	USARTdrv->Control (ARM_USART_CONTROL_RX, 1);

	USARTdrv->Control(ARM_USART_MODE_ASYNCHRONOUS |
			ARM_USART_DATA_BITS_8 |
			ARM_USART_PARITY_NONE |
			ARM_USART_STOP_BITS_1 |
			ARM_USART_FLOW_CONTROL_NONE,BOARD_BAUD_VALUE);

#if SELECT_UART_INSTANCE
NVIC_DisableIRQ(USART0_IRQn);
#else	
NVIC_DisableIRQ(ULPSS_UART_IRQn);
#endif
	
	return ;
} 

#if defined( __GNUC__ )

#if (__REDLIB_INTERFACE_VERSION__ >= 20000)
/* We are using new Redlib_v2 semihosting interface */
#define WRITEFUNC __sys_write
#define READFUNC __sys_readc
#else
/* We are using original Redlib semihosting interface */
#define WRITEFUNC __write
#define READFUNC __readc
#endif

#if defined(DEBUG_ENABLE)
#if defined(DEBUG_SEMIHOSTING)
/* Do nothing, semihosting is enabled by default in LPCXpresso */
#endif /* defined(DEBUG_SEMIHOSTING) */
#endif /* defined(DEBUG_ENABLE) */

#if !defined(DEBUG_SEMIHOSTING)
int WRITEFUNC(int iFileHandle, char *pcBuffer, int iLength)
{
#if defined(DEBUG_ENABLE)
	unsigned int i;
	for (i = 0; i < iLength; i++) {
		Board_UARTPutChar(pcBuffer[i]);
	}
#endif

	return iLength;
}
#endif
/* Called by bottom level of scanf routine within RedLib C library to read
   a character. With the default semihosting stub, this would read the character
   from the debugger console window (which acts as stdin). But this version reads
   the character from the LPC1768/RDB1768 UART. */
int READFUNC(void)
{
#if defined(DEBUG_ENABLE)
	int c = Board_UARTGetChar();
	return c;

#else
	return (int) -1;
#endif
}
#endif // defined( __GNUC__ )

#if defined(__CC_ARM)

#include <stdio.h>
#include <rt_misc.h>

#if defined(DEBUG_ENABLE)
#if defined(DEBUG_SEMIHOSTING)
#define ITM_Port8(n)    (*((volatile unsigned char *) (0xE0000000 + 4 * n)))
#define ITM_Port16(n)   (*((volatile unsigned short *) (0xE0000000 + 4 * n)))
#define ITM_Port32(n)   (*((volatile unsigned long *) (0xE0000000 + 4 * n)))

#define DEMCR           (*((volatile unsigned long *) (0xE000EDFC)))
#define TRCENA          0x01000000

/* Write to SWO */
void _ttywrch(int ch)
{
	if (DEMCR & TRCENA) {
		while (ITM_Port32(0) == 0) {}
		ITM_Port8(0) = ch;
	}
}

#else
static  void BoardOutChar(char ch)
{
#ifndef SIM_9118
	Board_UARTPutChar(ch);
#else
	*(volatile uint8_t *)0x800 = ch;
#endif	
}

#endif /* defined(DEBUG_SEMIHOSTING) */
#endif /* defined(DEBUG_ENABLE) */

struct __FILE {
	int handle;
};

FILE __stdout;
FILE __stdin;
FILE __stderr;

void *_sys_open(const char *name, int openmode)
{
	return NULL;
}

int fputc(int c, FILE *f)
{
#if defined(DEBUG_ENABLE)
#if defined(DEBUG_SEMIHOSTING)
	_ttywrch(c);
#else
	BoardOutChar((char) c);
#endif
#endif
	return 0;
}

int fgetc(FILE *f)
{
#if defined(DEBUG_ENABLE) && !defined(DEBUG_SEMIHOSTING)
	return Board_UARTGetChar();
#else
	return 0;
#endif
}

int ferror(FILE *f)
{
	return EOF;
}

void _sys_exit(int return_code)
{
	label:
	__WFI();
	goto label;	/* endless loop */
}

#endif /* defined (__CC_ARM) */

/**
 * @fn           void Board_UARTPutSTR(uint8_t *ptr)
 * @brief        Prints a string to the UART. 
 * @param[in]    ptr  : Terminated string to output
 * @return       none 
 */
void Board_UARTPutSTR(uint8_t *ptr)
{
	int i ;
	for(i =0 ; ptr[i]!='\0' ; i++)
	{
		send_done=0;
		USARTdrv->Send(&ptr[i],1);
		while(send_done==0);
	}
	return ;
}

/**
 * @fn        void RSI_Board_Init(void)
 * @brief     Set up and initialize all required blocks and functions related to the board hardware. 
 * @return    none
 */
void RSI_Board_Init(void)
{
	int i;

	for(i = 0 ; i < ledBitsCnt ;i++)
	{
		/*Set the GPIO pin MUX */
		RSI_EGPIO_SetPinMux(EGPIO1, ledBits[i].port , ledBits[i].pin,0);
		/*Set GPIO direction*/
		RSI_EGPIO_SetDir(EGPIO1, ledBits[i].port , ledBits[i].pin,0);
		/*Receive enable */
		RSI_EGPIO_PadReceiverEnable(((ledBits[i].port) * 16) + ledBits[i].pin);
	}
	/*Enable PAD selection*/
	RSI_EGPIO_PadSelectionEnable(1);

	/*Enable the DEBUG UART port*/
	DEBUGINIT();
	return ;
}

/**
 * @fn          void RSI_Board_LED_Set(int x, int y)
 * @brief       Sets the state of a board LED to on or off.
 * @param[in]   x    :  LED number to set state for
 * @param[in]   y     :  true for on, false for off 	   
 * @return      none
 */
void RSI_Board_LED_Set(int x, int y)
{
	RSI_EGPIO_SetPin(EGPIO1, ledBits[x].port , ledBits[x].pin,y);
	return ;
}

/**
 * @fn          void RSI_Board_LED_Toggle(int x)
 * @brief       Toggles the current state of a board LED. 
 * @param[in]   x : LED number to change state for
 * @return      none
 */
void RSI_Board_LED_Toggle(int x)
{
	RSI_EGPIO_TogglePort(EGPIO1, ledBits[x].port , (1 << ledBits[x].pin));
	return ;
}

/**
 * @fn        uint8_t Board_UARTGetChar(void)
 * @brief     Get a single character from the UART, required for scanf input. 
 * @return    EOF if not character was received, or character value  
 *
 */
uint8_t Board_UARTGetChar(void)
{
	uint8_t rev[1]={0};
	recv_done =0;
	USARTdrv->Receive(&rev,1);
	while(recv_done==0)
	{
		#if SELECT_UART_INSTANCE
	  RSI_M4SSUsart0Handler();
		#else	
		RSI_ULPUartHandler();
		#endif	 
	}
	return rev[0];
}

/**
 * @fn          void Board_UARTPutChar(uint8_t ch)
 * @brief       Sends a single character on the UART, required for printf redirection. 
 * @param[in]   ch	: character to send 
 * @return      none
 */
void Board_UARTPutChar(uint8_t ch)
{
	send_done=0;
	USARTdrv->Send(&ch, sizeof(ch));
	while(send_done==0)
	{
		#if SELECT_UART_INSTANCE
	  RSI_M4SSUsart0Handler();
		#else	
		RSI_ULPUartHandler();
		#endif	
	}

	return ;
}

/* IAR support */
#if defined(__ICCARM__)
/*******************
 *
 * Copyright 1998-2003 IAR Systems.  All rights reserved.
 *
 * $Revision: 30870 $
 *
 * This is a template implementation of the "__write" function used by
 * the standard library.  Replace it with a system-specific
 * implementation.
 *
 * The "__write" function should output "size" number of bytes from
 * "buffer" in some application-specific way.  It should return the
 * number of characters written, or _LLIO_ERROR on failure.
 *
 * If "buffer" is zero then __write should perform flushing of
 * internal buffers, if any.  In this case "handle" can be -1 to
 * indicate that all handles should be flushed.
 *
 * The template implementation below assumes that the application
 * provides the function "MyLowLevelPutchar".  It should return the
 * character written, or -1 on failure.
 *
 ********************/

#include <yfuns.h>

#if defined(DEBUG_UART) && !defined(DEBUG_SEMIHOSTING)

_STD_BEGIN

#pragma module_name = "?__write"

/*
   If the __write implementation uses internal buffering, uncomment
   the following line to ensure that we are called with "buffer" as 0
   (i.e. flush) when the application terminates. */
size_t __write(int handle, const unsigned char *buffer, size_t size)
{
#if defined(DEBUG_UART)
	size_t nChars = 0;

	if (buffer == 0) {
		/*
		   This means that we should flush internal buffers.  Since we
		   don't we just return.  (Remember, "handle" == -1 means that all
		   handles should be flushed.)
		 */
		return 0;
	}

	/* This template only writes to "standard out" and "standard err",
	   for all other file handles it returns failure. */
	if (( handle != _LLIO_STDOUT) && ( handle != _LLIO_STDERR) ) {
		return _LLIO_ERROR;
	}

	for ( /* Empty */; size != 0; --size) {
		Board_UARTPutChar(*buffer++);
		++nChars;
	}

	return nChars;
#else
	return size;
#endif /* defined(DEBUG_UART) */
}

_STD_END
#endif

#endif /* defined (__ICCARM__) */
