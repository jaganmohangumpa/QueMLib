/**
 * @file      rsi_dac.h
 * @version   1.0
 * @date      1 Aug 2017
 *
 *  Copyright(C) Redpine Signals 2017
 *  All rights reserved by Redpine Signals.
 *
 *  @section License
 *  This program should be used on your own responsibility.
 *  Redpine Signals assumes no responsibility for any losses
 *  incurred by customers or third parties arising from the use of this file.
 *
 *  @brief This file contains functions prototypes related to AUX-ADC peripheral
 *
 *  @section Description 
 *  this file contains list of functions prototypes for the AUX-ADC peripheral
 *
 *
 */

#ifndef __RSI_AUX_DAC_H__
#define __RSI_AUX_DAC_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "rsi_chip.h"
//#include "base_types.h"

/******************************************************
 * *                      Macros
******************************************************/ 
	
	/******************************************************
 * *                    Structures
 **/

/*
\brief DAC channel Configuration structure
*/
	
typedef struct dac_config_a{
 	        uint8_t  an_perif_dac_out_mux_en    : 1;
 	        uint8_t  an_perif_dac_out_mux_sel   : 1;
	        #define  AGPIO4                      0
	        #define  AGPIO15                     1
 	        uint8_t  aux_dac_en                 : 1;
          uint8_t  dac_dyn_en                 : 1;
	        uint8_t  dac_static_mode            : 1;
	        #define  STATIC_MODE       1
	        #define  FIFO_MODE         0
	        uint8_t  fifo_threshold             : 3;  
}dac_config;
	
typedef enum
{
	DAC_POWER_ON =0,
	DAC_POWER_OFF
}POWER_STATE_DAC;


/******************************************************
 * *                 Global Variables
 * ******************************************************/
/******************************************************
 * *               Function Declarations
 * ******************************************************/
 
uint32_t RSI_DAC_Config(AUX_ADC_DAC_COMP_Type *pstcDAC, uint32_t channel , dac_config *config);
uint32_t RSI_DAC_ReadData(AUX_ADC_DAC_COMP_Type *pstcDAC, uint32_t channel,  dac_config *config, uint16_t *data);
uint32_t RSI_DAC_Start( AUX_ADC_DAC_COMP_Type *pstcDAC ,uint32_t channel, dac_config *config );
uint32_t RSI_DAC_Stop( AUX_ADC_DAC_COMP_Type *pstcDAC,uint32_t channel, dac_config *config );
uint32_t RSI_DAC_ClkDivFactor(AUX_ADC_DAC_COMP_Type *pstcDAC, uint16_t div_factor);
void RSI_DAC_PowerControl(POWER_STATE_DAC state);
uint32_t RSI_DAC_WriteData(AUX_ADC_DAC_COMP_Type *pstcDAC, dac_config *config, uint16_t *data,uint32_t len);




#ifdef __cplusplus
}
#endif

#endif // __RSI_AUX_DAC_H__
