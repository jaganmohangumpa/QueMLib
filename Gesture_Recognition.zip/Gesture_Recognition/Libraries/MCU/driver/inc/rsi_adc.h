/**
 * @file      rsi_adc.h
 * @version   1.0
 * @date      1 Aug 2017
 *
 *  Copyright(C) Redpine Signals 2017
 *  All rights reserved by Redpine Signals.
 *
 *  @section License
 *  This program should be used on your own responsibility.
 *  Redpine Signals assumes no responsibility for any losses
 *  incurred by customers or third parties arising from the use of this file.
 *
 *  @brief This file contains functions prototypes related to AUX-ADC peripheral
 *
 *  @section Description 
 *  this file contains list of functions prototypes for the AUX-ADC peripheral
 *
 *
 */

#ifndef __RSI_AUX_ADC_H__
#define __RSI_AUX_ADC_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "RS1xxxx.h"
#include "base_types.h"

/******************************************************
 * *                      Macros
******************************************************/ 

  /**** List of Mask Bits ****/              
	#define pos0       0
	#define pos1       1
	#define pos2       2
	#define pos3       3
	#define pos4       4
	#define pos5       5
	#define pos6       6
	#define pos7       7
	#define pos8       8
	#define pos9       9
	#define pos10      10
	#define pos11      11
	#define pos12      12
 	#define pos13      13
 	#define pos14      14
 	#define pos15      15
 	#define pos16      16
 	#define pos17      17
 	#define pos18      18
 	#define pos19      19
 	#define pos20      20
 	#define pos21      21
 	#define pos22      22
 	#define pos23      23
 	#define pos24      24
 	#define pos25      25
 	#define pos26      26
 	#define pos27      27
 	#define pos28      28
 	#define pos29      29
 	#define pos30      30
 	#define pos31      31
	
 #define MULTI_CHANNEL_EVENT          1
 #define FIFO_MODE_EVENT              0
/******************************************************
 * *                    Constants
 * ******************************************************/
/******************************************************
 * *                   Enumerations
******************************************************/

typedef enum
{
	ADC_POWER_ON =0,
	ADC_POWER_OFF
}POWER_STATE;

/******************************************************
 * *                 Type Definitions
 * ******************************************************/
/******************************************************
 * *                    Structures
 **/

///*
//\brief ADC channel Configuration structure
//*/
//  #define AGPIO_IN                     0
// 	#define OPAMP_IN                     1
//  #define STATIC_MODE                  1
// 	#define FIFO_MODE                    0

//typedef struct adc_config_1_a{
// 	
//      uint8_t an_perif_adc_diffmode      : 1;
// 	 	  uint8_t an_perif_adc_in_sel        : 4;
// 	 	  uint8_t an_perif_adc_ip_sel        : 5; 
// 	 	  uint8_t fifo_threshold             : 3;
// 	 	  uint8_t input_sel                  : 1;
// 	 	
//	     
// }adc_config_1_t;

// typedef struct adc_config_2_a{ 
//	    uint8_t   multi_channel_en         : 1; 
// 	 	  uint8_t   static_mode              : 1;
// 	 	
// 	 	  uint16_t  ping_length              :11;
// 	 	  uint16_t  pong_length              :11;
//	    uint8_t   ping_enable           	 :1 ;
//	    uint8_t   pong_enable           	 :1 ;
// }adc_config_2_t;
// 
// typedef struct adc_config_3_a{        
// 	 	  uint32_t ping_addr                 :32;
// 	 	 // uint32_t pong_addr                 :32;
// }adc_config_3_t;
// 
// typedef struct adc_config_5_a{  
//   uint32_t pong_addr                   :32;
// }adc_config_5_t;
// 
// typedef struct adc_config_4_a{      
// 	 	  uint16_t adc_ch_offset             :16; // for which channel which position clk need to be activated
//      uint16_t adc_ch_freq_val           :16; // after how many regular cks nxt clk need to be generated  i.e. can decide sampling       
//}adc_config_4_t;
//	 
// 
// 
//typedef struct adc_config{ 	        
//         adc_config_1_t adc_config_1[16] ;
// 	       adc_config_2_t adc_config_2[16] ;
// 	       adc_config_3_t adc_config_3[16] ;
//	       adc_config_4_t adc_config_4[16] ;
//	       adc_config_5_t adc_config_5[16] ;
//}adc_config_t;
 

typedef struct
{
	void (*adccallbacFunc)( uint16_t channel,uint8_t event);   			  /*!< Call back function pointer */
		
} RSI_ADC_CALLBACK_T;

/******************************************************
 * *                 Global Variables
 * ******************************************************/
/******************************************************
 * *               Function Declarations
 * ******************************************************/
 
void RSI_ADC_Calibration(void);

uint32_t RSI_ADC_PingPongMemoryAdrConfig(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel ,uint32_t ping_addr, uint32_t pong_addr,uint16_t ping_length, uint16_t pong_length,uint8_t ping_enable,uint8_t pong_enable );

uint32_t RSI_ADC_PingpongEnable(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel);

uint32_t RSI_ADC_InternalPerChnlDmaEnable(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel);

void RSI_ADC_Config(AUX_ADC_DAC_COMP_Type *pstcADC,uint8_t multi_channel_en, uint8_t static_fifo_mode, uint8_t fifo_threshold, uint8_t internal_dma_en );

uint32_t RSI_ADC_ChannelConfig(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel , uint8_t an_perif_adc_ip_sel,uint8_t an_perif_adc_in_sel, uint8_t an_perif_adc_diffmode );

uint32_t RSI_ADC_FifoMode(AUX_ADC_DAC_COMP_Type *pstcADC,uint16_t an_perif_adc_ip_sel, uint16_t an_perif_adc_in_sel, uint8_t an_perif_adc_diffmode);

uint32_t RSI_ADC_StaticMode(AUX_ADC_DAC_COMP_Type *pstcADC,uint16_t an_perif_adc_ip_sel, uint16_t an_perif_adc_in_sel,uint8_t an_perif_adc_diffmode);

uint32_t RSI_ADC_Start( AUX_ADC_DAC_COMP_Type *pstcADC );

uint32_t RSI_ADC_Stop( AUX_ADC_DAC_COMP_Type *pstcADC );

uint32_t RSI_ADC_ChnlEnable(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel);

uint32_t RSI_ADC_ChnlDisable(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel);

uint32_t RSI_ADC_ReadData(AUX_ADC_DAC_COMP_Type *pstcADC, uint16_t *data, uint8_t ping_pong,uint16_t channel);

uint32_t RSI_ADC_ReadDataStatic(AUX_ADC_DAC_COMP_Type *pstcADC);

uint32_t RSI_ADC_ClkDivfactor(AUX_ADC_DAC_COMP_Type *pstcADC , uint16_t adc_on_time , uint16_t adc_total_duration);

uint32_t RSI_ADC_ChannelSamplingRate(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel , uint16_t adc_ch_offset, uint16_t adc_ch_freq_val);

uint32_t RSI_ADC_ChnlIntrMask(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel);

uint32_t RSI_ADC_ChnlIntrUnMask(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel);

uint32_t RSI_ADC_ChnlIntrClr(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel);

uint32_t RSI_ADC_ChnlIntrStatus(AUX_ADC_DAC_COMP_Type *pstcADC);

void RSI_ADC_PowerControl(POWER_STATE state);

uint32_t RSI_ADC_NoiseAvgMode(AUX_ADC_DAC_COMP_Type *pstcADC, bool en_disable);

uint32_t RSI_ADC_TempSensorEnable(AUX_ADC_DAC_COMP_Type *pstcADC);

uint32_t RSI_ADC_ThresholdConfig(AUX_ADC_DAC_COMP_Type *pstcADC , uint32_t threshold1,uint32_t threshold2, uint8_t range);

uint32_t RSI_ADC_Bbp(AUX_ADC_DAC_COMP_Type *pstcADC ,uint8_t adc_bbp_en, uint8_t bbp_en, uint8_t bbp_id);

void RSI_ADC_InterruptHandler( AUX_ADC_DAC_COMP_Type *pstcADC,RSI_ADC_CALLBACK_T *pADCCallBack);

void RSI_ADC_PingPongReInit(AUX_ADC_DAC_COMP_Type *pstcADC, uint8_t channel,uint8_t ping_enable,uint8_t pong_enable );

#ifdef __cplusplus
}
#endif

#endif // __RSI_AUX_ADC_H__
