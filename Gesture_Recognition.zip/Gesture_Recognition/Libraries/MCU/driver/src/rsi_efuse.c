/**
 * @file       rsi_efuse.c
 * @version    1.0
 * @date       1 Aug,2017
 *
 * Copyright(C) Redpine Signals 2016
 * All rights reserved by Redpine Signals.
 *
 * @section License
 * This program should be used on your own responsibility.
 * Redpine Signals assumes no responsibility for any losses
 * incurred by customers or third parties arising from the use of this file.
 *
 * @brief This files contains functions related to EFUSE
 * 
 * @section Description
 * This file contains the list of functions for configuring the EFUSE.
 * Following are list of API's which need to be defined in this file.
 *
 */



/* Includes */
#include "rsi_chip.h"

/* This API Is Used To Enable The EFUSE */  
void efuse_enable(EFUSE_Type* pstcEfuse)
{
  pstcEfuse->EFUSE_CTRL_REG_b.EFUSE_ENABLE =1U;
}

/* This API is used to Disable the EFUSE */
void efuse_Disable(EFUSE_Type* pstcEfuse)
{
	pstcEfuse->EFUSE_CTRL_REG_b.EFUSE_ENABLE =0U;
}

/* This API is used to read the eFUSE data */
uint8_t efuse_read_data(EFUSE_Type* pstcEfuse)
{
	return (pstcEfuse->EFUSE_READ_DATA_REG & 0xFF);
}

/* This API is used to set the eFUSE address for read and write operations */
void efuse_write_addr(EFUSE_Type* pstcEfuse , uint16_t u16Addr)
{
	/* Write address into address register*/
	pstcEfuse->EFUSE_DA_ADDR_REG |= (u16Addr & 0XFFFF);
}

/*  Any Bit in this macro can be programmed in any order by raising STROBE high for aperiod specified  by TPGM with a proper address selected.There is only one programming scheme,which is single bit programming */
error_t efuse_write_bit(EFUSE_Type *pstcEfuse , uint16_t u16Addr , uint8_t u8BitPos,uint32_t hold_time)
{
	/* Check for valid parameters */
	if( pstcEfuse == NULL )
	{
		return ERROR_EFUSE_INVALID_PARAMETERS;
	}
	if(	u16Addr > ADDRESS_MAX ) 
	{
		return ERROR_EFUSE_INVALID_WRITE_ADDRESS;
	}
	if(u8BitPos > BIT_POS_MAX )
	{
		return ERROR_EFUSE_INVALID_WRITE_BIT_POSITION;
	}

	/*Direct access enable */
	pstcEfuse->EFUSE_CTRL_REG = 0x06; 

	/*Lowering PGENB,CSB and LOAD with direct access */
	pstcEfuse->EFUSE_DA_CTRL_CLEAR_REG = 0x0B; 

	/*Address with bit position*/
	u16Addr |= (u8BitPos <<5);

	/*Fill the address register*/
	pstcEfuse->EFUSE_DA_ADDR_REG = u16Addr;

	/*Setting STROBE with direct access */
	pstcEfuse->EFUSE_DA_CTRL_SET_REG = 0x04; 

	/*Fill the eFUSE strobe hold count register*/
	/*32Mhz as base clock 2us hold time*/
	pstcEfuse->EFUSE_DA_CLR_STROBE_REG = (BIT(9)|hold_time);

 
	while(!(pstcEfuse->EFUSE_STATUS_REG & 0x0400));
		
	/* Setting CSB and LOAD  with direct access */
	pstcEfuse->EFUSE_DA_CTRL_SET_REG = 0x0A; 

	/*waiting for THP_A  (A7~A0 to STROBE Set time into Program mode) */
	/* Setting  PGENB with direct access */
	pstcEfuse->EFUSE_DA_CTRL_SET_REG = 0x01;
	
	pstcEfuse->EFUSE_CTRL_REG &= 0x02;

	return RSI_OK;
}

/* This API is used to read the data from 32x8 byte eFUSE memory(OTP) in fsm mode */
error_t efuse_fsm_read_byte(EFUSE_Type *pstcEfuse , uint16_t u16Addr , uint8_t *pu8Byte,uint32_t SocClk)
{
	float	read_time;
	uint8_t read_parameter;
	read_time=((1/SocClk)*(1000));
	read_parameter=42/read_time;
	/* Check for valid parameters */
	if( pstcEfuse == NULL )
	{
		return ERROR_EFUSE_INVALID_PARAMETERS;
	}
	if(	u16Addr > ADDRESS_MAX ) 
	{
		return ERROR_EFUSE_INVALID_WRITE_ADDRESS;
	}
	
	/*Set eFUSE time*/
	pstcEfuse->EFUSE_RD_TMNG_PARAM_REG = ((0x5<<8)|(read_parameter<<4)|(0x1<<0)) ;

	/*10 bit address with msb made 1 to enable read state machine */
	pstcEfuse->EFUSE_READ_ADDR_REG = (0x8000|u16Addr); 

	/*Enable eFUSE*/
	pstcEfuse->EFUSE_CTRL_REG = 0x1; 

	/*Wait for FSM data read done*/
	while (!(((pstcEfuse->EFUSE_READ_DATA_REG))& READ_FSM_DONE));

	/*Disable eFUSE*/
	pstcEfuse->EFUSE_CTRL_REG = 0x0;  

	/*Read eFUSE Data and copy to the application pointer */
	*pu8Byte = efuse_read_data(pstcEfuse);

	return RSI_OK;
}

/* This API is used to read the data from 32x8 byte eFUSE memory(OTP) in memory mapped mode */
error_t efuse_mem_map_read_byte(EFUSE_Type *pstcEfuse , uint16_t u16Addr , uint8_t *pu8Byte,uint32_t SocClk)
{
	float	read_time;
	uint8_t read_parameter;
	read_time=((1/SocClk)*(1000));
	read_parameter=42/read_time;
	/* Check for valid parameters */
	if( pstcEfuse == NULL )
	{
		return ERROR_EFUSE_INVALID_PARAMETERS;
	}
	if(	u16Addr > ADDRESS_MAX ) 
	{
		return ERROR_EFUSE_INVALID_WRITE_ADDRESS;
	}
	pstcEfuse->EFUSE_RD_TMNG_PARAM_REG = ((0x5<<8)|(read_parameter<<4)|(0x1<<0)) ;
	
	/*enable */
	pstcEfuse->EFUSE_CTRL_REG = 0x1;  
	
	/*Configure memory MAP read in byte mode*/
	pstcEfuse->EFUSE_MEM_MAP_LENGTH_REG = 0x0000;
	
	/*Read byte from memory*/
	*pu8Byte = *((uint8_t volatile *)(EFUSE_BASE + 0x2000 + u16Addr));
	
	return RSI_OK;
}

/* This API is used to Read the 1 word(16 bits) of data to EFUSE macro */
error_t efuse_mem_map_read_word(EFUSE_Type *pstcEfuse , uint16_t u16Addr , uint16_t *pu16Word,uint32_t SocClk)
{
	float	read_time;
	uint8_t read_parameter;
	read_time=((1/SocClk)*(1000));
	read_parameter=42/read_time;
	/* Check for valid parameters */
	if( pstcEfuse == NULL )
	{
		return ERROR_EFUSE_INVALID_PARAMETERS;
	}
	if(	u16Addr > ADDRESS_MAX ) 
	{
		return ERROR_EFUSE_INVALID_WRITE_ADDRESS;
	}
	pstcEfuse->EFUSE_RD_TMNG_PARAM_REG =  ((0x5<<8)|(read_parameter<<4)|(0x1<<0));
	
	/*eFUSE enable*/
	pstcEfuse->EFUSE_CTRL_REG = 0x1;  
	
	/*Select 16 bit read mode*/
	pstcEfuse->EFUSE_MEM_MAP_LENGTH_REG = 0x0001;

	/*Read from address*/
	*pu16Word = *((uint16_t volatile *)(EFUSE_BASE + 0x2000 + u16Addr));
	return RSI_OK;
}
/*End of file not truncated */
