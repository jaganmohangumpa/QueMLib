/**
 * @file      rsi_adc.c
 * @version   1.0
 * @date      1 Aug 2017
 *
 *  Copyright(C) Redpine Signals 2017
 *  All rights reserved by Redpine Signals.
 *
 *  @section License
 *  This program should be used on your own responsibility.
 *  Redpine Signals assumes no responsibility for any losses
 *  incurred by customers or third parties arising from the use of this file.
 *
 *  @brief This file contains APIs related to AUX-ADC
 *
 *  @section Description
 *  This file contains APIs relared to Analog to Digital converter peripheral
 *
 *
 */

 /* Includes */
 
#include "rsi_chip.h"


/**
 * @fn           uint32_t RSI_DAC_Config(AUX_ADC_DAC_COMP_Type *pstcDAC, uint32_t channel , dac_config *config)
 * @brief        This API is used to Configure require [arameters in Static, Reference voltage and FIFO mode
 * @param[in]    channel  :DAC channel to be configured as 0,1,2 ...15 when ADC multichannel enable is present
 * @param[in]    config   :pointer to the DAC channel configuration structure when ADC multichannel mode is set
 * @return       execution status 
 *
 */
uint32_t RSI_DAC_Config(AUX_ADC_DAC_COMP_Type *pstcDAC, uint32_t channel , dac_config *config)
{
		
	pstcDAC->AUXDAC_CTRL_1_b.DAC_FIFO_THRESHOLD   = config->fifo_threshold ;
	pstcDAC->AUXDAC_CTRL_1_b.DAC_FIFO_FLUSH = 1U;
	if( config->dac_dyn_en == 1 )
	{
		  pstcDAC->AUXDAC_CONIG_1_b.AUXDAC_DYN_EN = 1U;
      pstcDAC->AUXDAC_CTRL_1_b.DAC_TO_CTRL_ADC = 1;				
			pstcDAC->ADC_CH_BIT_MAP_CONFIG[channel].ADC_CH_BIT_MAP_CONFIG_0_b.CHANNEL_BITMAP = ( config->an_perif_dac_out_mux_en << 29 |
                                                                      config->an_perif_dac_out_mux_sel<< 30 );
  }
	else
  {		
    if( config->dac_static_mode == FIFO_MODE)
		{
			pstcDAC->AUXDAC_CONIG_1_b.AUXDAC_DYN_EN = 1U;
			pstcDAC->AUXDAC_CONIG_1_b.AUXDAC_OUT_MUX_EN = config->an_perif_dac_out_mux_en;
		  pstcDAC->AUXDAC_CONIG_1_b.AUXDAC_OUT_MUX_SEL=0U;	
		}
  }
	return RSI_OK;
}

/**
 * @fn           uint32_t RSI_DAC_WriteData(AUX_ADC_DAC_COMP_Type *pstcDAC, dac_config *config, uint16_t *data,uint32_t len)
 * @brief        This API is used to Read output data 
 * @param[in]    config   :pointer to the DAC channel configuration structure when ADC multichannel mode is set
 * @param[in]    data     :Input data 
 * @return       execution status 
 *
 */
uint32_t RSI_DAC_WriteData(AUX_ADC_DAC_COMP_Type *pstcDAC, dac_config *config, uint16_t *data,uint32_t len)
{
	uint32_t i;
	if(config->dac_static_mode == STATIC_MODE)
	{
		for(i=0;i<len;i++){
	  pstcDAC->AUXDAC_DATA_REG_b.AUXDAC_DATA = (*data) ;
		data++;
		}
	}
	return RSI_OK;
}

/**
 * @fn           uint32_t RSI_DAC_WriteDataStatic(AUX_ADC_DAC_COMP_Type *pstcDAC, dac_config *config, uint16_t *data,uint32_t len)
 * @brief        This API is used to Read output data 
 * @param[in]    config   :pointer to the DAC channel configuration structure when ADC multichannel mode is set
 * @param[in]    data     :Input data 
 * @return       execution status 
 *
 */
uint32_t RSI_DAC_WriteDataStatic(AUX_ADC_DAC_COMP_Type *pstcDAC, dac_config *config, uint16_t *data,uint32_t len)
{
	uint32_t i;
	if(config->dac_static_mode == STATIC_MODE)
	{
		for(i=0;i<len;i++){
	  pstcDAC->AUXDAC_CONIG_1_b.AUXDAC_DATA_S = (*data);
		pstcDAC->AUXDAC_CONIG_1_b.AUXDAC_EN_S = 1U;
		if(config->an_perif_dac_out_mux_en)
		{			
			pstcDAC->AUXDAC_CONIG_1_b.AUXDAC_OUT_MUX_EN   = config->an_perif_dac_out_mux_en ;
	  	pstcDAC->AUXDAC_CONIG_1_b.AUXDAC_OUT_MUX_SEL  = config->an_perif_dac_out_mux_sel ;
		 }else{
			return ERROR_NO_PAD_SEL;
		 }
		  data++;
		}
	}
	return RSI_OK;
}


/**
 * @fn           uint32_t RSI_DAC_ReadData(AUX_ADC_DAC_COMP_Type *pstcDAC, uint32_t channel,  dac_config *config, uint16_t data)
 * @brief        This API is used to Read output data 
 * @param[in]    channel  :DAC channel to be configured as 0,1,2 ...15 when ADC multichannel enable is present
 * @param[in]    config   :pointer to the DAC channel configuration structure when ADC multichannel mode is set
 * @param[out]   data     :Output data 
 * @return       execution status 
 *
 */
uint32_t RSI_DAC_ReadData(AUX_ADC_DAC_COMP_Type *pstcDAC, uint32_t channel,  dac_config *config, uint16_t *data)
{
	
	if( config->dac_dyn_en ==1 )
	{
	  if(!(config->dac_static_mode == FIFO_MODE))
		{ 
			 *data	 = pstcDAC->ADC_CH_BIT_MAP_CONFIG[channel].ADC_CH_BIT_MAP_CONFIG_1_b.CHANNEL_BITMAP ;
	     *data  = *data >> 1;
	     *data  = ( *data | ( pstcDAC->ADC_CH_BIT_MAP_CONFIG[channel].ADC_CH_BIT_MAP_CONFIG_0_b.CHANNEL_BITMAP >> 31 ));
		}
	}
	else if(!(pstcDAC->AUXDAC_CONIG_1_b.AUXDAC_OUT_MUX_EN == 1))
	{
		  *data = pstcDAC->AUXDAC_CONIG_1_b.AUXDAC_DATA_S;
	}
	
	return RSI_OK;
}

/**
 * @fn           uint32_t RSI_DAC_Start( AUX_ADC_DAC_COMP_Type *pstcDAC ,uint32_t channel, dac_config *config )
 * @brief        This API is used to start the ADC
 * @param[in]    channel  :DAC channel to be configured as 0,1,2 ...15 when ADC multichannel enable is present
 * @param[in]    config   :pointer to the DAC channel configuration structure when ADC multichannel mode is set
 * @return       execution status 
 *
 */
uint32_t RSI_DAC_Start( AUX_ADC_DAC_COMP_Type *pstcDAC ,uint32_t channel, dac_config *config )
{
	
	if( config->dac_dyn_en ==1 )
	{
		pstcDAC->AUXDAC_CONIG_1_b.AUXDAC_DYN_EN         = 1U ;			
		pstcDAC->AUXDAC_CTRL_1_b.DAC_ENABLE_F          = config->aux_dac_en ;
			
		pstcDAC->ADC_CH_BIT_MAP_CONFIG[channel].ADC_CH_BIT_MAP_CONFIG_0_b.CHANNEL_BITMAP  =  config->aux_dac_en << 28;
			// pstcDAC->ADC_CH_BIT_MAP_CONFIG_b[channel][0].CHANNEL_BITMAP =  config->aux_dac_en << 28;
			
	}else{
		if(config->dac_static_mode == FIFO_MODE)
		{ 
			
			pstcDAC->AUXDAC_CONIG_1_b.AUXDAC_EN_S = 1U;
	    pstcDAC->AUXDAC_CTRL_1_b.ENDAC_FIFO_CONFIG     = 1U;
			pstcDAC->AUXDAC_CTRL_1_b.DAC_ENABLE_F          = config->aux_dac_en ;
		}
	}
	return RSI_OK;
}

/**
 * @fn           uint32_t RSI_DAC_Stop( AUX_ADC_DAC_COMP_Type *pstcDAC )
 * @brief        This API is used to stop the ADC
 * @param[in]    channel  :DAC channel to be configured as 0,1,2 ...15 when ADC multichannel enable is present
 * @param[in]    config   :pointer to the DAC channel configuration structure when ADC multichannel mode is set
 * @return       execution status 
 *
 */
uint32_t RSI_DAC_Stop( AUX_ADC_DAC_COMP_Type *pstcDAC,uint32_t channel, dac_config *config )
{
	if( config->dac_dyn_en ==1 )
	{
		pstcDAC->AUXDAC_CONIG_1_b.AUXDAC_DYN_EN   = 0 ;			
		
		if( config->dac_static_mode == FIFO_MODE)
		{ 
		  pstcDAC->AUXDAC_CTRL_1_b.DAC_ENABLE_F          = 0U;
	    pstcDAC->AUXDAC_CTRL_1_b.ENDAC_FIFO_CONFIG     = 0U;
		}else{
			pstcDAC->ADC_CH_BIT_MAP_CONFIG[channel].ADC_CH_BIT_MAP_CONFIG_0_b.CHANNEL_BITMAP =  0 << 28;
		}		
	}else{
	  pstcDAC->AUXDAC_CONIG_1_b.AUXDAC_EN_S = 0;
	}
  return RSI_OK;
}

/**
 * @fn           uint32_t RSI_DAC_ClkDivFactor(AUX_ADC_DAC_COMP_Type *pstcDAC, uint16_t div_factor)
 * @brief        This API is used to set clock with configurable on time 
 * @param[in]    div_factor        : clock division factor to be programmed
 * @return       execution status 
 *
 */
uint32_t RSI_DAC_ClkDivFactor(AUX_ADC_DAC_COMP_Type *pstcDAC, uint16_t div_factor)
{
	pstcDAC->AUXDAC_CLK_DIV_FAC_b.DAC_CLK_DIV_FAC = div_factor ;
  return RSI_OK;
}


/**
 * @fn           uint32_t RSI_DAC_PowerControl(POWER_STATE state)
 * @brief        This API is used to Power On and off for DAC
 * @param[in]    state : DAC_POWER_ON - To powerup dac powergates
                         DAC_POWER_OFF - To powerdown dac powergates
 * @return       execution status 
 *
 */
void RSI_DAC_PowerControl(POWER_STATE_DAC state)
{
  
	switch(state)
	{
		case DAC_POWER_ON  :
		RSI_IPMU_PowerGateSet(AUXADC_PG_ENB);
		RSI_PS_UlpssPeriPowerUp(ULPSS_PWRGATE_ULP_AUX);
		break;
		case DAC_POWER_OFF :
		RSI_IPMU_PowerGateClr( AUXADC_PG_ENB  );
		break;
	}
}


