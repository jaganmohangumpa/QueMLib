#include "rsi_wurx.h"
#include "rsi_chip.h"

/**
 * @fn           void RSI_WURX_Init(uint8_t bypass_l1_enable,uint8_t number_of_bits,uint8_t l1_freq_div,l2_freq_div)
 * @brief        This API is used to calculate the 40MHz calibration.
 * @param[in]    bypass_l1_enable            : Enable or disable the bypass functionality of level1 
 * @param[in]    l1_freq_div                 : Set the level1 frequency by using division factor ,This parameter define frequency.
 *                                             Ranges : 32 khz incoming clock  then following option 
 *                                             0 : 0.125 khz, 1: 0.250 Khz, 2: 0.5 khz ,3: 1 khz, default : 2 khz  
 *                                             Ranges : 64 khz incoming clock  then following option 
 *                                             0 : 0.25 khz, 1: 0.5 Khz, 2: 1 khz ,3: 2 khz 
 * @param[in]    l2_freq_div                 : Set the level2 frequency by using division factor ,This parameter define frequency.
 *                                             Ranges : 32 khz incoming clock  then following option 
 *                                             0 : 4 khz, 1: 8 Khz, 2: 16 khz ,3: 32 khz 
 *                                             Ranges : 64 khz incoming clock  then following option 
 *                                             0 : 8 khz, 1: 16 Khz, 2: 32 khz ,3: 64 khz
 * @return       None
 */
void RSI_WURX_Init(uint8_t bypass_l1_enable,uint8_t l1_freq_div,uint8_t l2_freq_div)
{
  /*Wait for Out of reset*/
	while(!(WURX_MANUAL_CALIB_MODE_REG2 & 0x000001));
	while(!(WURX_CORR_DET_READ_REG      & 0x000002));
   /* Bypass L1 pattern */
  WURX_BYPASS_LEVEL1_AND_FREQ |= (bypass_l1_enable << POS21) ; 
	
  if(bypass_l1_enable){
   // Do nothing here  
  }else{
   /* Clear the frequency for L1 level pattern */
   WURX_BYPASS_LEVEL1_AND_FREQ &= ~(0x7 << POS18) ;	
   /* Freq L1 pattern (3 : 32Khz, 2 : 16Khz, 1 : 8Khz, 0 : 4Khz) for 32KHz Clock */	
   WURX_BYPASS_LEVEL1_AND_FREQ |= (l1_freq_div << POS18) ;   
  }
  /* Configure L2 pattern */   
	/* Clear the frequency for L2 pattern */
  WURX_BYPASS_LEVEL1_AND_FREQ &= ~(0x3 << POS16) ;	
  /* Freq L2 pattern (3 : 32Khz, 2 : 16Khz, 1 : 8Khz, 0 : 4Khz) for 32KHz Clock */	
  WURX_BYPASS_LEVEL1_AND_FREQ |= (l2_freq_div << POS16) ;	  
}

/**
 * @fn           void RSI_IPMU_40MhzClkCalib(uint8_t clk_enable,uint32_t channel_selection_value)
 * @brief        This API is used to calculate the 40MHz calibration.
 * @param[in]    clk_enable                  : Clock enable
 * @param[in]    channel_selection_value     : Channel selection frequency
 * @return       None
 */
void RSI_IPMU_40MhzClkCalib(uint8_t clk_enable,uint32_t channel_selection_value)
{
   uint32_t cntr;
	
   if(clk_enable)
   {

      /* enable ulpss_clk */ 
		 // RSI_ULPSS_EnableRefClks(MCU_ULP_40MHZ_CLK_EN,ULP_PROCESSOR_CLK,0);
		 
		 /*  NPSS REF Clock Cleaner OFF = 1 */
      ULPCLKS_REFCLK_REG |= (BIT(17));  // 
        /*NPSS REF Clock Cleaner ON = 0  bydefault is one */		
      ULPCLKS_REFCLK_REG &= ~(BIT(18));
      /* NPSS REF CLOCK Mux to SPI */		
      ULPCLKS_REFCLK_REG &= ~(BIT(16));  
		  /* SOC 40Mhz clock for Calibration */
      //ULPCLKS_REFCLK_REG |= (BIT(21));  
		  /* Ulp_clk 32Mhz clock for Calibration */		
      ULPCLKS_REFCLK_REG |= (BIT(21)| BIT(19));           
     	/* wait */		
      for (cntr = 0; cntr < (10 *4); cntr++)
      {
          __ASM("nop");
      }
        /* NPSS REF Clock Cleaner ON = 1 */	  
      ULPCLKS_REFCLK_REG |= (BIT(18));  
        /* NPSS REF Clock Cleaner OFF = 0 */	  
      ULPCLKS_REFCLK_REG &= ~(BIT(17)); 
	    /* Sets the ref clock to 40MHz RC clock and makes the ref clk freq to 20MHz as the reference clock is div/2 */	 
	    WURX_AAC_MODE_REG |= ( (0x1 << POS20) | (REF_CLOCK_FREQ << POS7) );

      /* Sets the required clock frequency to 2412GHz/80.Enables the b search calibration for lco frequency */
	    WURX_LCO_FREQ_CALIB_REG |= ( (BIT(13) | channel_selection_value ) );	  //2475 ->0x7BC
		
	    while(!(WURX_AAC_MODE_REG & 0x000002));
	    while((WURX_AAC_MODE_REG & 0x000002));
    }
    else
    {
       WURX_AAC_MODE_REG &= ~( BIT(19) | BIT(20) ) ;   
       /* NPSS Ref Clock CLeaner OFF */
       ULPCLKS_REFCLK_REG |= (BIT(17));
       ULPCLKS_REFCLK_REG &= ~(BIT(18));
    }		
}

/**
 * @fn           void RSI_IPMU_DCCalib()
 * @brief        This API is used to calculate the manual DC calibration as well as enable periodic detection enable 
 * @param[in]    None
 * @return       None
 */ 
 void RSI_IPMU_DCCalib()
{
		WURX_COMP_OFFSET_CALIB_REG |= (( VAL1 << POS10) | (DC_OFFSET_VALUE << POS3 ) | ( VAL2 << POS1) ); // 5% periodic auto calibration    
	  WURX_ENABLE_AND_AAC_DET_REG |= BIT(2); // Continiuos calibration mode is Enabled
}
 
/**
 * @fn           void RSI_WURX_Enable(uint8_t wurx_enable)
 * @brief        This API is used enable wurx.
 * @param[in]    wurx_enable   : Enable bit to enable wurx for operation. as well as enable correlation
 * @return       None
 */
void RSI_WURX_Enable(uint8_t wurx_enable)
{
    if(wurx_enable){
     /* Enable wurx and clk_en */
     WURX_ENABLE_AND_AAC_DET_REG |= ( BIT(1) | BIT(0));
	 /* Correlation Enable */
     MCU_FSM->MCU_FSM_CRTL_PDM_AND_ENABLES |= (BIT(1));	 
    }else{               
     /* Disable wurx and clk_en */
     WURX_ENABLE_AND_AAC_DET_REG &= ~(BIT(1) | BIT(0));
	   /* Disable wurx and clk_en */
     MCU_FSM->MCU_FSM_CRTL_PDM_AND_ENABLES &= ~(BIT(1));	 
    }
}

/**
 * @fn           void RSI_WURX_SetWakeUpThreshold(uint8_t pattern_number,uint8_t threshold_1 ,uint8_t threshold_2)
 * @brief        This API is used set up threshold value for operation.
 * @param[in]    threshold_1    : Threshold value for pattern1.
 * @param[in]    threshold_2    : Threshold value for pattern2. 
 * @param[in]    number_of_bits : Number of bits in level 1 correlation
 * @return       None
 */
void RSI_WURX_SetWakeUpThreshold(uint8_t threshold_1 ,uint8_t threshold_2)
{
    /* clear bit9 to 14 */ 
    WURX_CORR_CALIB_REG &= ~(0x3F << POS9); 
    /* Set threshold value for pattern1 */
    WURX_CORR_CALIB_REG |= (threshold_1 << POS9); 
  
    /* clear bit3 to 8 */ 
    WURX_CORR_CALIB_REG &= ~(0x3F << POS3); 
    /* Set threshold value for pattern2 */
    WURX_CORR_CALIB_REG |= (threshold_2 << POS3); 	

} 
/**
 * @fn           void RSI_WURX_Pattern2DetectionEnable(uint8_t enable)
 * @brief        This API is used enable pattern2.
 * @param[in]    enable  : Enable the pattern2 detection bit  .  
 * @return       None
 */ 
void RSI_WURX_Pattern2DetectionEnable(uint8_t enable)
{
  if(enable){
	/* Pattern2 detection enable */  
    WURX_CORR_CALIB_REG  |= BIT(18);
  }
  else
  {
	/* Pattern2 detection disable */ 	  
    WURX_CORR_CALIB_REG  &= ~BIT(18);
  }
}

/**
 * @fn           void RSI_WURX_TailDataDecode(uint8_t enable , uint8_t data_len)
 * @brief        This API is used to configure the L2 pattern
 * @param[in]    enable    : Enable the tail data decode bit. 
 * @param[in]    data_len  : Set the detection bit lenght.
 * @return       None
 */ 
void RSI_WURX_TailDataDecodeEnable(uint8_t enable,uint8_t data_len)
{
   if(enable){
	   /*WURX Decode Tail bits */ 
      WURX_CORR_CALIB_REG |= BIT(2);	
		  WURX_CORR_CALIB_REG = data_len;		 
   }else
   {
	    /* Clear Decode Tail bits */ 
      WURX_CORR_CALIB_REG &= ~BIT(2);	  
   }
}   


/**
 * @fn           uint8_t RSI_WURX_GetTailData(uint32_t *tail_data)
 * @brief        This API is used get the tail data
 * @param[in]    tail_data : Pointer to store the tail data.
 * @return       return status this api ,its pass or fail.
 */ 
error_t RSI_WURX_GetTailData(uint32_t *tail_data,uint8_t tail_data_len)
{ 
  if(tail_data_len==0x0)
  {
    while(!(WURX_CORR_DET_READ_REG & BIT(17)));
		RSI_WURX_ReadPattern1Odd(tail_data);
	}
  else if(tail_data_len==0x01)
	{
   while(!(WURX_CORR_DET_READ_REG & BIT(17)));
	 RSI_WURX_ReadPattern1Odd(tail_data);		
   while(!(WURX_CORR_DET_READ_REG & BIT(16)));
   RSI_WURX_ReadPattern1Even(tail_data);
  }
  else if(tail_data_len==0x02)
	{
   while(!(WURX_CORR_DET_READ_REG & BIT(17)));
	 RSI_WURX_ReadPattern1Odd(tail_data);		
   while(!(WURX_CORR_DET_READ_REG & BIT(16)));
   RSI_WURX_ReadPattern1Even(tail_data);
   while(!(WURX_CORR_DET_READ_REG & BIT(15)));
	 RSI_WURX_ReadPattern2Odd(tail_data);	
  }	
  else if(tail_data_len==0x03)
	{	
   while(!(WURX_CORR_DET_READ_REG & BIT(17)));
	 RSI_WURX_ReadPattern1Odd(tail_data);
   while(!(WURX_CORR_DET_READ_REG & BIT(16)));
   RSI_WURX_ReadPattern1Even(tail_data);
   while(!(WURX_CORR_DET_READ_REG & BIT(15)));
	 RSI_WURX_ReadPattern2Odd(tail_data);	
   while(!(WURX_CORR_DET_READ_REG & BIT(14)));
   RSI_WURX_ReadPattern2Even(tail_data);
  }		
	else
	{
		return INVALID_PARAMETERS;
	}		
	return RSI_OK;
}
/**
 * @fn           uint16_t RSI_WURX_CalThershValue(uint8_t bit_length,uint8_t percentage)
 * @brief        This API is used to calculate the threshold value.
 * @param[in]    bit_length : Bit length 64 or 32 bit.
 * @param[in]    percentage : Percentage the calculate the threshold value. 
 * @return       return the threshold value.
 */
uint16_t RSI_WURX_CalThershValue(uint8_t bit_length,uint8_t percentage)
{
		return ((percentage/100)*bit_length);		
}

/**
 * @fn           void RSI_WURX_Pattern1MactchValue(uint8_t bit_position,uint32_t match_value)
 * @brief        This API is used set the match value for detection pattern1 purpose.
 * @param[in]    match_value  : Match value.
 * @param[in]    bit_position : bit position for selecting the specific register. 
 * @return       None
 */ 
void RSI_WURX_Pattern1MactchValue(uint32_t *match_value)
{
		WURX_PATTERN1_REG_MSB = match_value[2];
		WURX_PATTERN1_REG_MID = match_value[1];		
		WURX_PATTERN1_REG_LSB = match_value[0];		
}

/**
 * @fn           void RSI_WURX_Pattern2MactchValue(uint8_t bit_position,uint32_t match_value)
 * @brief        This API is used set the match value for detection pattern2 purpose.
 * @param[in]    match_value  : Match value.
 * @param[in]    bit_position : bit position for selecting the specific register. 
 * @return       None
 */ 
void RSI_WURX_Pattern2MactchValue(uint32_t *match_value)
{
		WURX_PATTERN2_REG_MSB = match_value[2];
		WURX_PATTERN2_REG_MID = match_value[1];		
		WURX_PATTERN2_REG_LSB = match_value[0];			
}

/**
 * @fn           void RSI_WURX_PatternLength(uint8_t enable,uint8_t data_len)
 * @brief        This API is used set pattern length for wakeup
 * @param[in]    l1_len  : value to decide the l1 pattern lenght.
 *                         Ranges 0: 2 bits  , 1: 4 bits , 2:8 bits 3: 16 bits 
 * @param[in]    l2_len  : value to decide the l2 pattern lenght .
 *                         Ranges  1 : 1 bits, 2: 2 bits, 3: 4 bits
 *                                 4 : 8 bits, 5: 16 bits, 6: 32 bits
 *                                 0,7: 64 bits 
 * @return       None
 */ 
void RSI_WURX_SetPatternLength(uint8_t enable,uint8_t l1_len,uint8_t l2_len)
{
	   if(enable){
	   /* clear pattern length */
	    WURX_CORR_CALIB_REG &= ~(0x7 << POS15);	  
	    /* pattern length */
	    WURX_CORR_CALIB_REG |= l2_len << POS15;
	    /* set pattern lenght for l1*/		 
      WURX_LEVEL1_PATTERN_REG |= (l1_len << POS20); //2 bits	   pass 1 for 4 bit  
   }else
   {
		  /* disable */
	    WURX_CORR_CALIB_REG &= ~(l2_len << POS15);	  
   }
}
/**
 * @fn           uint16_t RSI_WURX_ReadPatternLength()
 * @brief        This API is used read pattern length
 * @param[in]    None
 * @return       pattern length type.
 */ 
uint16_t RSI_WURX_ReadPatternLength()
{ 	
	    uint16_t value;
	    /* pattern length */
	    value = (WURX_CORR_CALIB_REG & (0x38000))>> POS15;
	    return value;
}

/**
 * @fn           void RSI_WURX_AnalogOff()
 * @brief        This API is used to off the analog block.
 * @param[in]    None
 * @return       None
 */ 
void RSI_WURX_AnalogOff()
{
	volatile uint32_t spareReg=0;	
	WURX_ENABLE_AND_AAC_DET_REG &= ~(BIT(0) ); //0x009E93;
	spareReg = ULP_SPI_MEM_MAP(0x141);
	spareReg &= ~BIT(20);	
	ULP_SPI_MEM_MAP(0x141) = spareReg;
  ULP_SPI_MEM_MAP(0x141) &= ~BIT(21);
	WURX_TEST_MODE_REG |= BIT(19);	
}


/**
 * @fn           void RSI_WURX_DigitalOff()
 * @brief        This API is used to off the digital block.
 * @param[in]    None
 * @return       None
 */ 
void RSI_WURX_DigitalOff()
{
		RSI_IPMU_PowerGateClr(WURX_CORR_PG_ENB | WURX_PG_ENB );
}

void RSI_WURX_ReadPattern1Odd(uint32_t *tail_data)
{
    uint32_t read_tail_data=0; 
    tail_data[0]=WURX_ODD_PATTERN1_REG_LSB;        // 22 bit for LSB
		read_tail_data=WURX_ODD_PATTERN1_REG_MID;
		read_tail_data=(read_tail_data<<22);      
		tail_data[0]=tail_data[0] | read_tail_data;    // 10 bit read
		read_tail_data=0;
		read_tail_data=WURX_ODD_PATTERN1_REG_MID;
		read_tail_data=(read_tail_data>>10);
		tail_data[1]=read_tail_data;                   // 12 bit read	
		read_tail_data=0;
    read_tail_data=WURX_ODD_PATTERN1_REG_MSB;
		read_tail_data=read_tail_data<<12;
		tail_data[1]=tail_data[1]|read_tail_data;     // 20 bit read
}

void RSI_WURX_ReadPattern1Even(uint32_t *tail_data)
{
	 uint32_t read_tail_data=0;		
   tail_data[2]=WURX_EVEN_PATTERN1_REG_LSB;        // 22 bit for LSB
	 read_tail_data=WURX_EVEN_PATTERN1_REG_MID;
	 read_tail_data=(read_tail_data<<22);      
	 tail_data[2]=tail_data[2] | read_tail_data;    // 10 bit read
	 read_tail_data=0;
	 read_tail_data=WURX_EVEN_PATTERN1_REG_MID;
	 read_tail_data=(read_tail_data>>10);
	 tail_data[3]=read_tail_data;                   // 12 bit read	
	 read_tail_data=0;
   read_tail_data=WURX_EVEN_PATTERN1_REG_MSB;
	 read_tail_data=read_tail_data<<12;
	 tail_data[3]=tail_data[3]|read_tail_data;     // 20 bit read	
}

void RSI_WURX_ReadPattern2Odd(uint32_t *tail_data)
{
   uint32_t read_tail_data=0;	 
   tail_data[4]=WURX_ODD_PATTERN2_REG_LSB;        // 22 bit for LSB
	 read_tail_data=WURX_ODD_PATTERN2_REG_MID;
	 read_tail_data=(read_tail_data<<22);      
	 tail_data[4]=tail_data[4] | read_tail_data;    // 10 bit read
	 read_tail_data=0;
	 read_tail_data=WURX_ODD_PATTERN2_REG_MID;
	 read_tail_data=(read_tail_data>>10);
	 tail_data[5]=read_tail_data;                   // 12 bit read	
	 read_tail_data=0;
   read_tail_data=WURX_ODD_PATTERN2_REG_MSB;
	 read_tail_data=read_tail_data<<12;
	 tail_data[5]=tail_data[5]|read_tail_data;     // 20 bit read	
}

void RSI_WURX_ReadPattern2Even(uint32_t *tail_data)
{
   uint32_t read_tail_data=0;	 
   tail_data[6]=WURX_ODD_PATTERN2_REG_LSB;        // 22 bit for LSB
	 read_tail_data=WURX_ODD_PATTERN2_REG_MID;
	 read_tail_data=(read_tail_data<<22);      
	 tail_data[6]=tail_data[6] | read_tail_data;    // 10 bit read
	 read_tail_data=0;
	 read_tail_data=WURX_ODD_PATTERN2_REG_MID;
	 read_tail_data=(read_tail_data>>10);
	 tail_data[7]=read_tail_data;                   // 12 bit read	
	 read_tail_data=0;
   read_tail_data=WURX_ODD_PATTERN2_REG_MSB;
	 read_tail_data=read_tail_data<<12;
	 tail_data[7]=tail_data[7]|read_tail_data;     // 20 bit read	
}

uint16_t RSI_WURX_TaildataPresent()
{
	uint32_t read;
  read = WURX_CORR_CALIB_REG;
	read = read & 0x3 ;
  return read;	
}
