/**
 * @file      rsi_adc.c
 * @version   1.0
 * @date      1 Aug 2017
 *
 *  Copyright(C) Redpine Signals 2017
 *  All rights reserved by Redpine Signals.
 *
 *  @section License
 *  This program should be used on your own responsibility.
 *  Redpine Signals assumes no responsibility for any losses
 *  incurred by customers or third parties arising from the use of this file.
 *
 *  @brief This file contains APIs related to AUX-ADC
 *
 *  @section Description
 *  This file contains APIs relared to Analog to Digital converter peripheral
 *
 *
 */

 /* Includes */
 
#include "rsi_chip.h"
#include "rsi_adc.h"


volatile uint32_t auxadcCalibValueLoad=0 , auxadcCalibValue=0;
volatile uint32_t calib_done=0,cal,impuDummyRead;

 static struct 
 {
	 uint32_t ping_addr[16];
	 uint32_t pong_addr[16];
	 uint16_t ping_length[16];
	 uint16_t pong_length[16];
	 uint32_t ping_mem1[16];
	 uint32_t ping_mem2[16];
	 uint32_t ping_mem3[16];
	 uint32_t pong_mem1[16];
	 uint32_t pong_mem2[16];
	 uint32_t pong_mem3[16];
	 
 }adc_config;

/**
 * @fn           uint32_t RSI_ADC_PingPongMemoryAdrConfig(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel ,uint32_t ping_addr, uint32_t pong_addr,uint16_t ping_length, uint16_t pong_length,uint8_t ping_enable,uint8_t pong_enable )
 * @brief        This API is used to configure Ping-pong memory location along with the length of the samples
 * @param[in]    channel  :ADC channel to be configured as 0,1,2 ...15
 * @param[in]    config   :pointer to the ADC channel configuration structure 
 * @return       execution status 
 *
 */
uint32_t RSI_ADC_PingPongMemoryAdrConfig(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel ,uint32_t ping_addr, uint32_t pong_addr,uint16_t ping_length, uint16_t pong_length,uint8_t ping_enable,uint8_t pong_enable )
{
	adc_config.ping_addr[channel] = ping_addr;
	adc_config.pong_addr[channel] = pong_addr;
	adc_config.ping_length[channel] = ping_length;
	adc_config.pong_length[channel] = pong_length;
	
	if(ping_addr == pong_addr)
	{
		return ERROR_PING_PONG_ADDR_MATCH;	
	}else
  {	
	if(ping_enable)
	{
		ping_addr = ping_addr + ((ping_length)*2) ;
    pstcADC->ADC_INT_MEM_1_b.PROG_WR_DATA = 	ping_addr	;
	  adc_config.ping_mem1[channel] = pstcADC->ADC_INT_MEM_1_b.PROG_WR_DATA;
    
		pstcADC->ADC_INT_MEM_2 = 1 << pos15 | (2*channel  ) << pos10 | ping_length << pos0;
		adc_config.ping_mem2[channel] = pstcADC->ADC_INT_MEM_2;
    
		pstcADC->ADC_INT_MEM_2 =  (2*channel) << pos10 | ping_length << pos0;
		adc_config.ping_mem3[channel] = pstcADC->ADC_INT_MEM_2;	
	}
	if(pong_enable){
		pong_addr = pong_addr + ( (pong_length)*2) ;
    pstcADC->ADC_INT_MEM_1_b.PROG_WR_DATA = 	pong_addr	;
	  adc_config.pong_mem1[channel] = pstcADC->ADC_INT_MEM_1_b.PROG_WR_DATA;
    
		pstcADC->ADC_INT_MEM_2 = 1 << pos15 | (2*channel +1  ) << 10 | pong_length << pos0;
		adc_config.pong_mem2[channel] = pstcADC->ADC_INT_MEM_2;
		
    pstcADC->ADC_INT_MEM_2 =  ( 2*channel + 1 ) << 10 | pong_length << pos0;	
		adc_config.pong_mem3[channel] = pstcADC->ADC_INT_MEM_2;	
		
	 }
  }
	return RSI_OK;
}

/**
 * @fn           uint32_t RSI_ADC_PingPongReInit(AUX_ADC_DAC_COMP_Type *pstcADC, uint8_t ping_enable,uint8_t pong_enable )
 * @brief        This API is used to configure Ping-pong memory location along with the length of the samples
 * @param[in]    channel  :ADC channel to be configured as 0,1,2 ...15
 * @return       execution status 
 *
 */
void RSI_ADC_PingPongReInit(AUX_ADC_DAC_COMP_Type *pstcADC, uint8_t channel,uint8_t ping_enable,uint8_t pong_enable )
{
	if(ping_enable)
	{
		 pstcADC->ADC_INT_MEM_1_b.PROG_WR_DATA =  adc_config.ping_mem1[channel];
		 pstcADC->ADC_INT_MEM_2 = adc_config.ping_mem2[channel];
		 pstcADC->ADC_INT_MEM_2 = adc_config.ping_mem3[channel];
	}
	if(pong_enable)
	{
		pstcADC->ADC_INT_MEM_1_b.PROG_WR_DATA =  adc_config.pong_mem1[channel];
		pstcADC->ADC_INT_MEM_2 = adc_config.pong_mem2[channel] ;
		pstcADC->ADC_INT_MEM_2 = adc_config.pong_mem3[channel];
	}
} 


void RSI_ADC_Calibration()
{
	volatile uint32_t  impuDummyRead;
  
	AUX_ADC_DAC_COMP->AUXADC_CTRL_1_b.ADC_ENABLE |= 1U;
	AUX_ADC_DAC_COMP->AUXADC_CONFIG_2 |= BIT(10);

	impuDummyRead = ULP_SPI_MEM_MAP(0);
	if(calib_done==0)
	{
//	cal = ULP_SPI_MEM_MAP(0x110);	
//	ULP_SPI_MEM_MAP(0x110)  = cal ;	
	ULP_SPI_MEM_MAP(0x110) |= BIT(11);
	while(GSPI_CTRL_REG1 & SPI_ACTIVE);	
	/*Wait for 1*/
  while(!(ULP_SPI_MEM_MAP(0x1C1) & BIT(0)));
  /*wait for 0*/
  while((ULP_SPI_MEM_MAP(0x1C1) & BIT(0)));	
	/*150 clocks of 1 Mhz wait*/
  auxadcCalibValue = ULP_SPI_MEM_MAP(0x112);
  auxadcCalibValueLoad |= BIT(0) | BIT(7);
  auxadcCalibValueLoad |= (auxadcCalibValue & 0x1F) <<2;
  auxadcCalibValueLoad |= (((auxadcCalibValue >> 6) & 0x1F) << 8);
  auxadcCalibValueLoad |= (((auxadcCalibValue >> 11) & 0x1F) << 13);
	calib_done = 1;
	}
 else{
 }	 
  ULP_SPI_MEM_MAP(0x111) = (auxadcCalibValueLoad);
  while(GSPI_CTRL_REG1 & SPI_ACTIVE);
	AUX_ADC_DAC_COMP->AUXADC_CTRL_1_b.ADC_ENABLE = 0;
}

//void RSI_ADC_Calibration()
//{
//	
//	ADC_DAC->AUXADC_CTRL_1_b.ADC_ENABLE |= 1U;
//	impuDummyRead = ULP_SPI_MEM_MAP(0);
//	cal = ULP_SPI_MEM_MAP(0x110);	
//	ULP_SPI_MEM_MAP(0x110)  = cal ;	
//	ULP_SPI_MEM_MAP(0x110) |= BIT(11);
//	ULP_SPI_MEM_MAP(0x110)  = cal ;	
//	ULP_SPI_MEM_MAP(0x110) |= BIT(11);	
//	ADC_DAC->AUXADC_CTRL_1_b.ADC_ENABLE |= 0;
//}

/**
 * @fn           uint32_t RSI_ADC_PingpongEnable(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel)
 * @brief        This API is used to Enable ping pong for corresponding ADC channels 
 * @param[in]    channel  :ADC channel to be configured as 0,1,2 ...15
 * @param[in]    config   :pointer to the ADC channel configuration structure 
 * @return       execution status 
 *
 */
uint32_t RSI_ADC_PingpongEnable(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel)
{
	pstcADC->ADC_SEQ_CTRL_b.ADC_SEQ_CTRL_PING_PONG |= 1 << channel;	
	return RSI_OK;
}

/**
 * @fn           uint32_t RSI_ADC_InternalPerChnlDmaEnable(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel)
 * @brief        This API is used to Enable ping pong for corresponding ADC channels 
 * @param[in]    channel  :ADC channel to be configured as 0,1,2 ...15
 * @param[in]    config   :pointer to the ADC channel configuration structure 
 * @return       execution status 
 *
 */
uint32_t RSI_ADC_InternalPerChnlDmaEnable(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel)
{
	pstcADC->ADC_SEQ_CTRL_b.ADC_SEQ_CTRL_DMA_MODE  |= 1 << channel;	
	return RSI_OK;
}

/**
 * @fn           void RSI_ADC_Config(AUX_ADC_DAC_COMP_Type *pstcADC,uint8_t multi_channel_en, uint8_t static_fifo_mode, uint8_t fifo_threshold )
 * @brief        This API is used to configure the ADC channels 
 * @param[in]    config   :pointer to the ADC channel configuration structure 
 * @return       NONE 
 *
 */
void RSI_ADC_Config(AUX_ADC_DAC_COMP_Type *pstcADC,uint8_t multi_channel_en, uint8_t static_fifo_mode, uint8_t fifo_threshold, uint8_t internal_dma_en )
{
	pstcADC->AUXADC_CTRL_1_b.ADC_NUM_PHASE |= 1;
	pstcADC->AUXADC_CTRL_1_b.ADC_MULTIPLE_CHAN_ACTIVE |= multi_channel_en ; 
	pstcADC->AUXADC_CTRL_1_b.ADC_STATIC_MODE |= static_fifo_mode  ;
			
	pstcADC->AUXADC_CTRL_1_b.ADC_FIFO_THRESHOLD |= fifo_threshold;
	pstcADC->AUXADC_CTRL_1_b.ADC_FIFO_FLUSH |= 1;
	pstcADC->INTERNAL_DMA_CH_ENABLE_b.INTERNAL_DMA_ENABLE |= internal_dma_en;	
}


/**
 * @fn           uint32_t RSI_ADC_ChannelConfig(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel , uint8_t an_perif_adc_ip_sel,uint8_t an_perif_adc_in_sel, uint8_t an_perif_adc_diffmode )
 * @brief        This API is used to configure the ADC channels 
 * @param[in]    channel  :ADC channel to be configured as 0,1,2 ...15
 * @param[in]    config   :pointer to the ADC channel configuration structure 
 * @return       channel configuration 
 *
 */
uint32_t RSI_ADC_ChannelConfig(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel , uint8_t an_perif_adc_ip_sel,uint8_t an_perif_adc_in_sel, uint8_t an_perif_adc_diffmode )
{
	
	if(an_perif_adc_diffmode)
	{		
		pstcADC->ADC_CH_BIT_MAP_CONFIG[channel].ADC_CH_BIT_MAP_CONFIG_0_b.CHANNEL_BITMAP  |= an_perif_adc_diffmode   << pos26  |
		                                                                                     an_perif_adc_in_sel     << pos22 ;
  }		   			
	pstcADC->ADC_CH_BIT_MAP_CONFIG[channel].ADC_CH_BIT_MAP_CONFIG_0_b.CHANNEL_BITMAP    |= an_perif_adc_ip_sel << pos17  ;
   
  return RSI_OK;
}	
/**
 * @fn           uint32_t RSI_ADC_ChannelSamplingRate(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel )
 * @brief        This API is used to configure the ADC channels 
 * @param[in]    channel  :ADC channel to be configured as 0,1,2 ...15
 * @param[in]    adc_ch_offset     : channel offset for each channel 
 * @param[in]    adc_ch_freq_val   : channel frequency for each channel to set sampling rate
 * @return       execution status 
 *
 */
uint32_t RSI_ADC_ChannelSamplingRate(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel , uint16_t adc_ch_offset, uint16_t adc_ch_freq_val)
{
	if(adc_ch_freq_val==1)
	{
		//return ERROR_FREQ_VAL;
	}	
	pstcADC->ADC_CH_OFFSET_b[channel].CH_OFFSET |= adc_ch_offset ;
	pstcADC->ADC_CH_FREQ_b[channel].CH_FREQ_VALUE |= adc_ch_freq_val ; //fifo for channel 0 freq val is 1 offset is 0
	
	return RSI_OK;
}



/**
 * @fn           uint32_t RSI_ADC_StaticMode(AUX_ADC_DAC_COMP_Type *pstcADC, adc_config *config)
 * @brief        This API is used to configure the ADC in Static Mode 
 * @param[in]    config   :pointer to the ADC channel configuration structure 
 * @return       execution status 
 *
 */

uint32_t RSI_ADC_StaticMode(AUX_ADC_DAC_COMP_Type *pstcADC,uint16_t an_perif_adc_ip_sel, uint16_t an_perif_adc_in_sel, uint8_t an_perif_adc_diffmode)
{
	pstcADC->AUXADC_CTRL_1_b.ADC_NUM_PHASE |= 1;
 
	pstcADC->AUXADC_CTRL_1_b.ADC_STATIC_MODE |= 1 ;
	pstcADC->AUXADC_CONFIG_2 |= BIT(10);
	if(an_perif_adc_diffmode)
	{
		pstcADC->AUXADC_CONFIG_1_b.AUXADC_DIFF_MODE |= an_perif_adc_diffmode;
		pstcADC->AUXADC_CONFIG_1_b.AUXADC_INN_SEL   |= an_perif_adc_in_sel ;
	}
	pstcADC->AUXADC_CONFIG_1_b.AUXADC_INP_SEL   |= an_perif_adc_in_sel ;
	
	return RSI_OK;
}

/**
 * @fn           uint32_t RSI_ADC_FifoMode(AUX_ADC_DAC_COMP_Type *pstcADC,uint16_t an_perif_adc_ip_sel, uint16_t an_perif_adc_in_sel, uint8_t an_perif_adc_diffmode)
 * @brief        This API is used to configure the ADC in Static Mode 
 * @param[in]    config   :pointer to the ADC channel configuration structure 
 * @return       execution status 
 *
 */
uint32_t RSI_ADC_FifoMode(AUX_ADC_DAC_COMP_Type *pstcADC,uint16_t an_perif_adc_ip_sel, uint16_t an_perif_adc_in_sel, uint8_t an_perif_adc_diffmode)
{
	pstcADC->AUXADC_CTRL_1_b.ADC_NUM_PHASE |= 1;
	
	pstcADC->INTERNAL_DMA_CH_ENABLE_b.PER_CHANNEL_ENABLE  |= 1 << 0;	
	
	//pstcADC->AUXADC_CONFIG_2 |= BIT(10);
	
	if(an_perif_adc_diffmode)
	{
		pstcADC->AUXADC_CONFIG_1_b.AUXADC_DIFF_MODE |= an_perif_adc_diffmode;
		pstcADC->AUXADC_CONFIG_1_b.AUXADC_INN_SEL   |= an_perif_adc_in_sel ;
	}
	pstcADC->AUXADC_CONFIG_1_b.AUXADC_INP_SEL   |= an_perif_adc_ip_sel ;
	
	return RSI_OK;
}



/**
 * @fn           uint32_t RSI_ADC_Start( AUX_ADC_DAC_COMP_Type *pstcADC )
 * @brief        This API is used to start the ADC
 * @param[in]    channel  :ADC channel to be configured as 0,1,2 ...15
 * @return       execution status 
 *
 */
uint32_t RSI_ADC_Start( AUX_ADC_DAC_COMP_Type *pstcADC )
{
	pstcADC->AUXADC_CONFIG_2_b.AUXADC_CONFIG_ENABLE |= 1U;
	pstcADC->AUXADC_CTRL_1_b.ADC_ENABLE |= 1U;
	return RSI_OK;
}

/**
 * @fn           uint32_t RSI_ADC_Stop( AUX_ADC_DAC_COMP_Type *pstcADC )
 * @brief        This API is used to stop the ADC
 * @param[in]    channel  :ADC channel to be configured as 0,1,2 ...15
 * @return       execution status 
 *
 */
uint32_t RSI_ADC_Stop( AUX_ADC_DAC_COMP_Type *pstcADC )
{
	pstcADC->AUXADC_CONFIG_2_b.AUXADC_CONFIG_ENABLE = 0;
	pstcADC->AUXADC_CTRL_1_b.ADC_ENABLE = 0;
  return RSI_OK;
}

/**
 * @fn           uint32_t RSI_ADC_ChnlEnable(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel)
 * @brief        This API is used to Enable the ADC
 * @param[in]    channel  :ADC channel to be configured as 0,1,2 ...15
 * @return       execution status 
 *
 */
uint32_t RSI_ADC_ChnlEnable(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel)
{
	if(pstcADC->AUXADC_CTRL_1_b.ADC_MULTIPLE_CHAN_ACTIVE == 1)
	{
	pstcADC->INTERNAL_DMA_CH_ENABLE_b.PER_CHANNEL_ENABLE  |= 1 << channel;
	}
	else{
	return ERROR_NO_MULTI_CHNL_ENABLE;
	}
  return RSI_OK;
}

/**
 * @fn           uint32_t RSI_ADC_ChnlDisable(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel)
 * @brief        This API is used to Disable the ADC
 * @param[in]    channel  :ADC channel to be configured as 0,1,2 ...15
 * @return       execution status 
 *
 */
uint32_t RSI_ADC_ChnlDisable(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel)
{
  pstcADC->INTERNAL_DMA_CH_ENABLE_b.PER_CHANNEL_ENABLE  &= ~( 1 << channel);
  return RSI_OK;
}

/**
 * @fn           uint32_t RSI_ADC_ReadDataStatic(AUX_ADC_DAC_COMP_Type *pstcADC)
 * @brief        This API is used to Read the ADC samples when static mode is enabled.
 * @param[out]   data     :Pointer to read buffer 
 * @param[in]    config   :pointer to the ADC channel configuration structure 
 * @return       execution status 
 *
 */
uint32_t RSI_ADC_ReadDataStatic(AUX_ADC_DAC_COMP_Type *pstcADC)
{	
   return pstcADC->AUXADC_DATA_b.AUXADC_DATA;
}
/**
 * @fn           uint32_t RSI_ADC_ReadData(AUX_ADC_DAC_COMP_Type *pstcADC, uint16_t *data, adc_config *config, uint8_t ping_pong)
 * @brief        This API is used to Read the ADC samples when ulp memories are used.
 * @param[out]   data     :Pointer to read buffer 
 * @param[in]    config   :pointer to the ADC channel configuration structure 
 * @param[in]    ping_pong: 1 - ping memory must be read
                            0 - pong memory must be read
 * @return       execution status 
 *
 */
uint32_t RSI_ADC_ReadData(AUX_ADC_DAC_COMP_Type *pstcADC, uint16_t *data, uint8_t ping_pong,uint16_t channel)
{
	uint32_t i;
  
	  if(ping_pong)
		{			
   		for(i=0;i< adc_config.ping_length[channel]; i++)
		  {
		    data[i] = *(volatile uint32_t *)(adc_config.ping_addr[channel] + i*2 );
	   	}
		}else{
			for(i=0;i<adc_config.pong_length[channel]; i++)
		  {
		    data[i] = *(volatile uint32_t *)(adc_config.pong_addr[channel] + i*2 );
		  }
		}
	
	return RSI_OK;
}


/**
 * @fn           uint32_t RSI_ADC_ClkConfig(AUX_ADC_DAC_COMP_Type *pstcADC, uint16_t adc_on_time , uint16_t adc_total_duration,adc_config *config)
 * @brief        This API is used to set clock with configurable on time 
 * @param[in]    adcOnTime        :ON duration of the clock 
 * @param[in]    adcTotalDuration :Total ON and OFF duration of the clock
 * @param[in]    config   :pointer to the ADC channel configuration structure 
 * @return       execution status 
 * @note         mininum ON time is 15us if opamp comes into picture.
 *               adc should maintain minimum off time of 200ns.
 * When 1mhz is adc clk to obtain 15us on time adc_on_time must be programmed to 15 i.e. 15 clocks.
 * adc_total_duration = total clock duration i.e adc_on_time + adc_off time dution. (15 + 1) clocks
 */

uint32_t RSI_ADC_ClkDivfactor(AUX_ADC_DAC_COMP_Type *pstcADC, uint16_t adc_on_time , uint16_t adc_total_duration)
{
	pstcADC->AUXADC_CTRL_1_b.EN_ADC_CLK |= 0;
	pstcADC->AUXADC_CLK_DIV_FAC_b.ADC_CLK_ON_DUR |= adc_on_time;
	pstcADC->AUXADC_CLK_DIV_FAC_b.ADC_CLK_DIV_FAC |= adc_total_duration;
	pstcADC->AUXADC_CTRL_1_b.EN_ADC_CLK |= 1;
	
  return RSI_OK;
}

/**
 * @fn           uint32_t RSI_ADC_ChnlIntrMask(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel)
 * @brief        This API is used to Mask the ADC channel
 * @param[in]    channel  :ADC channel to be configured as 0,1,2 ...15
 * @return       execution status 
 *
 */
uint32_t RSI_ADC_ChnlIntrMask(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel)
{
	if(AUX_ADC_DAC_COMP->AUXADC_CTRL_1_b.ADC_MULTIPLE_CHAN_ACTIVE)
	{
	 pstcADC->INTR_MASK_REG_b.FIRST_MEM_SWITCH_INTR_MASK &=~(1 << channel);
	}else{
	 // pstcADC->INTR_MASK_REG &= ~( BIT(4) | BIT(3) ); 
		
		pstcADC->INTR_MASK_REG_b.ADC_FIFO_AFULL_INTR_MASK = 0;
		pstcADC->INTR_MASK_REG_b.ADC_FIFO_FULL_INTR_MASK = 0;
	}
	
	return RSI_OK;	
}

/**
 * @fn           uint32_t RSI_ADC_ChnlIntrMask(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel)
 * @brief        This API is used to Mask the ADC channel
 * @param[in]    channel  :ADC channel to be configured as 0,1,2 ...15
 * @return       execution status 
 *
 */
uint32_t RSI_ADC_ChnlIntrUnMask(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel)
{
	pstcADC->INTR_MASK_REG_b.FIRST_MEM_SWITCH_INTR_MASK |=(1 << channel);
	return RSI_OK;
		
}

/**
 * @fn           uint32_t RSI_ADC_ChnlIntrClr(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel)
 * @brief        This API is used to clr the ADC channel
 * @param[in]    channel  :ADC channel to be configured as 2^n where n = channel number = 0,1,2,3...15
 * @return       execution status 
 *
 */
uint32_t RSI_ADC_ChnlIntrClr(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel)
{

	 pstcADC->INTR_CLEAR_REG_b.INTR_CLEAR_REG |= (1 << (channel-1));
	 pstcADC->INTR_CLEAR_REG_b.INTR_CLEAR_REG &= ~(1 << (channel-1));
   return RSI_OK;
}

/**
 * @fn           uint32_t RSI_ADC_ChnlIntrStatus(AUX_ADC_DAC_COMP_Type *pstcADC, uint32_t channel)
 * @brief        This API is used to status the ADC channel
 * @param[in]    channel  :ADC channel to be configured as 0,1,2 ...15
 * @return       execution status 
 *
 */
uint32_t RSI_ADC_ChnlIntrStatus(AUX_ADC_DAC_COMP_Type *pstcADC)
{
	return pstcADC->INTR_STATUS_REG_b.FIRST_MEM_SWITCH_INTR;
}
/**
 * @fn           uint32_t RSI_ADC_PowerControl(POWER_STATE state)
 * @brief        This API is used to Power On and off for ADC
 * @param[in]    state : ADC_POWER_ON - To powerup adc powergates
                         ADC_POWER_OFF - To powerdown adc powergates
 * @return       execution status 
 *
 */
void RSI_ADC_PowerControl(POWER_STATE state)
{
  switch(state)
	{
		case ADC_POWER_ON  :
		RSI_IPMU_PowerGateSet(AUXADC_PG_ENB);
		RSI_PS_UlpssPeriPowerUp(ULPSS_PWRGATE_ULP_AUX);
		break;
		case ADC_POWER_OFF :
		RSI_IPMU_PowerGateClr( AUXADC_PG_ENB  );
		break;
	}
}

/**
 * @fn           uint32_t RSI_ADC_NoiseAvgMode(AUX_ADC_DAC_COMP_Type *pstcADC, bool en_disable)
 * @brief        This API is used to Enable or Disable Noise averaging mode
 * @param[in]    en_disable : 1 - To enable noise averaging mode
                              0 - To disable noise averaging mode           
 * @return       execution status 
 * @NOTE:         When noise averaging mode is enabled adc gives more accurate values as output.
 * For example : When voltage of 1.37V is given the output is 0x21D. 
 *               When this mode is enabled accurate value of 0x223 is obtained.
 *
 */
uint32_t RSI_ADC_NoiseAvgMode(AUX_ADC_DAC_COMP_Type *pstcADC, bool en_disable)
{
	pstcADC->AUXADC_CTRL_1_b.BYPASS_NOISE_AVG = en_disable;
	ULP_SPI_MEM_MAP(0x110) = en_disable << pos17 ;
	return RSI_OK;
}

/**
 * @fn           uint32_t RSI_ADC_TempSensorEnable(AUX_ADC_DAC_COMP_Type *pstcADC)
 * @brief        This API is used to Enable temp-Sensor 
 * @return       execution status 
 * @NOTE         ADC must be in static mode to check temperature measurement
 *
 */
uint32_t RSI_ADC_TempSensorEnable(AUX_ADC_DAC_COMP_Type *pstcADC)
{
	pstcADC->TS_PTAT_ENABLE_b.TS_PTAT_EN |= 1U;
	return RSI_OK;
}

/**
 * @fn           uint32_t RSI_ADC_ThresholdConfig(AUX_ADC_DAC_COMP_Type *pstcADC , uint32_t threshold1,uint32_t threshold2, uint8_t range)
 * @brief        This API is used to compare threshold value with adc data 
 * @param[in]    threshold1  : threshold value to be programmed
 * @param[in]    threshold2  : threshold value to be programmed when range is 1 
 * @param[in]    range       : When adc data compared lies in certain range of threshold values set this bit
 * @return       execution status 
 * NOTE          threshold1 and  threshold2 are programmed to set upper and lower limits of the adc output. 
 *               When the output is within this limits an interrupt is rised.
 *
 */

uint32_t RSI_ADC_ThresholdConfig(AUX_ADC_DAC_COMP_Type *pstcADC , uint32_t threshold1,uint32_t threshold2, uint8_t range)
{
	pstcADC->ADC_DET_THR_CTRL_0_b.ADC_INPUT_DETECTION_THRESHOLD_0 |= threshold1;
	pstcADC->ADC_DET_THR_CTRL_0_b.ADC_INPUT_DETECTION_THRESHOLD_1 |= (threshold1 >> 8) ; 
	
	if((pstcADC->ADC_DET_THR_CTRL_0_b.ADC_INPUT_DETECTION_THRESHOLD_0  | (pstcADC->ADC_DET_THR_CTRL_0_b.ADC_INPUT_DETECTION_THRESHOLD_1<<9)) >= pstcADC->AUXADC_DATA_b.AUXADC_DATA )
	{
		if((pstcADC->ADC_DET_THR_CTRL_0_b.ADC_INPUT_DETECTION_THRESHOLD_0 | (pstcADC->ADC_DET_THR_CTRL_0_b.ADC_INPUT_DETECTION_THRESHOLD_1<<9)) == pstcADC->AUXADC_DATA_b.AUXADC_DATA )
		{
			pstcADC->ADC_DET_THR_CTRL_0_b.COMP_EQ_EN |= 1;
		}else{
			pstcADC->ADC_DET_THR_CTRL_0_b.COMP_GRTR_THAN_EN |= 1;	
		}	
	}else{	
		pstcADC->ADC_DET_THR_CTRL_0_b.COMP_LESS_THAN_EN |= 1;
	}
	
	if(range)
	{
		pstcADC->ADC_DET_THR_CTRL_1_b.ADC_INPUT_DETECTION_THRESHOLD_2 |= threshold2;
		pstcADC->ADC_DET_THR_CTRL_1_b.ADC_DETECTION_THRESHOLD_2_UPPER_BITS |= ( threshold2 >> 8 );
		
	  if((pstcADC->ADC_DET_THR_CTRL_1_b.ADC_INPUT_DETECTION_THRESHOLD_2  | (pstcADC->ADC_DET_THR_CTRL_0_b.ADC_INPUT_DETECTION_THRESHOLD_1<<9)) >= pstcADC->AUXADC_DATA_b.AUXADC_DATA )
	  {
		  if((pstcADC->ADC_DET_THR_CTRL_1_b.ADC_INPUT_DETECTION_THRESHOLD_2 | (pstcADC->ADC_DET_THR_CTRL_0_b.ADC_INPUT_DETECTION_THRESHOLD_1<<9)) == pstcADC->AUXADC_DATA_b.AUXADC_DATA )
		  {
			 pstcADC->ADC_DET_THR_CTRL_1_b.COMP_EQ_EN |= 1;
		  }else{
			 pstcADC->ADC_DET_THR_CTRL_1_b.COMP_GRTR_THAN_EN |= 1;	
		  }	
	  }else{	
		  pstcADC->ADC_DET_THR_CTRL_1_b.COMP_LESS_THAN_EN |= 1;
	  }	
	}
	
	return RSI_OK;
}

/**
 * @fn           uint32_t RSI_ADC_Bbp(AUX_ADC_DAC_COMP_Type *pstcADC ,uint8_t adc_bbp_en, uint8_t bbp_en, uint8_t bbp_id)
 * @brief        This API is used for baseband
 * @param[in]    adc_bbp_en : To enable adc to bbp path
 * @param[in]    bbp_en     : Adc samples are given to bbp
 * @param[in]    bbp_id     : Channel id for bbp samples
 * @return       execution status 
 *
 */

uint32_t RSI_ADC_Bbp(AUX_ADC_DAC_COMP_Type *pstcADC ,uint8_t adc_bbp_en, uint8_t bbp_en, uint8_t bbp_id)
{
	pstcADC->VAD_BBP_ID_b.AUX_ADC_BPP_EN = adc_bbp_en;
	pstcADC->VAD_BBP_ID_b.BPP_EN         = bbp_en ;
	pstcADC->VAD_BBP_ID_b.BPP_ID         = bbp_id ;
	
	return RSI_OK;
}

/**
 * @fn          void RSI_ADC_InterruptHandler( AUX_ADC_DAC_COMP_Type *pstcADC,RSI_ADC_CALLBACK_T *pADCCallBack)
 * @brief		    Handles all interrupt of ADC
 * @param[in]	  pstcADC    Pointer to the MCPWM instance register area
 * @param[in]	  pADCCallBack Pointer to the structure of type RSI_CALLBACK
*/
void RSI_ADC_InterruptHandler( AUX_ADC_DAC_COMP_Type *pstcADC,RSI_ADC_CALLBACK_T *pADCCallBack)
{
	uint32_t channel_no =0;
	
	if((pADCCallBack->adccallbacFunc) == NULL)
	{
		//return ERROR_ADC_INVALID_ARG;
	}
		
	if( AUX_ADC_DAC_COMP->AUXADC_CTRL_1_b.ADC_MULTIPLE_CHAN_ACTIVE)
	{
		channel_no = RSI_ADC_ChnlIntrStatus(AUX_ADC_DAC_COMP);
	  RSI_ADC_ChnlIntrClr(AUX_ADC_DAC_COMP,channel_no);
		pADCCallBack ->adccallbacFunc(channel_no  , MULTI_CHANNEL_EVENT);
	}
	if(!(AUX_ADC_DAC_COMP->AUXADC_CTRL_1_b.ADC_STATIC_MODE))
	{
		AUX_ADC_DAC_COMP->AUXADC_CTRL_1_b.ADC_FIFO_FLUSH = 1;
		pADCCallBack ->adccallbacFunc(channel_no  , FIFO_MODE_EVENT);
	}	
}	

