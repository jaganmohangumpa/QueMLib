/* -------------------------------------------------------------------------- 
 * Copyright (c) 2013-2016 ARM Limited. All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the License); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * $Date:        02. March 2016
 * $Revision:    V1.1
 *
 * Project:      USB common (Device and Host) module for NXP LPC18xx
 * -------------------------------------------------------------------------- */

/* History:
 *  Version 1.1
 *    Improved support for Host and Device
 *  Version 1.0
 *    Initial release
 */

#include "rsi_chip.h"

#include "Driver_USB.h"
#include "USB.h"
#include "RTE_Device.h"
#include "RTE_Components.h"

volatile uint8_t USB_role  = ARM_USB_ROLE_NONE;
volatile uint8_t USB_state = 0U;

#ifdef RTE_Drivers_USBH0
extern void USBH0_IRQ (void);
#endif
#ifdef RTE_Drivers_USBD0
extern void USBD0_IRQ (void);
#endif


// Common IRQ Routine **********************************************************

/**
  \fn          void IRQ073_Handler (void)
  \brief       USB Interrupt Routine (IRQ).
*/
void IRQ073_Handler (void) {
#if(defined(RTE_Drivers_USBH0) && defined(RTE_Drivers_USBD0))
  switch (USB_role) {
#ifdef RTE_Drivers_USBH0
    case ARM_USB_ROLE_HOST:
      USBH_IRQ ();
      break;
#endif
#ifdef RTE_Drivers_USBD0
    case ARM_USB_ROLE_DEVICE:
      USBD_IRQ ();
      break;
#endif
    default:
      break;
  }
#else
#ifdef RTE_Drivers_USBH0
  USBH_IRQ ();
#else
  USBD_IRQ ();
#endif
#endif
}


// Public Functions ************************************************************

/**
  \fn          void USB_PinsConfigure (void)
  \brief       Configure USB pins
*/
void USB_PinsConfigure (void) {

  // Common (Device and Host) Pins
#if (RTE_USB0_IND0_PIN_EN)
#endif

#if (RTE_USB0_IND1_PIN_EN)
#endif

  // Host Pins
  if (USB_role == ARM_USB_ROLE_HOST) {
#if (RTE_USB0_PPWR_PIN_EN)
#endif

#if (RTE_USB0_PWR_FAULT_PIN_EN)
#endif
  }
}

/**
  \fn          void USB0_PinsUnconfigure (void)
  \brief       De-configure USB pins
*/
void USB_PinsUnconfigure (void) {

  // Common (Device and Host) Pins
#if (RTE_USB0_IND0_PIN_EN)
#endif
#if (RTE_USB0_IND1_PIN_EN)
#endif

  // Host Pins
  if (USB_role == ARM_USB_ROLE_HOST) {
#if (RTE_USB0_PPWR_PIN_EN)
#endif
#if (RTE_USB0_PWR_FAULT_PIN_EN)
#endif
  }
}
