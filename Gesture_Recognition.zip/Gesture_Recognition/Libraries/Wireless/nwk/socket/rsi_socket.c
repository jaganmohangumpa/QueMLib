/**
 * @file     rsi_socket.c
 * @version  0.1
 * @date     15 Aug 2015
 *
 *  Copyright(C) Redpine Signals 2015
 *  All rights reserved by Redpine Signals.
 *
 *  @section License
 *  This program should be used on your own responsibility.
 *  Redpine Signals assumes no responsibility for any losses
 *  incurred by customers or third parties arising from the use of this file.
 *
 *  @brief : This file contains socket APIs
 *
 *  @section Description  This file contains socket APIs
 *
 *
 */
#include "rsi_driver.h"
#include "rsi_wlan_non_rom.h"


//! Socket information pool pointer
rsi_socket_info_t *rsi_socket_pool;
extern rsi_wlan_cb_non_rom_t wlan_cb_non_rom;

/*==============================================*/
/**
 * @fn         int32_t rsi_socket_async(int32_t protocolFamily, int32_t type, int32_t protocol, void (*callback)(uint32_t sock_no, uint8_t *buffer, uint32_t length))
 * @brief      Creates socket
 * @param[in]  protocolFamily , Type of the socket family to create
 * @param[in]  type , type of the socket to create 
 * @param[in]  protocol , to enable SSL over TCP 
 * @param[in]  callback , callback function to read data ayncronously from socket 
 *
 * @param[out] None
 * @return     
 *             <0 - If fails
 *             >= - If success
 *
 * @section description
 * This function creates socket
 *
 */

int32_t  rsi_socket_async(int32_t protocolFamily, int32_t type, int32_t protocol, void (*callback)(uint32_t sock_no, uint8_t *buffer, uint32_t length))
{
#ifdef ROM_WIRELESS
  return ROMAPI_WL->socket_async(global_cb_p, protocolFamily, type, protocol, callback);
#else
  return api_wl->socket_async(global_cb_p, protocolFamily, type, protocol, callback);
#endif

}
/*==============================================*/
/**
 * @fn          int32_t rsi_socket(int32_t protocolFamily, int32_t type, int32_t protocol)
 * @brief       Creates socket
 * @param[in]   protocolFamily , Type of the socket family to create
 * @param[in]   type , type of the socket to create 
 * @param[in]   protocol , to enable SSL over TCP 
 * @param[out]  None
 * @return      
 *              <0  - If fails
 *              >=0 - If success
 *
 * @section description
 * This function creates socket
 *
 */

int32_t rsi_socket(int32_t protocolFamily, int32_t type, int32_t protocol)
{
	if (protocol  & BIT(0))
	{
		if(protocol & BIT(13))
		{	
			wlan_cb_non_rom.tls_version = (RSI_SOCKET_FEAT_SSL | RSI_SSL_V_1_0);
		}
		else if (protocol & BIT(14))			
		{
			wlan_cb_non_rom.tls_version = (RSI_SOCKET_FEAT_SSL | RSI_SSL_V_1_1);
		}
		else if (protocol & BIT(15))
		{
			wlan_cb_non_rom.tls_version = (RSI_SOCKET_FEAT_SSL |RSI_SSL_V_1_2);
		}
		else
		{
			wlan_cb_non_rom.tls_version = RSI_SOCKET_FEAT_SSL;
		}
	}


#ifdef ROM_WIRELESS
	return ROMAPI_WL->socket_async(global_cb_p, protocolFamily, type, protocol, NULL);
#else
	return api_wl->socket_async(global_cb_p, protocolFamily, type, protocol, NULL);
#endif

}

/*==============================================*/
/**
 * @fn          int32_t  rsi_bind(int32_t sockID, struct rsi_sockaddr *localAddress, int32_t addressLength)
 * @brief       Assign address to socket
 * @param[in]   sockID, socket descriptor
 * @param[in]   localAddress, address which needs to be assign 
 * @param[in]   addressLength, length of the socket address 
 * @param[out]  None
 * @return
 *              <0 - If fails
 *               0 - If success
 *
 * @section description
 * This assigns address to the socket
 *
 *
 */
int32_t  rsi_bind(int32_t sockID, struct rsi_sockaddr *localAddress, int32_t addressLength)
{
#ifdef ROM_WIRELESS
  return ROMAPI_WL->bind(global_cb_p, sockID, localAddress, addressLength);
#else
  return api_wl->bind(global_cb_p, sockID, localAddress, addressLength);
#endif
}
/*==============================================*/
/**
 * @fn          int32_t  rsi_connect(int32_t sockID, struct rsi_sockaddr *remoteAddress, int32_t addressLength)
 * @brief       connect the socket to specified remoteAddress
 * @param[in]   sockID, socket descriptor 
 * @param[in]   remoteAddress, remote peer address structure 
 * @param[in]   addressLength, remote peer address structrue length 
 * @param[out]  None
 * @return
 *
 *              <0 - If fails
 *               0 - If success
 *
 * @section description
 * This function is use to connect the socket to specified remote address
 *
 */

int32_t  rsi_connect(int32_t sockID, struct rsi_sockaddr *remoteAddress, int32_t addressLength)
{
#ifdef ROM_WIRELESS
  return ROMAPI_WL->connect(global_cb_p, sockID, remoteAddress, addressLength);
#else
  return api_wl->connect(global_cb_p, sockID, remoteAddress, addressLength);
#endif
}
/*==============================================*/
/**
 * @fn         int32_t  rsi_listen(int32_t sockID, int32_t backlog)
 * @brief      This function is used to make socket to listen for remote connecion request in passive mode
 * @param[in]  sockID, socket descriptor 
 * @param[in]  backlog, maximum number of pending connections requests 
 * @param[out] None
 * @return
 *              <0 - If fails
 *               0 - If success
 *
 * @section description
 * This function is used to make socket to listen for remote connecion request in passive mode
 *
 */

int32_t  rsi_listen(int32_t sockID, int32_t backlog)
{
#ifdef ROM_WIRELESS
  return ROMAPI_WL->listen(global_cb_p, sockID, backlog);
#else
  return api_wl->listen(global_cb_p, sockID, backlog);
#endif
}
/*==============================================*/
/**
 * @fn         int32_t  rsi_accept(int32_t sockID, struct rsi_sockaddr *ClientAddress, int32_t *addressLength)
 * @brief      This function is used to accept connection request from remote peer
 * @param[in]  sockID, socket descriptor 
 * @param[in]  ClientAddress, Remote peer address 
 * @param[in]  addressLength, Remote peer address length
 * @param[out] None
 * @return
 *             <0 - If fails
 *              0 - If success
 *
 * @section description
 * This function is used to accept connection request from remote peer
 *
 */

int32_t  rsi_accept(int32_t sockID, struct rsi_sockaddr *ClientAddress, int32_t *addressLength)
{
#ifdef ROM_WIRELESS
  return ROMAPI_WL->accept(global_cb_p, sockID, ClientAddress, addressLength);
#else
  return api_wl->accept(global_cb_p, sockID, ClientAddress, addressLength);
#endif
}
/*==============================================*/
/**
 * @fn         int32_t  rsi_recvfrom(int32_t sockID, int8_t *buffer, int32_t buffersize, int32_t flags,struct rsi_sockaddr *fromAddr, int32_t *fromAddrLen)
 * @brief      This function is used to receive data from remote peer 
 * @param[in]  sockID, socket descriptor 
 * @param[in]  buffer, application buffer pointer to hold receive data
 * @param[in]  buffersize, requested bytes for read
 * @param[in]  flags, reserved
 * @param[in]  fromAddr, remote peer address 
 * @param[in]  fromAddrLen, remote peer address length
 * @param[out] None 
 * @return
 *             <0 - If fails
 *              0 - If success
 *
 *
 * @section description
 * This function is used to receive data from remote peer 
 *
 */

int32_t  rsi_recvfrom(int32_t sockID, int8_t *buffer, int32_t buffersize, int32_t flags,struct rsi_sockaddr *fromAddr, int32_t *fromAddrLen)
{
#ifdef ROM_WIRELESS
  return ROMAPI_WL->recvfrom(global_cb_p, sockID, buffer, buffersize, flags, fromAddr, fromAddrLen);
#else
  return api_wl->recvfrom(global_cb_p, sockID, buffer, buffersize, flags, fromAddr, fromAddrLen);
#endif
}
/*==============================================*/
/**
 * @fn         int32_t  rsi_recv(int32_t sockID, void *rcvBuffer, int32_t bufferLength, int32_t flags)
 * @brief      This function is used to receive data from remote peer 
 * @param[in]  sockID, socket descriptor 
 * @param[in]  buffer, application buffer pointer to hold receive data
 * @param[in]  buffersize, requested bytes for read
 * @param[in]  flags, reserved
 * @return
 *
 *             <0 - If fails
 *              0 - If success
 *
 * @section description
 * This function is used to receive data from remote peer 
 *
 */
int32_t  rsi_recv(int32_t sockID, void *rcvBuffer, int32_t bufferLength, int32_t flags)
{
  int32_t fromAddrLen = 0;
  
#ifdef ROM_WIRELESS
  return ROMAPI_WL->recvfrom(global_cb_p, sockID, rcvBuffer, bufferLength, flags, NULL, &fromAddrLen);
#else
  return api_wl->recvfrom(global_cb_p, sockID, rcvBuffer, bufferLength, flags, NULL, &fromAddrLen);
#endif
}

/*==============================================*/
/**
 * @fn          int32_t rsi_sendto(int32_t sockID, int8_t *msg, int32_t msgLength, int32_t flags, struct rsi_sockaddr *destAddr, int32_t destAddrLen)
 * @brief       This function is used to send data to specific remote peer on a given socket synchronously
 * @param[in]   sockID, socket descriptor 
 * @param[in]   msg, pointer to data which needs to be send to remote peer 
 * @param[in]   msgLength, length of data to send 
 * @param[in]   flags, reserved 
 * @param[in]   destAddr, remote peer address to send data 
 * @param[in]   destAddrLen, rmeote peer address length
 * @param[out]  None
 * @return
 *             <0 - If fails
 *              0 - If success
 *
 * @section description
 * This function is used to send data to specific remote peer on a given socket
 *
 */

int32_t rsi_sendto(int32_t sockID, int8_t *msg, int32_t msgLength, int32_t flags, struct rsi_sockaddr *destAddr, int32_t destAddrLen)
{
#ifdef ROM_WIRELESS
  ROMAPI_WL->sendto_async(global_cb_p, sockID, msg, msgLength, flags, destAddr, destAddrLen, NULL);
#else
  api_wl->sendto_async(global_cb_p, sockID, msg, msgLength, flags, destAddr, destAddrLen, NULL);
#endif
}

/*==============================================*/
/**
 * @fn          int32_t rsi_sendto_async(int32_t sockID, int8_t *msg, int32_t msgLength, int32_t flags, struct rsi_sockaddr *destAddr, int32_t destAddrLen,
                     void (*data_transfer_complete_handler)(uint8_t sockID, uint16_t length))
 * @brief       This function is used to send data to specific remote peer on a given socket asynchronously
 * @param[in]   sockID, socket descriptor 
 * @param[in]   msg, pointer to data which needs to be send to remote peer 
 * @param[in]   msgLength, length of data to send 
 * @param[in]   flags, reserved 
 * @param[in]   destAddr, remote peer address to send data 
 * @param[in]   destAddrLen, rmeote peer address length
 * @param[in]   data_transfer_complete_handler, pointer to the callback function which will be called after data transfer completion
 * @param[out]  None
 * @return
 *             <0 - If fails
 *              0 - If success
 *
 * @section description
 * This function is used to send data to specific remote peer on a given socket
 *
 */
int32_t rsi_sendto_async(int32_t sockID, int8_t *msg, int32_t msgLength, int32_t flags, struct rsi_sockaddr *destAddr, int32_t destAddrLen,
                     void (*data_transfer_complete_handler)(uint8_t sockID, uint16_t length))
{
#ifdef ROM_WIRELESS
  return ROMAPI_WL->sendto_async(global_cb_p, sockID, msg, msgLength, flags, destAddr, destAddrLen, data_transfer_complete_handler);
#else
  return api_wl->sendto_async(global_cb_p, sockID, msg, msgLength, flags, destAddr, destAddrLen, data_transfer_complete_handler);
#endif
}
/*==============================================*/
/**
 * @fn         int32_t rsi_send(int32_t sockID, const int8_t *msg, int32_t msgLength, int32_t flags)
 * @brief      This function is used to send data on a given socket syncronously
 * @param[in]  sockID, socket descriptor 
 * @param[in]  msg, pointer to data which needs to be send to remote peer 
 * @param[in]  msgLength, length of data to send 
 * @param[in]  flags, reserved 
 * @param[out] None
 * @return
 *             <0 - If fails
 *              0 - If success
 *
 * @section description
 * This function is used to send data on a given socket
 *
 */

int32_t rsi_send(int32_t sockID, const int8_t *msg, int32_t msgLength, int32_t flags)
{
#ifdef ROM_WIRELESS
  return ROMAPI_WL->send_async(global_cb_p, sockID, msg, msgLength, flags, NULL);
#else
  return api_wl->send_async(global_cb_p, sockID, msg, msgLength, flags, NULL);
#endif
}



/*==============================================*/
/**
 * @fn         int32_t rsi_send_async(int32_t sockID, const int8_t *msg, int32_t msgLength, int32_t flags, 
                   void (*data_transfer_complete_handler)(uint8_t sockID, uint16_t length))
 * @brief      This function is used to send data on a given socket asynchronously
 * @param[in]  sockID, socket descriptor 
 * @param[in]  msg, pointer to data which needs to be send to remote peer 
 * @param[in]  msgLength, length of data to send 
 * @param[in]  flags, reserved 
 * @param[in]  data_transfer_complete_handler, pointer to the callback function which will be called after data transfer completion
 * @param[out] None
 * @return
 *             <0 - If fails
 *              0 - If success
 *
 * @section description
 * This function is used to send data on a given socket
 *
 */
int32_t rsi_send_async(int32_t sockID, const int8_t *msg, int32_t msgLength, int32_t flags, 
    void (*data_transfer_complete_handler)(uint8_t sockID, uint16_t length))
{
#ifdef ROM_WIRELESS
  return ROMAPI_WL->send_async(global_cb_p, sockID, msg, msgLength, flags, data_transfer_complete_handler);
#else
  return api_wl->send_async(global_cb_p, sockID, msg, msgLength, flags, data_transfer_complete_handler);
#endif
}

/*==============================================*/
/**
 * @fn          int32_t  rsi_shutdown(int32_t sockID, int32_t how)
 * @brief       This function is used to close the socket
 * @param[in]   sockID, socket descriptor 
 * @param[in]   how, to select type of socket close 
 * @param[out]  None
 * @return
 *             <0 - If fails
 *              0 - If success
 *
 * @section description
 * This function is used to close the socket
 *
 */
int32_t  rsi_shutdown(int32_t sockID, int32_t how)
{
#ifdef ROM_WIRELESS
  return ROMAPI_WL->shutdown(global_cb_p, sockID, how);
#else
  return api_wl->shutdown(global_cb_p, sockID, how);
#endif
}


/*==============================================*/
/**
 * @fn          int32_t rsi_check_state(int32_t type)
 * @brief       Checks wlan state
 * @param[in]   type, socket family ttype 
 * @param[out]  None
 * @return
 *              1 - If not in IP config state
 *              0 - If in IP cofig state
 *
 * @section description
 * This function is used to check the wlan state
 *
 */
int32_t rsi_check_state(int32_t type)
{
  rsi_driver_cb_t   *rsi_driver_cb   = global_cb_p->rsi_driver_cb;

  if(rsi_driver_cb->wlan_cb->opermode == RSI_WLAN_ACCESS_POINT_MODE)
  {
    if(RSI_CHECK_WLAN_STATE() != RSI_WLAN_STATE_CONNECTED)
    {
      return 1;
    }
  }
  else
  {
    if(type == AF_INET)
    {
      if(RSI_CHECK_WLAN_STATE() != RSI_WLAN_STATE_IP_CONFIG_DONE)
      {
        return 1;
      }
    }
    else
    {
      if(RSI_CHECK_WLAN_STATE() != RSI_WLAN_STATE_IPV6_CONFIG_DONE)
      {
        return 1;
      }
    }
  }
  return 0;
}


/*==============================================*/
/**
 * @fn          int32_t rsi_get_application_socket_descriptor(int32_t sock_id)
 * @brief       Gets application socket descriptor from module socket descriptor
 * @param[in]   sock_id, module's socket descriptor
 * @param[out]  None
 * @return
 *             <0 - If index is not found
 *             >0 - application index
 *
 * @section description
 * This function is used to get the application socket descriptor from module socket descriptor
 *
 */
int32_t rsi_get_application_socket_descriptor(int32_t sock_id)
{
#ifdef ROM_WIRELESS
  return ROMAPI_WL->rsi_get_application_socket_descriptor(global_cb_p, sock_id);
#else
  return api_wl->rsi_get_application_socket_descriptor(global_cb_p, sock_id);
#endif
}

/*==============================================*/
/**
 * @fn          void rsi_clear_sockets(uint8_t sockID)
 * @brief       function to clear socket information
 * @param[in]   sockID, socket descriptor
 * @param[out]  None
 * @return      void
 *
 * @section description
 * This function is used to clear socket information
 *
 */
void rsi_clear_sockets(uint8_t sockID)
{
#ifdef ROM_WIRELESS
  ROMAPI_WL->rsi_clear_sockets(global_cb_p, sockID);
#else
  api_wl->rsi_clear_sockets(global_cb_p, sockID);
#endif
}



/*==============================================*/
/**
 * @fn           int rsi_setsockopt(int sockID, int level, int option_name,const void *option_value, socklen_t option_len)
 * @brief        This function is used to set the socket options 
 * @param[in]    sockID, socket descriptor 
 * @param[in]    level,
 * @param[in]    option_name,
 * @param[in]    option_value,
 * @param[in]    option_len, 
 * @return        
 *
 *
 * @section description
 * This API is used to set the socket options
 *
 *
 */

int rsi_setsockopt(int sockID, int level, int option_name,const void *option_value, rsi_socklen_t option_len)
{

  struct rsi_timeval *timeout = NULL;
  
  uint16_t timeout_val;

  //! If sockID is not in available range
  if(sockID < 0 || sockID >= RSI_NUMBER_OF_SOCKETS)
  {
    //! Set error
    rsi_wlan_set_status(EBADF);

    return RSI_SOCK_ERROR;
  }
  if((option_name != SO_RCVTIMEO ) || (level != SOL_SOCKET))
  {
    rsi_wlan_set_status(EINVAL);

    return RSI_SOCK_ERROR;
  }
  //! If socket is in not created state
  if(rsi_socket_pool[sockID].sock_state == RSI_SOCKET_STATE_INIT) 
  {
    //! Set error
    rsi_wlan_set_status(EBADF);

    return RSI_SOCK_ERROR;
  }
  
  timeout = (struct rsi_timeval *)option_value;
  
  timeout_val = (timeout->tv_usec/1000) + (timeout->tv_sec * 1000);

  //! This feature is available only if Synchrounous bitmap is set
  if(rsi_socket_pool[sockID].sock_bitmap & RSI_SOCKET_FEAT_SYNCHRONOUS)
  {
    rsi_socket_pool[sockID].read_time_out = timeout_val;
  }
  else
  {
    //! Set error
    rsi_wlan_set_status(ENOPROTOOPT);

    return RSI_SOCK_ERROR;
  }

  return RSI_SUCCESS;
}

/*==============================================*/
/**
 * @fn          int32_t  rsi_select(int32_t nfds, rsi_fd_set *readfds, rsi_fd_set *writefds, rsi_fd_set *exceptfds, struct rsi_timeval *timeout) 
 * @brief
 * @param[in]   int32_t nfds
 * @param[in]   rsi_fd_set *readfds
 * @param[in]   rsi_fd_set *writefds
 * @param[in]   rsi_fd_set *exceptfds
 * @param[out]
 * @return
 *
 *
 * @section description
 * This 
 *
 *
 */

int32_t  rsi_select(int32_t nfds, rsi_fd_set *readfds, rsi_fd_set *writefds, rsi_fd_set *exceptfds, struct rsi_timeval *timeout)
{

  return RSI_SOCK_ERROR;
  //! TODO: Later
}

uint8_t calculate_buffers_required(uint8_t type, uint16_t length)
{
#ifdef ROM_WIRELESS
  return ROMAPI_WL->calculate_buffers_required(global_cb_p, type, length);
#else
  return api_wl->calculate_buffers_required(global_cb_p, type, length);
#endif
}


