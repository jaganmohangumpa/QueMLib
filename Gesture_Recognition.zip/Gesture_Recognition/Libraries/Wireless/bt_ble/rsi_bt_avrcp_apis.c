/**
 * @file     rsi_bt_avrcp_apis.c
 * @version  0.1
 * @date     03 Sep 2015
 *
 *  Copyright(C) Redpine Signals 2015
 *  All rights reserved by Redpine Signals.
 *
 *  @section License
 *  This program should be used on your own responsibility.
 *  Redpine Signals assumes no responsibility for any losses
 *  incurred by customers or third parties arising from the use of this file.
 *
 *  @brief : This file contains BT SPP API's which needs to be called from application
 *
 *  @section Description  This file contains BT SPP API's called from application
 *
 */
#ifdef RSI_BT_ENABLE
#include "rsi_driver.h" 
#include "rsi_bt.h"
#include "rsi_bt_apis.h"
#include "rsi_bt_config.h"

/* NOTE***********************************************
 * For all the API's device address shall be provided as ASCII string.
 * Ex: "00:12:34:AB:CD:EF"
 ****************************************************/

/*==============================================*/
/**
 * @fn         rsi_bt_avrcp_init
 * @brief      sets profile mode
 * @return     int32_t
 *             0  =  success
 *             !0 = failure
 * @section description
 * This function is used to set the profile mode.
 */
int32_t rsi_bt_avrcp_init(void)
{ 
  rsi_bt_req_profile_mode_t bt_req_avrcp_init = {RSI_AVRCP_PROFILE_BIT};
  return rsi_bt_driver_send_cmd(RSI_BT_REQ_SET_PROFILE_MODE, &bt_req_avrcp_init, NULL);
}
/*==============================================*/
/**
 * @fn         rsi_bt_avrcp_conn
 * @brief      requests avrcp connection.
 * @param[in]  remote_dev_address, remote device address
 * @return     int32_t
 *             0  =  success
 *             !0 = failure
 * @section description
 * This API is used to initiate avrcp connection.
 * */
int32_t rsi_bt_avrcp_conn(uint8_t *remote_dev_addr)
{
  rsi_bt_req_avrcp_conn_t bt_req_avrcp_connect = {{0}};
  rsi_ascii_dev_address_to_6bytes_rev(bt_req_avrcp_connect.dev_addr, (int8_t *)remote_dev_addr);

  return rsi_bt_driver_send_cmd(RSI_BT_REQ_AVRCP_CONNECT, &bt_req_avrcp_connect, NULL);
}


/*==============================================*/
/**
 * @fn         rsi_bt_avrcp_disconn
 * @brief      requests avrcp disconnection.
 * @param[in]  remote_dev_address, remote device address
 * @return     int32_t
 *             0  =  success
 *             !0 = failure
 * @section description
 * This API is used to initiate avrcp disconnection.
 * */
int32_t rsi_bt_avrcp_disconn(uint8_t *remote_dev_addr)
{
  rsi_bt_req_avrcp_disconnect_t bt_req_avrcp_disconnect = {{0}};
  
  
  rsi_ascii_dev_address_to_6bytes_rev(bt_req_avrcp_disconnect.dev_addr, (int8_t *)remote_dev_addr);
  return rsi_bt_driver_send_cmd(RSI_BT_REQ_AVRCP_DISCONNECT, &bt_req_avrcp_disconnect, NULL);
}


/*==============================================*/
/**
 * @fn         rsi_bt_avrcp_play
 * @brief      requests avrcp play.
 * @section description
 * This API is used to play audio.
 * */
int32_t rsi_bt_avrcp_play(uint8_t *remote_dev_addr)
{
  rsi_bt_req_avrcp_play_t bt_req_avrcp_play = {{0}};
  
  
  rsi_ascii_dev_address_to_6bytes_rev(bt_req_avrcp_play.dev_addr, (int8_t *)remote_dev_addr);
  return rsi_bt_driver_send_cmd(RSI_BT_REQ_AVRCP_PLAY, &bt_req_avrcp_play, NULL);
}



/*==============================================*/
/**
 * @fn         rsi_bt_avrcp_pause
 * @brief      requests avrcp play.
 * @section description
 * This API is used to play audio.
 * */
int32_t rsi_bt_avrcp_pause(uint8_t *remote_dev_addr)
{
  rsi_bt_req_avrcp_pause_t bt_req_avrcp_pause = {{0}};
  
  
  rsi_ascii_dev_address_to_6bytes_rev(bt_req_avrcp_pause.dev_addr, (int8_t *)remote_dev_addr);
  
  return rsi_bt_driver_send_cmd(RSI_BT_REQ_AVRCP_PAUSE, &bt_req_avrcp_pause, NULL);
}



/*==============================================*/
/**
 * @fn         rsi_bt_avrcp_next
 * @brief      requests avrcp next.
 * @section description
 * This API is used to play audio.
 * */
int32_t rsi_bt_avrcp_next(uint8_t *remote_dev_addr)
{
  rsi_bt_req_avrcp_next_t bt_req_avrcp_next = {{0}};
  
  
  rsi_ascii_dev_address_to_6bytes_rev(bt_req_avrcp_next.dev_addr, (int8_t *)remote_dev_addr);
  
  return rsi_bt_driver_send_cmd(RSI_BT_REQ_AVRCP_NEXT, &bt_req_avrcp_next, NULL);
}




/*==============================================*/
/**
 * @fn         rsi_bt_avrcp_next
 * @brief      requests avrcp next.
 * @section description
 * This API is used to play audio.
 * */
int32_t rsi_bt_avrcp_previous(uint8_t *remote_dev_addr)
{
  rsi_bt_req_avrcp_previous_t bt_req_avrcp_previous = {{0}};
  
  
  rsi_ascii_dev_address_to_6bytes_rev(bt_req_avrcp_previous.dev_addr, (int8_t *)remote_dev_addr);
  
  return rsi_bt_driver_send_cmd(RSI_BT_REQ_AVRCP_PREVIOUS, &bt_req_avrcp_previous, NULL);
}
#endif
