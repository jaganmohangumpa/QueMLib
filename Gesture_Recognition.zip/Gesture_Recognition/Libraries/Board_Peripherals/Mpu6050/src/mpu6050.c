/*
 *********************************************************************************************************
 *
 *                                    (c) Copyright 2018 Redpine Signals
 *                                           All rights reserved.
 *
 *               This file is protected by international copyright laws. This file can only be used in
 *               accordance with a license and should Not be redistributed in any way without written
 *               permission by Redpine Signals.
 *
 *                                            www.redpinesignals.com
 *
 *********************************************************************************************************
 */

/*
 *********************************************************************************************************
 *
 *											 					 mpu6050 source file
 *
 * File           : mpu6050.c
 * Version        : V0.1
 * Description    : mpu6050 sensor file
 * History        :
 * 2018-01-17     : V0.1    First version.
 *********************************************************************************************************
 * Note(s)		 :
 *********************************************************************************************************
 */
/*
 *********************************************************************************************************
 *                                           INCLUDE FILES
 *********************************************************************************************************
 */

#include "mpu6050.h"
#include "mpu6050_port.h"
#include "DEFINES.h"
#include "macros_knn.h"
/*
 *********************************************************************************************************
 *                                          LOCAL GLOBAL VARIABLES
 *********************************************************************************************************
 */
int16_t Gx_offset = 0, Gy_offset = 0, Gz_offset = 0;
int16_t MPU6050_Lastax, MPU6050_Lastay, MPU6050_Lastaz, MPU6050_Lastgx, MPU6050_Lastgy, MPU6050_Lastgz;
int16_t MPU6050_FIFO[6][11];

float Gesture_X[1000]= {0},Gesture_Y[1000]= {0};
float Xmeanremovel_data[1000]={0},Ymeanremovel_data[1000]={0};
int16_t Gesture_filled =0, mov_avg_len=0;
float knn_test[TEST_ROWS][TEST_COLS];

/*
 *********************************************************************************************************
 *                                           EXTERN VARIABLES
 *********************************************************************************************************
 */
// extern uint8_t flag;
int predicted_digit=0;

/*
 *********************************************************************************************************
 *                                           EXTERN FUNCTIONS
 *********************************************************************************************************
 */
extern void rsi_delay_ms(int delay);
extern uint8_t button_press;

/*
 *********************************************************************************************************
 *                                           MPU6050_newValues()
 *
 * Description : Gets the 6 axis values from the sensor
 *
 * Argument(s) : ax,ay,az ----> buffer to store accelerometer values 
 *							 gx,gy,gz ----> buffer to store gyrometer values
 *
 * Return(s)   :6-axis values
 *
 * Caller(s)   : 
 *
 * Note(s)     :
 *********************************************************************************************************
 */

uint16_t MPU6050_newValues(int16_t ax, int16_t ay, int16_t az, int16_t gx, int16_t gy, int16_t gz)
{
	uint8_t i;
	int32_t sum = 0;

	for(i = 1; i < 10; i++)
	{
		MPU6050_FIFO[0][i - 1] = MPU6050_FIFO[0][i];
		MPU6050_FIFO[1][i - 1] = MPU6050_FIFO[1][i];
		MPU6050_FIFO[2][i - 1] = MPU6050_FIFO[2][i];
		MPU6050_FIFO[3][i - 1] = MPU6050_FIFO[3][i];
		MPU6050_FIFO[4][i - 1] = MPU6050_FIFO[4][i];
		MPU6050_FIFO[5][i - 1] = MPU6050_FIFO[5][i];
	}

	MPU6050_FIFO[0][9] = ax;
	MPU6050_FIFO[1][9] = ay;
	MPU6050_FIFO[2][9] = az;
	MPU6050_FIFO[3][9] = gx;
	MPU6050_FIFO[4][9] = gy;
	MPU6050_FIFO[5][9] = gz;

	sum = 0;
	for(i = 0; i < 10; i++)
	{
		sum += MPU6050_FIFO[0][i];
	}
	MPU6050_FIFO[0][10] = sum / 10;

	sum = 0;
	for(i = 0; i < 10; i++)
	{
		sum += MPU6050_FIFO[1][i];
	}
	MPU6050_FIFO[1][10] = sum / 10;

	sum = 0;
	for(i = 0; i < 10; i++)
	{
		sum += MPU6050_FIFO[2][i];
	}
	MPU6050_FIFO[2][10] = sum / 10;

	sum = 0;
	for(i = 0; i < 10; i++)
	{
		sum += MPU6050_FIFO[3][i];
	}
	MPU6050_FIFO[3][10] = sum / 10;

	sum = 0;
	for(i = 0; i < 10; i++)
	{
		sum += MPU6050_FIFO[4][i];
	}
	MPU6050_FIFO[4][10] = sum / 10;

	sum = 0;
	for(i = 0; i < 10; i++)
	{
		sum += MPU6050_FIFO[5][i];
	}
	MPU6050_FIFO[5][10] = sum / 10;
	return 0;
}

/*
 *********************************************************************************************************
 *                                           MPU6050_setClockSource()
 *
 * Description : Sets the clock source for the sensor
 *
 * Argument(s) : Source		-------			Clock Source to set
 *
 * Return(s)   : 0        -------     SUCCESS
 *              <0				-------			FAILURE 
 *
 * Caller(s)   :
 *
 * Note(s)     :
 *********************************************************************************************************
 */

uint16_t MPU6050_setClockSource(uint8_t source)
{
	uint8_t data;
	int32_t 	status = 0;
	data = source;
	status= mpu6050_i2c_writebuf (MPU6050_RA_PWR_MGMT_1, data, 1);	
	return status;
}
/*
 *********************************************************************************************************
 *                                           MPU6050_setFullScaleGyroRange()
 *
 * Description : Sets the Full scale Gyroscope range
 *
 * Argument(s) : Range		--------		Range to set
 *
 * Return(s)   : 0        -------     SUCCESS
 *              <0				-------			FAILURE 
 *
 * Caller(s)   :
 *
 * Note(s)     :
 *********************************************************************************************************
 */
uint16_t MPU6050_setFullScaleGyroRange(uint8_t range)
{
	uint8_t data;
	int32_t 	status = 0;
	if(range==0x00)
	{
		data = 0x00;
	}
	else if(range == 0x01)
	{
		data = 0x08;
	}
	else if(range == 0x10)
	{
		data = 0x10;
	}
	else if(range == 0x11)
	{
		data = 0x18;
	}
	status= mpu6050_i2c_writebuf (MPU6050_RA_GYRO_CONFIG, range ,1);	
	return status;
}

/*
 *********************************************************************************************************
 *                                           MPU6050_setFullScaleAccelRange()
 *
 * Description : Sets the Full scale Accelerometer range
 *
 * Argument(s) : Range		-------			Range to set 
 *
 * Return(s)   : 0        -------     SUCCESS
 *              <0				-------			FAILURE 
 *
 * Caller(s)   :
 *
 * Note(s)     :
 *********************************************************************************************************
 */

uint16_t MPU6050_setFullScaleAccelRange(uint8_t range)
{
	int32_t 	status = 0;
	uint8_t data;
	if(range==0x00)
	{
		data = 0x00;
	}
	else if(range == 0x01)
	{
		data = 0x08;
	}
	else if(range == 0x10)
	{
		data = 0x10;
	}
	else if(range == 0x11)
	{
		data = 0x18;
	}
	status= mpu6050_i2c_writebuf (MPU6050_RA_ACCEL_CONFIG, data ,1);	
	return status;
}


/*
 *********************************************************************************************************
 *                                           MPU6050_setSleepEnabled()
 *
 * Description : Enables the  sensor sleep bit
 *
 * Argument(s) : Enable		-------				1
 *
 * Return(s)   : 0        -------     SUCCESS
 *              <0				-------			FAILURE 
 *
 * Caller(s)   :
 *
 * Note(s)     :
 *********************************************************************************************************
 */

uint16_t MPU6050_setSleepEnabled(uint8_t enabled)
{
	int32_t 	status = 0;
	uint8_t data;
	if(enabled)
	{
		data=0x40 ;
	}else
	{
		data=0x00 ;
	}
status= mpu6050_i2c_writebuf (MPU6050_RA_PWR_MGMT_1, data ,1);	
return status;
}


/*
 *********************************************************************************************************
 *                                           MPU6050_setI2CMasterModeEnabled()
 *
 * Description : Enables the i2c master mode
 *
 * Argument(s) :	Enable	-------				1
 *
 * Return(s)   : 0        -------     SUCCESS
 *              <0				-------			FAILURE 
 *
 * Caller(s)   :
 *
 * Note(s)     :
 *********************************************************************************************************
 */

uint16_t MPU6050_setI2CMasterModeEnabled(uint8_t enabled)
{
	int32_t 	status = 0;
	uint8_t data;
	if(enabled)
	{
		data=0x20 ;
	}else
	{
		data=0x00 ;
	}
status= mpu6050_i2c_writebuf (MPU6050_RA_USER_CTRL, data ,1);	
	return status;
}


/*
 *********************************************************************************************************
 *                                           MPU6050_setI2CBypassEnabled()
 *
 * Description : Set the i2c bypass as enable
 *
 * Argument(s) : Enable		-------				1
 *
 * Return(s)   : 0        -------     SUCCESS
 *              <0				-------			FAILURE 
 *
 * Caller(s)   :
 *
 * Note(s)     :
 *********************************************************************************************************
 */

uint16_t MPU6050_setI2CBypassEnabled(uint8_t enabled)
{
	int32_t 	status = 0;
	uint8_t data;
	if(enabled)
	{
		data=0x02 ;
	}else
	{
		data=0x00 ;
	}
	status= mpu6050_i2c_writebuf (MPU6050_RA_INT_PIN_CFG, data ,1);	
	return status;
}

/*
 *********************************************************************************************************
 *                                           MPU6050_initialize()
 *
 * Description : Sensor initialization
 *
 * Argument(s) : None
 *
 * Return(s)   : None
 *
 * Caller(s)   :
 *
 * Note(s)     :
 *********************************************************************************************************
 */

void MPU6050_initialize(void)
{
	int32_t 	status = 0;
	uint8_t datad =0;
	uint8_t datan = 0;

	status=	MPU6050_setClockSource(MPU6050_CLOCK_PLL_XGYRO);
	status=MPU6050_setFullScaleGyroRange(MPU6050_GYRO_FS_1000);
	status=MPU6050_setFullScaleAccelRange(MPU6050_ACCEL_FS_2);
	status=MPU6050_setSleepEnabled(0);
	status=MPU6050_setI2CMasterModeEnabled(0);
	status=MPU6050_setI2CBypassEnabled(1);


	datan |= 0x30;
	status= mpu6050_i2c_writebuf (MPU6050_RA_INT_PIN_CFG, datan ,1);	

	datad |= 0x01;
	status= mpu6050_i2c_writebuf (MPU6050_RA_INT_ENABLE, datad ,1);	
}


/*
 *********************************************************************************************************
 *                                           MPU6050_collectdata()
 *
 * Description : Collects sensor data
 *
 * Argument(s) : None
 *
 * Return(s)   : Sensor values
 *
 * Caller(s)   :
 *
 * Note(s)     :
 *********************************************************************************************************
 */
#if 0
uint16_t MPU6050_collectdata()
{
		int16_t temp[6]={0};
		uint32_t i=0;
		int16_t Gesture_filled =0;
	if((button_press ))
	{
		while(1)
		{
			do{
			rsi_delay_ms(2);
				/* Read the XLSB,XMSB,YLSB,YMSB,ZLSB,ZMSB values*/
				MPU6050_getMotion6(&temp[0], &temp[1], &temp[2], &temp[3], &temp[4], &temp[5]);
				/* Subtract the values corresponding to x-axis and y axis and store it in an array*/
				GestureX[i] =temp[0]/16384.0;	
				GestureY[i] =temp[1]/16384.0;	
				GestureZ[i] =temp[2]/16384.0;	

				i++;
				Gesture_filled++;

				memset(temp,0,sizeof(temp));
				/* If the array is filled, clear the index and the elements in the array*/
				if(i> sizeof(GestureX))
				{
					i=0;
						memset(GestureX,0,sizeof(GestureX));
					memset(GestureZ,0,sizeof(GestureZ));
					
				}
			}while((button_press==1));
			
			predicted_digit = gestureDTWAlgorithm(GestureX, GestureY, GestureZ, Gesture_filled);
			 
			 
			 memset(GestureX,0,sizeof(GestureX));
			 memset(GestureY,0,sizeof(GestureY));
			 memset(GestureZ,0,sizeof(GestureZ));
			
			send_flag = 1;
			break;
		}
			
	return 0;
	}
}

#endif
	float x_mean, y_mean, x_std = 0, y_std = 0;

float x_avg[1000]={0},y_avg[1000]={0};
uint16_t MPU6050_collectdata(){
	float xy_mean[2]={0},xy_std[2]={0};
	int16_t temp[6]={0};
	float gx[1000]={0},gy[1000]={0},gz,total;
	
	uint16_t k=0,l=0,m=0,j=0,i=0;
	float sum[40]= {0},mean_average=0;
		

	

	if((button_press ))
	{
		Gesture_filled = 0;
	while(1)
		{
		
			do{
			
				rsi_delay_ms(2);
				/* Read the XLSB,XMSB,YLSB,YMSB,ZLSB,ZMSB values*/
				MPU6050_getMotion6(&temp[0], &temp[1], &temp[2], &temp[3], &temp[4], &temp[5]);

				Gesture_X[i] = temp[0];
				Gesture_Y[i] = temp[2];

				i++;
				Gesture_filled++;
				memset(temp,0,sizeof(temp));

			}while((button_press==1));
			
					for(i=0;i<Gesture_filled;i++)
				{
					gx[i]=Gesture_X[i]/16384.0;
					gy[i]=Gesture_Y[i]/16384.0;
				}
				
				
			calculate_mean(gx,gy,Gesture_filled,xy_mean);

			calculate_stddev(gx,gy,Gesture_filled,xy_std);
			
	for (int i=0;i<Gesture_filled;i++)
	{
		Xmeanremovel_data[i] =(gx[i]-xy_mean[0])/xy_std[0];
		Ymeanremovel_data[i] =(gy[i]-xy_mean[1])/xy_std[1];
	}
	
		movingAverage(Xmeanremovel_data,Ymeanremovel_data,x_avg,y_avg, Gesture_filled, MOVING_AVG_WINDOW);
	
		mov_avg_len = Gesture_filled - MOVING_AVG_WINDOW;										
	
	for(i=0;i<Gesture_filled;i++)
	{
		Gesture_X[i]=0;
		Gesture_Y[i]=0;
		gx[i]=0;
		gy[i]=0;
	}
	
						
			/* Dividing the gesture elements into 10 equal halves and averaging each set and pushing it into an array named as sum */
			for(k=0,j=1;k<mov_avg_len/DATA_WINDOW *j;k++)
			{
				sum[j-1]=sum[j-1] + x_avg[k];

				if(k==(j*(mov_avg_len/DATA_WINDOW))-1)
				{
					j++;
					if(j==DATA_WINDOW+1)
						break;
				}
			}
			
			for(l=0,m=1;l<mov_avg_len/DATA_WINDOW *m;l++)
			{
				sum[m+DATA_WINDOW-1]=sum[m+DATA_WINDOW-1] + y_avg[l];

				if(l==(m*(mov_avg_len/DATA_WINDOW))-1)
				{
					m++;
					if(m==DATA_WINDOW+1)
						break;
				}
			}
						
					/* copying the test data obtained in to knn_test array */
				for(i=0;i<40;i++)
				{
					knn_test[0][i] = sum[i];
//					printf("%f,",sum[i]);
				
				}
				break;
		}
return 0;
	}
}
	

/*
 *********************************************************************************************************
 *                                           MPU6050_testConnection()
 *
 * Description : Compares device address with the obtained sensor address 
 *
 * Argument(s) : None
 *
 * Return(s)   : 1        -------     SUCCESS
 *               0				-------			FAILURE 
 *
 * Caller(s)   :
 *
 * Note(s)     :
 *********************************************************************************************************
 */

uint8_t MPU6050_testConnection(void)
{
	if(MPU6050_getDeviceID() == MPU6050_ADDRESS_AD0_LOW)	// 0x68 or 0b01101000;
		return 1;
	else
		return 0;
}


/*
 *********************************************************************************************************
 *                                           MPU6050_getMotion6()
 *
 * Description : Gets the accelerometer and gyrometer values
 *
 * Argument(s) : ax,ay,az ----> buffer to store accelerometer values 
 *							 gx,gy,gz ----> buffer to store gyrometer values
 *
 * Return(s)   :6-axis values
 * Caller(s)   :
 *
 * Note(s)     :
 *********************************************************************************************************
 */

void MPU6050_getMotion6(int16_t* ax, int16_t* ay, int16_t* az, int16_t* gx, int16_t* gy, int16_t* gz)
{
	int i=0;uint8_t buffer[14];

	{
			buffer[0] = mpu6050_i2c_readbuf8 (MPU_DEVICE_ADDRESS, MPU6050_RA_ACCEL_XOUT_H, 1);	
			buffer[1] = mpu6050_i2c_readbuf8 (MPU_DEVICE_ADDRESS, MPU6050_RA_ACCEL_XOUT_L, 1);	
			buffer[2] = mpu6050_i2c_readbuf8 (MPU_DEVICE_ADDRESS, MPU6050_RA_ACCEL_YOUT_H, 1);	
			buffer[3] = mpu6050_i2c_readbuf8 (MPU_DEVICE_ADDRESS, MPU6050_RA_ACCEL_YOUT_L, 1);	
			buffer[4] = mpu6050_i2c_readbuf8 (MPU_DEVICE_ADDRESS, MPU6050_RA_ACCEL_ZOUT_H, 1);	
			buffer[5] = mpu6050_i2c_readbuf8 (MPU_DEVICE_ADDRESS, MPU6050_RA_ACCEL_ZOUT_L, 1);	
		

		MPU6050_Lastax = (((int16_t)buffer[0]) << 8) | buffer[1];
		MPU6050_Lastay = (((int16_t)buffer[2]) << 8) | buffer[3];
		MPU6050_Lastaz = (((int16_t)buffer[4]) << 8) | buffer[5];

		for(i=8;i<=13;i++)
		{
		buffer[i] = 0;
		 
		}
		MPU6050_Lastgx = (((int16_t)buffer[8]) << 8) | buffer[9];
		MPU6050_Lastgy = (((int16_t)buffer[10]) << 8) | buffer[11];
		MPU6050_Lastgz = (((int16_t)buffer[12]) << 8) | buffer[13];

		// Copy the pre-paired data in above step to buffer
		MPU6050_newValues(MPU6050_Lastax, MPU6050_Lastay, MPU6050_Lastaz, MPU6050_Lastgx, MPU6050_Lastgy, MPU6050_Lastgz);

		*ax = MPU6050_FIFO[0][10];
		*ay = MPU6050_FIFO[1][10];
		*az = MPU6050_FIFO[2][10];
		
	}
}


/*
 *********************************************************************************************************
 *                                           MPU6050_getlastMotion6()
 *
 * Description : Gets the last 6 sensor values
 *
 * Argument(s) : ax,ay,az ----> buffer to store accelerometer values 
 *							 gx,gy,gz ----> buffer to store gyrometer values
 *
 * Return(s)   : None
 *
 * Caller(s)   :
 *
 * Note(s)     :
 *********************************************************************************************************
 */

void MPU6050_getlastMotion6(int16_t* ax, int16_t* ay, int16_t* az, int16_t* gx, int16_t* gy, int16_t* gz)
{
	*ax = MPU6050_FIFO[0][10];
	*ay = MPU6050_FIFO[1][10];
	*az = MPU6050_FIFO[2][10];
}


/*
 *********************************************************************************************************
 *                                           MPU6050_getDeviceID()
 *
 * Description : Gets the device ID of the sensor
 *
 * Argument(s) : None
 *
 * Return(s)   : ID of the sensor
 *
 * Caller(s)   :
 *
 * Note(s)     :
 *********************************************************************************************************
 */

uint8_t MPU6050_getDeviceID(void)
{

	uint8_t data[1];
	data[0] = mpu6050_i2c_readbuf8(MPU_DEVICE_ADDRESS, MPU6050_RA_WHO_AM_I, 1);	
	return data[0];
}
/*
 *********************************************************************************************************
 *                                      MPU6050_InitGyro_Offset()
 *
 * Description : Initialize the gyrometer offset values
 *
 * Argument(s) : None
 *
 * Return(s)   : None
 *
 * Caller(s)   :
 *
 * Note(s)     :
 *********************************************************************************************************
 */
void MPU6050_InitGyro_Offset(void)
{
	uint8_t i;
	int16_t temp[6];
	int32_t	tempgx = 0, tempgy = 0, tempgz = 0;
	int32_t	tempax = 0, tempay = 0, tempaz = 0;
	Gx_offset = 0;
	Gy_offset = 0;
	Gz_offset = 0;

	for(i = 0; i < 50; i++)
	{
		rsi_delay_ms(100);
		MPU6050_getMotion6(&temp[0], &temp[1], &temp[2], &temp[3], &temp[4], &temp[5]);
	}
	for(i = 0; i < MPU60XX_SAMPLES; i++)
	{
		rsi_delay_ms(200);
		MPU6050_getMotion6(&temp[0], &temp[1], &temp[2], &temp[3], &temp[4], &temp[5]);

		tempax += temp[0];
		tempay += temp[1];
		tempaz += temp[2];
		tempgx += temp[3];
		tempgy += temp[4];
		tempgz += temp[5];
	}

	Gx_offset = tempgx / MPU60XX_SAMPLES;
	Gy_offset = tempgy / MPU60XX_SAMPLES;
	Gz_offset = tempgz / MPU60XX_SAMPLES;

	tempax /= MPU60XX_SAMPLES;
	tempay /= MPU60XX_SAMPLES;
	tempaz /= MPU60XX_SAMPLES;
}


/*
 *********************************************************************************************************
 *                                           END
 *********************************************************************************************************
 */
