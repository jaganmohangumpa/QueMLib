/*
 *********************************************************************************************************
 *
 *                                    (c) Copyright 2018 Redpine Signals
 *                                           All rights reserved.
 *
 *               This file is protected by international copyright laws. This file can only be used in
 *               accordance with a license and should not be redistributed in any way without written
 *               permission by Redpine Signals.
 *
 *                                            www.redpinesignals.com
 *
 *********************************************************************************************************
 */
  /*
 *********************************************************************************************************
 *
 *											 mpu6050_port source file
 *
 * File           : mpu6050_port.c
 * Version        : V0.1
 * Description    : mpu6050 port file
 * History        :
 * 2018-01-17     : V0.1   First version.
 *********************************************************************************************************
 * Note(s)		 :
 *********************************************************************************************************
 */
 /*
 *********************************************************************************************************
 *                                           INCLUDE FILES
 *********************************************************************************************************
 */
#include "rsi_chip.h"
#include <mpu6050.h>
#include "I2C.h"
#include "mpu6050_port.h"

/*
 *********************************************************************************************************
 *                                           LOCAL DEFINES
 *********************************************************************************************************
 */
#define MAX_WRITE    			  16        /* Max bytes to write in one step     */
#define SIZE_BUFFERS         4


/*
 *********************************************************************************************************
 *                                            GLOBAL FUNCTIONS
 *********************************************************************************************************
*/


/*
 *********************************************************************************************************
 *                                           LOCAL GLOBAL VARIABLES
 *********************************************************************************************************
 */


/*
 *********************************************************************************************************
 *                                           EXTERN VARIABLES
 *********************************************************************************************************
 */
extern ARM_DRIVER_I2C Driver_I2C0;
static ARM_DRIVER_I2C *I2Cdrv = &Driver_I2C0;

    
/*
 ********************************************************************************************************* *
 *                                           mpu6050_i2c_writebuf()
 *
 * Description : Wrapper for CMSIS I2C write
 *
 * Argument(s) : sub_addr     -----  Address of the register
 *
 *               buf          -----  Buffer which gets filled when the register is read
 *
 *               len          -----  length of the buffer
 *
 *
 * Return(s)   : status
 *
 * Caller(s)   :
 *
 * Note(s)     :
 *********************************************************************************************************
 */
int32_t  mpu6050_i2c_writebuf (uint8_t sub_addr, uint8_t buf, uint32_t len)
{
 	uint8_t wr_buf[MAX_WRITE + 2];
	uint32_t tx_done = 0;
  uint32_t cnt_num =0;
	
  wr_buf[0] = sub_addr;
	wr_buf[1] = buf;
	
  I2Cdrv->MasterTransmit (MPU_DEVICE_ADDRESS, wr_buf, len+1 , false);
  while (I2Cdrv->GetStatus().busy);
	
	cnt_num = I2Cdrv->GetDataCount ();
  if (cnt_num != (len + 1))
  {		
		return -1;
    /* Acknowledge polling */
	}
  else
	{
		tx_done = 1;
	}
  return 0;
}

/*
 ********************************************************************************************************* *
 *                                           mpu6050_i2c_readbuf8()
 *
 * Description : Wrapper for CMSIS I2C read
 *
 * Argument(s) : sub_addr     -----  Sub Address of the register
 *
 *               devaddr      -----  Device Address
 *
 *               len          -----  length of the buffer
 *
 *
 * Return(s)   : status
 *
 * Caller(s)   :
 *
 * Note(s)     :
 *********************************************************************************************************
 */

uint8_t mpu6050_i2c_readbuf8 (uint16_t devaddr, uint16_t subaddr, uint32_t len) 
{
	uint32_t cnt_num =0;
  uint8_t sub[2],	value;
	uint32_t rx_done = 0;

  sub[0] = (uint8_t)(subaddr & 0xFF);
 
  I2Cdrv->MasterTransmit (MPU_DEVICE_ADDRESS, sub, 1, false);
  while (I2Cdrv->GetStatus().busy);
	
  I2Cdrv->MasterReceive (MPU_DEVICE_ADDRESS, &value, len, false);
  while (I2Cdrv->GetStatus().busy);
	
  cnt_num = I2Cdrv->GetDataCount ();
	
  if (cnt_num != (len))
  {		
		 return 2;
    /* Acknowledge polling */
	}
	else
  {
		rx_done = 1;
	}

	return value;
}


/*
 *********************************************************************************************************
 *                                           END
 *********************************************************************************************************
 */
