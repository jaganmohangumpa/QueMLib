/*
 *********************************************************************************************************
 *
 *                                    (c) Copyright 2018 Redpine Signals,Inc
 *                                           All rights reserved.
 *
 *               This file is protected by international copyright laws. This file can only be used in
 *               accordance with a license and should Not be redistributed in any way without written
 *               permission by Redpine Signals.
 *
 *                                            www.redpinesignals.com
 *
 **************************************************************************************************************
 */
  /*
 *********************************************************************************************************
 *
 *											  									push button source file
 *
 * File           : push_button.c
 * Version        : V0.1
 * Description    :
 * History        :
 * 2018-02-01		  : V0.1    First version. 
 * *********************************************************************************************************
 * Note(s)		 :
 *********************************************************************************************************
 */
/*
 *********************************************************************************************************
 *                                              INCLUDE FILES
 *********************************************************************************************************
 */
 
#include "push_button.h"


/*
 *********************************************************************************************************
 *                                           LOCAL GLOBAL VARIABLES
 *********************************************************************************************************
 */
volatile uint8_t button_press =0;

/*
 *********************************************************************************************************
 *                                            GLOBAL FUNCTIONS
 *********************************************************************************************************
 */
/*
 ********************************************************************************************************* *
 *                                           push_button_handler()
 *
 * Description : Hits the handler whenever push button interrupt is received
 *
 * Argument(s) : None
 *
 * Return(s)   : None
 *
 * Caller(s)   :
 *
 * Note(s)     :
 *********************************************************************************************************
 */ 
void push_button_handler(void)
{
	volatile uint32_t intrStatus =0;
	uint32_t i=0,j=0;
	intrStatus = RSI_NPSSGPIO_GetIntrStatus();
	for(i=0;i<100000;i++);
	//   for(j=0;j<100000;j++);
	 	if(button_press  == 1)
	{
		button_press =0;

	}
	else	if(button_press  == 0)
		{
			button_press =1;
		
		}
	
		if(intrStatus & NPSS_GPIO_2_INTR){
		RSI_NPSSGPIO_ClrIntr(NPSS_GPIO_2_INTR);
	}
	
}

/*
 ********************************************************************************************************* *
 *                                           push_button_initialize()
 *
 * Description : Configures interrupt for push button
 *
 * Argument(s) : None
 *
 * Return(s)   : None
 *
 * Caller(s)   :
 *
 * Note(s)     :
 *********************************************************************************************************
 */ 
void push_button_initialize(void)
{
	
	RSI_NPSSGPIO_InputBufferEn(NPSS_GPIO_2 , 1);
	 
	RSI_NPSSGPIO_SetPinMux(NPSS_GPIO_2 , NPSSGPIO_PIN_MUX_MODE0);

	RSI_NPSSGPIO_SetDir(NPSS_GPIO_2 ,NPSS_GPIO_DIR_INPUT);
	
  RSI_NPSSGPIO_SetIntRiseEdgeEnable(NPSS_GPIO_2_INTR);

	RSI_NPSSGPIO_IntrUnMask(NPSS_GPIO_2_INTR);

	NVIC_EnableIRQ(TEST_PIN);

}
	
/*
 *********************************************************************************************************
 *                                           END
 *********************************************************************************************************
 */