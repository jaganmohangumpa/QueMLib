 /*
 *********************************************************************************************************
 *
 *                                    (c) Copyright 2018 Redpine Signals
 *                                           All rights reserved.
 *
 *               This file is protected by international copyright laws. This file can only be used in
 *               accordance with a license and should not be redistributed in any way without written
 *               permission by Redpine Signals.
 *
 *                                            www.redpinesignals.com
 *
 **************************************************************************************************************
 */
 
#ifndef MACROS_KNN_H
#define MACROS_KNN_H

#ifdef __cplusplus
extern "C"{
#endif


/*
 *********************************************************************************************************
 *                                              INCLUDE FILES
 *********************************************************************************************************
 */

#define DATA_WINDOW 20
#define MOVING_AVG_WINDOW 60

typedef enum {Initialize,start,collect_data,detect_pattern,Initial,Default}TEST;
/*
 *********************************************************************************************************
 *                                            GLOBAL FUNCTIONS
 *********************************************************************************************************
 */



/*
 *********************************************************************************************************
 *                                           END
 *********************************************************************************************************
 */

#ifdef __cplusplus
}
#endif

#endif      // MACROS_KNN_H
