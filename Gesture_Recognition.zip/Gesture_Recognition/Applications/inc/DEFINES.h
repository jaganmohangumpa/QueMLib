#define TRAIN_ROWS 81
#define TRAIN_COLS 41
#define TEST_ROWS 1
#define TEST_COLS 40
#define DIST_METHOD 'd'
#define K 1
#define WINDOW 3    // FOR DTW Distance
