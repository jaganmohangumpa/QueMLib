/*
 *********************************************************************************************************
 *
 *                                    (c) Copyright 2018 Redpine Signals
 *                                           All rights reserved.
 *
 *               This file is protected by international copyright laws. This file can only be used in
 *               accordance with a license and should not be redistributed in any way without written
 *               permission by Redpine Signals.
 *
 *                                            www.redpinesignals.com
 *
 **************************************************************************************************************
 */


/*
 *********************************************************************************************************
 *
 *											  provisioning  source file
 *
 * File           : provisioning.c
 * Version        : V0.1
 * Description    : 
 * History        :
 * 2018-02-01		  : V0.1    First version.
 *********************************************************************************************************
 * Note(s)		 :
 *********************************************************************************************************
 */

/*
 *********************************************************************************************************
 *                                           INCLUDE FILES
 *********************************************************************************************************
 */
#include "rsi_chip.h"
#include "rsi_wlan_apis.h"              											
#include "base_types.h"
#include "stdlib.h"
#include "I2C.h"
#include "mpu6050.h"


/*
 *********************************************************************************************************
 *                                           LOCAL DEFINES
 *********************************************************************************************************
 */
#define   SIZE_BUFFERS                   20  
#define 	MAXIMUM_NO_OF_SENSORS          20 

/*
 *********************************************************************************************************
 *                                           LOCAL CONSTANTS
 *********************************************************************************************************
 */

/*
 *********************************************************************************************************
 *                                           LOCAL DATA TYPES
 *********************************************************************************************************
 */
/*
 *********************************************************************************************************
 *                                           EXTERN VARIABLES
 *********************************************************************************************************
 */

/* I2C Driver */
extern ARM_DRIVER_I2C Driver_I2C0;
static ARM_DRIVER_I2C *I2Cdrv = &Driver_I2C0;
extern ARM_DRIVER_I2C Driver_I2C0;

/*
 *********************************************************************************************************
 *                                           LOCAL GLOBAL VARIABLES
 *********************************************************************************************************
 */
ARM_DRIVER_I2C *drv_info; 

 /*
 *********************************************************************************************************
 *                                           EXTERN FUNCTIONS
 *********************************************************************************************************
 */

/*
 *********************************************************************************************************
 *                                            GLOBAL FUNCTIONS
 *********************************************************************************************************
 */ 
void ARM_I2C_SignalEvent(uint32_t event); 

 /*
 *********************************************************************************************************
 *                                           ErrorHandler()
 *
 * Description : Handles errors during i2c setup
 *
 * Argument(s) : None
 *
 * Return(s)   : None
 *
 * Caller(s)   :
 *
 * Note(s)     :
 *********************************************************************************************************
 */
void ErrorHandler(void)
{
  while(1);
}
/*
 *********************************************************************************************************
 *                                           I2C_Initialize()
 *
 * Description : I2C driver initialization
 *
 * Argument(s) : None
 *
 * Return(s)   : None
 *
 * Caller(s)   :
 *
 * Note(s)     :
 *********************************************************************************************************
 */
int32_t I2C_Initialize (void) {
  uint8_t val;
	
	ARM_DRIVER_VERSION  version;
 
  drv_info = &Driver_I2C0;  
  version = drv_info->GetVersion ();
  if (version.api < 0x10A)   
  {
    // error handling
    ErrorHandler();
    return -1;
  }
 
  I2Cdrv->Initialize   (ARM_I2C_SignalEvent);
  I2Cdrv->PowerControl (ARM_POWER_FULL);
  I2Cdrv->Control      (ARM_I2C_BUS_SPEED, 2);

	return 0;
}


/*
 *********************************************************************************************************
 *                                           ARM_I2C_SignalEvent()
 *
 * Description : Handles the events on i2c line
 *
 * Argument(s) : event  ----- Event on i2c bus
 *
 * Return(s)   : None
 *
 * Caller(s)   :
 *
 * Note(s)     :
 *********************************************************************************************************
 */
void ARM_I2C_SignalEvent(uint32_t event)
{
   switch(event)
   {
     case ARM_I2C_EVENT_TRANSFER_DONE:
      break;
     case ARM_I2C_EVENT_TRANSFER_INCOMPLETE:
       break;
     case ARM_I2C_EVENT_SLAVE_TRANSMIT:
       break;    
     case ARM_I2C_EVENT_SLAVE_RECEIVE:
       break;
     case ARM_I2C_EVENT_ADDRESS_NACK:
       break;
     case ARM_I2C_EVENT_GENERAL_CALL:
       break;
     case ARM_I2C_EVENT_ARBITRATION_LOST:
       break;
     case ARM_I2C_EVENT_BUS_ERROR:
       break;
     case ARM_I2C_EVENT_BUS_CLEAR:
       break;
   }
   return;
}

/*
 *********************************************************************************************************
 *                                           END
 *********************************************************************************************************
 */
