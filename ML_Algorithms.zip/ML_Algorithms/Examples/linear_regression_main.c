#include "linear_regression.h"
void main()
{
	float x[] = {1,2,3,4,5};
	float y[] = {1,2,1.3,3.75,2.25};
	float w1, w0;

	linear_regression(x,y,&w1,&w0,5);
	printf("y = w1.x + w0 \n");
	printf("w1 = %f \nw0 = %f\n\n", w1,w0);

	
	float test_x = 2.4;
	float test_y = 	predict_dependent(test_x, w1, w0);
	printf("For x: %f, Predicted value y:%f\n",test_x,test_y);	
	
}
		


