/*
 *********************************************************************************************************
 *
 *                                    (c) Copyright 2018 Redpine Signals
 *                                           All rights reserved.
 *
 *               This file is protected by international copyright laws. This file can only be used in
 *               accordance with a license and should not be redistributed in any way without written
 *               permission by Redpine Signals.
 *
 *                                            www.redpinesignals.com
 *
 *********************************************************************************************************
 */
 /*
 *********************************************************************************************************
 *
 * logistic_regression example file 
 *
 * File           : logistic_regression.c
 * Version        : QueMLib 2.0a
 * Description    : 
 * History        :
 * *******************************************************************************************************
 * Note(s)	  :
 *********************************************************************************************************
 */
 /*
 *********************************************************************************************************
 *                                           INCLUDE FILES
 *********************************************************************************************************
 */

#include <stdio.h>
#include <math.h>
#include "logistic_regression.h"

/*
 *********************************************************************************************************
 *                                           DEFINE VALUES
 *********************************************************************************************************
 */

#define train_X_Rows 10 // train_X_rows = train_Y class elements
#define train_X_cols 2
#define learning_rate 0.3
#define n_epochs 500
#define test_X_Rows 2
#define test_X_cols 2
#define weight_array_size 3 // Bias + columns numbers


int main()
{
float train_X[train_X_Rows][train_X_cols] ={
{2.7810836,2.550537003},
{1.465489372,2.362125076},
{3.396561688,4.400293529},
{1.38807019,1.850220317},
{3.06407232,1.850220317},
{7.627531214,3.005305973},
{5.332441248,2.759262235},
{6.922596716,1.77106367},
{8.675418651,1.77106367},
{7.673756466,3.508563011}
};

	int train_Y[train_X_Rows] = {0,0,0,0,0,1,1,1,1,1};
	float test_X[test_X_Rows][test_X_cols] = {{7.673756466,3.508563011},{3.396561688,4.400293529}};
	float weights[weight_array_size] ={0};// Including Bias
	float predicted[test_X_Rows] ={0};
	int i;
	logistic_regression_train((float *)train_X, train_Y, train_X_Rows, train_X_cols,learning_rate,n_epochs,weights);
	logisti_regression_predict((float *)test_X,test_X_Rows, test_X_cols,weights,predicted);
	for(i = 0; i < test_X_Rows; i++ )
	{
		printf("Prediciton = %lf\n", predicted[i]);
	}

}
