# include <stdlib.h>
# include <stdio.h>
# include <math.h>
# include <time.h>
# include <complex.h>
#include "blas_level_1_float.h"



void test_ISMAX_Float ( );
void test_SASUM_Float ( );
void test_SAXPY_Float ( );
void test_SCOPY_Float ( );
void test_SDOT_Float ( );
void test_SNRM2_Float ( );
void test_SSCAL_Float ( );
void test_SSWAP_Float ( );
void test_scnrm2_Float ( );
void test_SDSDOT_Float ( );


int main ( )

{
 
//  //printf ( "\n" );
//  //printf ( "BLAS1_S_PRB:\n" );
//  //printf ( "  C version\n" );
//  //printf ( "  Test the BLAS1_S library.\n" );

  test_ISMAX_Float ( );
  test_SASUM_Float ( );
  test_SAXPY_Float ( );
  test_SCOPY_Float ( );
  test_SDOT_Float ( );
  test_SNRM2_Float ( );
  test_SSCAL_Float ( );
  test_SSWAP_Float ( );
  test_scnrm2_Float ( );
  test_SDSDOT_Float ( );

//  //printf ( "\n" );
//  //printf ( "BLAS1_S_PRB:\n" );
//  //printf ( "  Normal end of execution.\n" );
//  //printf ( "\n" );

  return 0;
}


void test_ISMAX_Float ( )



{
# define N 11

  int i;
  int i1;
  int incx;
  float x[N];
	int temp;

//  //printf ( "\n" );
//  //printf ( "test_ISMAX\n" );
//  //printf ( "  ISAMAX returns the index of maximum magnitude;\n" );

  for ( i = 1; i <= N; i++ )
  {
    x[i-1] = ( float ) ( ( 7 * i ) % 11 ) - ( float ) ( N / 2 );
  }

//  //printf ( "\n" );
//  //printf ( "  The vector X:\n" );
//  //printf ( "\n" );

  for ( i = 1; i <= N; i++ )
  {
//    //printf ( "  %6d  %8f\n", i, x[i-1] );
  }

  incx = 1;

  i1 = isamax_Float ( N, x, incx );
	
	temp =i1;

//  //printf ( "\n" );
//  //printf ( "  The index of maximum magnitude = %d\n", i1 );

  return;
# undef N
}



void test_SASUM_Float ( )


{
# define LDA 6
# define MA 5
# define NA 4
# define NX 10

  float a[LDA*NA];
  int i;
  int j;
  float x[NX];
  float temp,temp1,temp2;
  for ( i = 0; i < NX; i++ )
  {
    x[i] = pow ( -1.0, i + 1 ) * ( float ) ( 2 * ( i + 1 ) );
  }

//  //printf ( "\n" );
//  //printf ( "test_SASUM\n" );
//  //printf ( "  SASUM adds the absolute values of elements of a vector.\n" );
//  //printf ( "\n" );
//  //printf ( "  X = \n" );
//  //printf ( "\n" );
//  for ( i = 0; i < NX; i++ )
//  {
//    //printf ( "  %6d  %14f\n", i + 1, x[i] );
//  }
	temp = sasum_Float ( NX,   x, 1 );
	temp1 = sasum_Float ( NX/5, x, 1);
	temp2 = sasum_Float ( 2,    x, NX/2 );

  //printf ( "\n" );
  //printf ( "  SASUM ( NX,   X, 1 ) =    %f\n", sasum_Float ( NX,   x, 1 ) );
  //printf ( "  SASUM ( NX/5, X, 1) =    %f\n", sasum_Float ( NX/5, x, 1) );
  //printf ( "  SASUM ( 2,    X, NX/2 ) = %f\n", sasum_Float ( 2,    x, NX/2 ) );

  for ( i = 0; i < MA; i++ )
  {
    for ( j = 0; j < NA; j++ )
    {
      a[i+j*LDA] = pow ( -1.0, i + 1 + j + 1)
        * ( float ) ( 10 * ( i + 1 ) + j + 1 );
    }
  }

  //printf ( "\n" );
  //printf ( "  Demonstrate with a matrix A:\n" );
  //printf ( "\n" );
  for ( i = 0; i < MA; i++ )
  {
    for ( j = 0; j < NA; j++ )
    {
      //printf ( "  %14f", a[i+j*LDA] );
    }
    //printf ( "\n" );
  }
     //sasum_FLoat(MA,a+0+1*LDA,1);
  //printf ( "\n" );
  //printf ( "  SASUM(MA,A(1,2),1) =   %f\n", sasum_Float ( MA, a+0+1*LDA, 1 ) );
  //printf ( "  SASUM(NA,A(2,1),LDA) = %f\n", sasum_Float ( NA, a+1+0*LDA, LDA ) );

  return;
# undef LDA
# undef MA
# undef NA
# undef NX
}


void test_SAXPY_Float ( )

{
# define N 6

  float da;
  int i;
  float x[N];
  float y[N];

  for ( i = 0; i < N; i++ )
  {
    x[i] = ( float ) ( i + 1 );
  }

  for ( i = 0; i < N; i++ )
  {
    y[i] = ( float ) ( 100 * ( i + 1 ) );
  }

  //printf ( "\n" );
  //printf ( "test_SAXPY\n" );
  //printf ( "  SAXPY adds a multiple of vector X to vector Y.\n" );
  //printf ( "\n" );
  //printf ( "  X =\n" );
  //printf ( "\n" );
  for ( i = 0; i < N; i++ )
  {
    //printf ( "  %6d  %14f\n", i + 1, x[i] );
  }
  //printf ( "\n" );
  //printf ( "  Y =\n" );
  //printf ( "\n" );
  for ( i = 0; i < N; i++ )
  {
    //printf ( "  %6d  %14f\n", i + 1, y[i] );
  }

  da = 2.0;
  saxpy_Float ( N, da, x, 1, y, 1 );
  //printf ( "\n" );
  //printf ( "  SAXPY ( N, %f, X, 1, Y, 1 )\n", da );
  //printf ( "\n" );
  //printf ( "  Y =\n" );
  //printf ( "\n" );
  for ( i = 0; i < N; i++ )
  {
    //printf ( "  %6d  %14f\n", i + 1, y[i] );
  }

  for ( i = 0; i < N; i++ )
  {
    y[i] = ( float ) ( 100 * ( i + 1 ) );
  }

  da = -2.0;
  saxpy_Float ( N, da, x, 1, y, 1 );
  //printf ( "\n" );
  //printf ( "  SAXPY ( N, %f, X, 1, Y, 1 )\n", da );
  //printf ( "\n" );
  //printf ( "  Y =\n" );
  //printf ( "\n" );
  for ( i = 0; i < N; i++ )
  {
    //printf ( "  %6d  %14f\n", i + 1, y[i] );
  }

  for ( i = 0; i < N; i++ )
  {
    y[i] = ( float ) ( 100 * ( i + 1 ) );
  }

  da = 3.0;
  saxpy_Float ( 3, da, x, 2, y, 1 );
  //printf ( "\n" );
  //printf ( "  SAXPY ( 3, %14f, X, 2, Y, 1 )\n", da );
  //printf ( "\n" );
  //printf ( "  Y =\n" );
  //printf ( "\n" );
  for ( i = 0; i < N; i++ )
  {
    //printf ( "  %6d  %14f\n", i + 1, y[i] );
  }

  for ( i = 0; i < N; i++ )
  {
    y[i] = ( float ) ( 100 * ( i + 1 ) );
  }

  da = -4.0;
  saxpy_Float ( 3, da, x, 1, y, 2 );
  //printf ( "\n" );
  //printf ( "  SAXPY ( 3, %14f, X, 1, Y, 2 )\n", da );
  //printf ( "\n" );
  //printf ( "  Y =\n" );
  //printf ( "\n" );
  for ( i = 0; i < N; i++ )
  {
    //printf ( "  %6d  %14f\n", i + 1, y[i] );
  }

  return;
# undef N
}


void test_SCOPY_Float ( )


{
  float a[5*5];
  int i;
  int j;
  float x[10];
  float y[10];

  //printf ( "\n" );
  //printf ( "test_SCOPY\n" );
  //printf ( "  SCOPY copies one vector into another.\n" );
  //printf ( "\n" );

  for ( i = 0; i < 10; i++ )
  {
    x[i] = ( float ) ( i + 1 );
  }

  for ( i = 0; i < 10; i++ )
  {
    y[i] = ( float ) ( 10 * ( i + 1 ) );
  }

  for ( i = 0; i < 5; i++ )
  {
    for ( j = 0; j < 5; j++ )
    {
      a[i+j*5] = ( float ) ( 10 * ( i + 1 ) + j + 1 );
    }
  }

  //printf ( "\n" );
  //printf ( "  X =\n" );
  //printf ( "\n" );
  for ( i = 0; i < 10; i++ )
  {
    //printf ( "  %6d  %14f\n", i + 1, x[i] );
  }
  //printf ( "\n" );
  //printf ( "  Y =\n" );
  //printf ( "\n" );
  for ( i = 0; i < 10; i++ )
  {
    //printf ( "  %6d  %14f\n", i + 1, y[i] );
  }
  //printf ( "\n" );
  //printf ( "  A =\n" );
  //printf ( "\n" );
  for ( i = 0; i < 5; i++ )
  {
    for ( j = 0; j < 5; j++ )
    {
      //printf ( "  %14f", a[i+j*5] );
    }
      //printf ( "\n" );
  }

  scopy_Float ( 5, x, 1, y, 1 );
  //printf ( "\n" );
  //printf ( "  SCOPY ( 5, X, 1, Y, 1 )\n" );
  //printf ( "\n" );
  for ( i = 0; i < 10; i++ )
  {
    //printf ( "  %6d  %14f\n", i + 1, y[i] );
  }

  for ( i = 0; i < 10; i++ )
  {
    y[i] = ( float ) ( 10 * ( i + 1 ) );
  }

  scopy_Float ( 4, x, 2, y, 3 );
  //printf ( "\n" );
  //printf ( "  SCOPY ( 3, X, 2, Y, 3 )\n" );
  //printf ( "\n" );
  for ( i = 0; i < 10; i++ )
  {
    //printf ( "  %6d  %14f\n", i + 1, y[i] );
  }

  scopy_Float ( 5, x, 1, a, 1 );
  //printf ( "\n" );
  //printf ( "  SCOPY ( 5, X, 1, A, 1 )\n" );
  //printf ( "\n" );
  //printf ( "  A =\n" );
  //printf ( "\n" );
  for ( i = 0; i < 5; i++ )
  {
    for ( j = 0; j < 5; j++ )
    {
      //printf ( "  %14f", a[i+j*5] );
    }
      //printf ( "\n" );
  }

  for ( i = 0; i < 5; i++ )
  {
    for ( j = 0; j < 5; j++ )
    {
      a[i+j*5] = ( float ) ( 10 * ( i + 1 ) + j + 1 );
    }
  }

  scopy_Float ( 5, x, 2, a, 5 );
  //printf ( "\n" );
  //printf ( "  SCOPY ( 5, X, 2, A, 5 )\n" );
  //printf ( "\n" );
  //printf ( "  A =\n" );
  //printf ( "\n" );
  for ( i = 0; i < 5; i++ )
  {
    for ( j = 0; j < 5; j++ )
    {
      //printf ( "  %14f", a[i+j*5] );
    }
      //printf ( "\n" );
  }

  return;
}

void test_SDOT_Float ( )



{
# define N 5
# define LDA 10
# define LDB 7
# define LDC 6

  float a[LDA*LDA];
  float b[LDB*LDB];
  float c[LDC*LDC];
  int i;
  int j;
  float sum1;
  float x[N];
  float y[N];

  //printf ( "\n" );
  //printf ( "test_SDOT\n" );
  //printf ( "  SDOT computes the dot product of vectors.\n" );
  //printf ( "\n" );

  for ( i = 0; i < N; i++ )
  {
    x[i] = ( float ) ( i + 1);
  }

  for ( i = 0; i < N; i++ )
  {
    y[i] = - ( float ) ( i + 1 );
  }

  for ( i = 0; i < N; i++ )
  {
    for ( j = 0; j < N; j++ )
    {
      a[i+j*LDA] = ( float ) ( i + 1 + j + 1 );
    }
  }

  for ( i = 0; i < N; i++ )
  {
    for ( j = 0; j < N; j++ )
    {
      b[i+j*LDB] = ( float ) ( ( i + 1 ) - ( j + 1 ) );
    }
  }

  sum1 = sdot_Float ( N, x, 1, y, 1 );

  //printf ( "\n" );
  //printf ( "  Dot product of X and Y is %f\n", sum1 );
/*
  To multiply a ROW of a matrix A times a vector X, we need to
  specify the increment between successive entries of the row of A:
*/
  sum1 = sdot_Float ( N, a+1+0*LDA, LDA, x, 1 );

  //printf ( "\n" );
  //printf ( "  Product of row 2 of A and X is %14f\n", sum1 );
/*
  Product of a column of A and a vector is simpler:
*/
  sum1 = sdot_Float ( N, a+0+1*LDA, 1, x, 1 );

//  //printf ( "\n" );
//  //printf ( "  Product of column 2 of A and X is %14f\n", sum1 );
/*
  Here's how matrix multiplication, c = a*b, could be done
  with SDOT:
*/
  for ( i = 0; i < N; i++ )
  {
    for ( j = 0; j < N; j++ )
    {
      c[i+j*LDC] = sdot_Float ( N, a+i, LDA, b+0+j*LDB, 1 );
    }
  }

//  //printf ( "\n" );
//  //printf ( "  Matrix product computed with SDOT:\n" );
//  //printf ( "\n" );
  for ( i = 0; i < N; i++ )
  {
    for ( j = 0; j < N; j++ )
    {
      //printf ( "  %14f", c[i+j*LDC] );
    }
    //printf ( "\n" );
  }

  return;
# undef N
# undef LDA
# undef LDB
# undef LDC
}



void test_SNRM2_Float ( )
{
# define N 5
# define LDA 10
/*
  These parameters illustrate the fact that matrices are typically
  dimensioned with more space than the user requires.
*/
  float a[LDA*LDA];
  int i;
  int incx;
  int j;
  float sum1;
  float x[N];
  float temp;
//  //printf ( "\n" );
//  //printf ( "test_SNRM2\n" );
//  //printf ( "  SNRM2 computes the Euclidean norm of a vector.\n" );
//  //printf ( "\n" );
/*
  Compute the euclidean norm of a vector:
*/
  for ( i = 0; i < N; i++ )
  {
    x[i] = ( float ) ( i + 1 );
  }
	temp = snrm2_Float ( N, x, 1 );
//  //printf ( "\n" );
//  //printf ( "  X =\n" );
//  //printf ( "\n" );
//  for ( i = 0; i < N; i++ )
//  {
//    //printf ( "  %6d  %14f\n", i + 1, x[i] );
//  }
//  //printf ( "\n" );
//  //printf ( "  The 2-norm of X is %f\n", snrm2_Float ( N, x, 1 ) );
/*
  Compute the euclidean norm of a row or column of a matrix:
*/
  for ( i = 0; i < N; i++ )
  {
    for ( j = 0; j < N; j++ )
    {
      a[i+j*LDA] = ( float ) ( i + 1 + j + 1 );
    }
  }
 temp = snrm2_Float ( N, a+1+0*LDA, LDA );
//  //printf ( "\n" );
//  //printf ( "  The 2-norm of row 2 of A is %f\n", snrm2_Float ( N, a+1+0*LDA, LDA ) );

//  //printf ( "\n" );
//  //printf ( "  The 2-norm of column 2 of A is %f\n" ,
//       snrm2_Float ( N, a+0+1*LDA, 1 ) );
 temp = snrm2_Float ( N, a+0+1*LDA, 1 ) ;
  return;
# undef N
# undef LDA
}

void test_SSCAL_Float ( )
{
# define N 6

  float da;
  int i;
  float x[N];
  
  for ( i = 0; i < N; i++ )
  {
    x[i] = ( float ) ( i + 1 );
  }

//  //printf ( "\n" );
//  //printf ( "test_SSCAL\n" );
//  //printf ( "  SSCAL multiplies a vector by a scalar.\n" );
//  //printf ( "\n" );
//  //printf ( "  X =\n" );
//  //printf ( "\n" );
  for ( i = 0; i < N; i++ )
  {
    //printf ( "  %6d  %14f\n", i + 1, x[i] );
  }

  da = 5.0;
  sscal_Float ( N, da, x, 1 );
//  //printf ( "\n" );
//  //printf ( "  SSCAL ( N, %f, X, 1 )\n", da );
//  //printf ( "\n" );
//  for ( i = 0; i < N; i++ )
//  {
//    //printf ( "  %6d  %14f\n", i + 1, x[i] );
//  }

  for ( i = 0; i < N; i++ )
  {
    x[i] = ( float ) ( i + 1 );
  }

  da = -2.0;
  sscal_Float ( 3, da, x, 2 );
//  //printf ( "\n" );
//  //printf ( "  SSCAL ( 3, %f, X, 2 )\n", da );
//  //printf ( "\n" );
  for ( i = 0; i < N; i++ )
  {
    //printf ( "  %6d  %14f\n", i + 1, x[i] );
  }

  return;
# undef N
}

void test_SSWAP_Float ( )


{
# define N 6

  int i;
  float x[N];
  float y[N];

  for ( i = 0; i < N; i++ )
  {
    x[i] = ( float ) ( i + 1 );
  }

  for ( i = 0; i < N; i++ )
  {
    y[i] = ( float ) ( 100 * ( i + 1 ) );
  }

//  //printf ( "\n" );
//  //printf ( "test_SSWAP\n" );
//  //printf ( "  SSWAP swaps two vectors.\n" );
//  //printf ( "\n" );
//  //printf ( "  X and Y:\n" );
//  //printf ( "\n" );
  for ( i = 0; i < N; i++ )
  {
    //printf ( "  %6d  %14f  %14f\n", i + 1, x[i], y[i] );
  }

  sswap_Float ( N, x, 1, y, 1 );
//  //printf ( "\n" );
//  //printf ( "  SSWAP ( N, X, 1, Y, 1 )\n" );
//  //printf ( "\n" );
//  //printf ( "  X and Y:\n" );
//  //printf ( "\n" );
//  for ( i = 0; i < N; i++ )
//  {
//    //printf ( "  %6d  %14f  %14f\n", i + 1, x[i], y[i] );
//  }

  for ( i = 0; i < N; i++ )
  {
    x[i] = ( float ) ( i + 1 );
  }

  for ( i = 0; i < N; i++ )
  {
    y[i] = ( float ) ( 100 * ( i + 1 ) );
  }

  sswap_Float ( 2, x, 1, y, 1 );
//  //printf ( "\n" );
//  //printf ( "  SSWAP ( 2, X, 1, Y, 1 )\n" );

//  //printf ( "\n" );
//  //printf ( "  X and Y:\n" );
//  //printf ( "\n" );
  for ( i = 0; i < N; i++ )
  {
    //printf ( "  %6d  %14f  %14f\n", i + 1, x[i], y[i] );
  }

  return;
# undef N
}
void test_scnrm2_Float ( )

{
# define N 5

  int i;
  int incx;
  float norm;
	float temp;
  float complex x[N] = {
    2.0 - 1.0 * I,
   -4.0 - 2.0 * I,
    3.0 + 1.0 * I,
    2.0 + 2.0 * I,
   -1.0 - 1.0 * I };

//  //printf ( "\n" );
//  //printf ( "test_scnrm2\n" );
//  //printf ( "  SCNRM2 returns the Euclidean norm of a complex vector.\n" );

//  //printf ( "\n" );
//  //printf ( "  The vector X:\n" );
//  //printf ( "\n" );
  for ( i = 0; i < N; i++ )
  {
    //printf ( "  %6d  %6f  %6f\n",i, creal ( x[i] ), cimag ( x[i] ) );
  }

  incx = 1;
  norm = scnrm2_Float ( N, x, incx );

//  //printf ( "\n" );
//  //printf ( "  The euclidean norm of X is %f\n", norm );
  temp = norm;
  return;
# undef N
}
void test_SDSDOT_Float ( )
{
# define N 5
# define LDA 10
# define LDB 7
# define LDC 6

  float a[LDA*LDA];
  float b[LDB*LDB];
  float c[LDC*LDC];
  int i;
  int j;
  float sum1;
  float x[N];
  float y[N];
  float sb=2.9332;
  float temp;
//  //printf ( "\n" );
//  //printf ( "test_SDSDOT\n" );
//  //printf ( "  SDSDOT computes the inner product of two vectors with extended prescision accumulation\n" );
//  //printf ( "\n" );

  for ( i = 0; i < N; i++ )
  {
    x[i] = ( float ) ( i + 1);
  }

  for ( i = 0; i < N; i++ )
  {
    y[i] = - ( float ) ( i + 1 );
  }
 for ( i = 0; i < N; i++ )
  {
    for ( j = 0; j < N; j++ )
    {
      a[i+j*LDA] = ( float ) ( i + 1 + j + 1 );
    }
  }

  for ( i = 0; i < N; i++ )
  {
    for ( j = 0; j < N; j++ )
    {
      b[i+j*LDB] = ( float ) ( ( i + 1 ) - ( j + 1 ) );
    }
  }

  sum1 = sdsdot_Float ( N,sb, x, 1, y, 1 );
//  //printf ( "\n" );
//  //printf ( "  scalar  added to the Product of x and y is %f\n", sum1 );
  temp = sum1;

}


