#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <complex.h>
#include "blas_level1_int_32.h"
#include <stdint.h>

int main();
void test_isamax_int32();
void test_sasum_int32();
void test_saxpy_int32();
void test_scopy_int32();
void test_sdot_int32();
void test_snrm2_int32();
void test_sscal_int32();
void test_sswap_int32();
void test_scnrm2_int32();
void test_sdsdot_int32();


int main()
{

	//printf ( "\n" );
 	//printf ( "BLAS Level1_Integer_16 :\n" );
	test_isamax_int32();
	test_sasum_int32();
	test_saxpy_int32();
	test_scopy_int32();
	test_sdot_int32();
	test_snrm2_int32();
	test_sscal_int32();
	test_sswap_int32();
	test_scnrm2_int32();
	test_sdsdot_int32();
	//printf("End");

}

void test_isamax_int32()
{
	# define N 30
	int32_t i;
  	int32_t i1;
  	int32_t incx;
  	int32_t  x[N];
    int temp;
	//printf("------------------------------------------------------------\n");
	//printf("ISAMAx returns the index of maximum number of the vector:\n");
	//printf("------------------------------------------------------------\n\n");
	for(i=1;i<=N;i++)
	{
		x[i-1] = (int32_t) ((7*i) % 100) - (int) (N/2);
	}

	//printf(" The vector X:\n");

 	for(i=1;i<=N;i++)
  	{
    		//printf("%6d  %8d\n", i, x[i-1]);
  	}

  	incx = 1;

  	i1 = isamax_int32(N,x,incx);
		temp=i1;

	//printf("\n");
  	//printf("The index of maximum Number = %d\n", i1);
	
	return;
	# undef N
}

void test_sasum_int32()
{
	# define LDA 21
	# define MA 10
	# define NA 10
	# define NX 5

  	int32_t a[LDA*NA];
  	int32_t i;
  	int32_t j;
  	int32_t x[NX];
		int temp;
  	for(i=0;i<NX;i++)
  	{
    		x[i]=pow(-1.0,i+1)*(int32_t)(2*(i+1));
  	}

  	//printf("SASUM adds the absolute values of elements of a vector.\n" );
  	//printf("X=\n");
  	//printf("\n");
 	for(i=0;i<NX;i++)
 	{
    		//printf("  %6d  %14d\n", i+1, x[i]);
  	}
   temp = sasum_int32(NX,x,1);
	 temp = sasum_int32(NX/5,x,1);
	 temp = sasum_int32(2,x,NX/2);
	 
	//printf("\n");
	//printf("SASUM(NX,X,1) =  %d\n", sasum_int32(NX,x,1));
	//printf("SASUM (NX/5,X,1) =    %d\n", sasum_int32(NX/5,x,1));
	//printf ("SASUM(2,X,NX/2 ) = %d\n", sasum_int32(2,x,NX/2));

	for(i=0;i<MA;i++ )
  	{
    		for(j=0;j<NA;j++)
    		{
      			a[i+j*LDA] = pow(-1.0,i+1 + j+1)* (int)(10 *(i+1)+j+1);
    		}
  	}

  	//printf ( "\n" );
  	//printf ( "Demonstrate with a matrix A:\n" );
	//printf ( "\n" );
	for (i=0;i<MA;i++)
	{
		for(j=0;j<NA;j++ )
		{
			//printf("  %12d",a[i+j*LDA]);
		}
		//printf ("\n");
	}
   temp = sasum_int32( MA, a+0+1*LDA, 1);
	 temp = sasum_int32( NA, a+1+0*LDA,LDA);
	 temp = temp;
	//printf ("\n");
	//printf ("SASUM(MA,A(1,2),1) = %d\n", sasum_int32( MA, a+0+1*LDA, 1));
	//printf ( "  SASUM(NA,A(2,1),LDA) = %d\n", sasum_int32( NA, a+1+0*LDA,LDA));
	
	return;
	# undef LDA
	# undef MA
	# undef NA
	# undef NX
}

void test_saxpy_int32( )
{
	# define N 20
	int32_t da;
	int32_t i;
	int32_t x[N];
	int32_t y[N];

	for(i=0;i<N;i++)
	{
		x[i]=(int32_t)(i+1);
	}

	for(i=0;i<N;i++)
	{
		y[i]=(int32_t)(100 * (i+1 ));
	}


	//printf( "SAXPY adds a multiple of vector X to vector Y.\n");
	
	//printf("X =\n");
	//printf( "\n");

	for(i=0;i<N;i++)
	{
		//printf("  %6d  %14d\n", i+1,x[i]);
	}

	//printf(" Y=\n");
	//printf ( "\n" );

	for(i=0;i<N;i++)
	{
		//printf( "%6d  %14d\n", i+1, y[i]);
	}

  	da=2.0;
	saxpy_int32(N,da,x,1,y,1);
	//printf("SAXPY( N, %d, X, 1, Y, 1)\n", da);
	//printf ( " Y =\n" );
	//printf ( "\n" );
	
	for(i=0;i<N;i++)
	{
		//printf("  %6d  %14d\n", i+1, y[i]);
	}

	for(i =0;i<N;i++)
	{
		y[i] = (int32_t)(100 *(i+1));
	}

	da = -2.0;
	saxpy_int32( N, da, x, 1, y, 1 );
	//printf ( "\n" );
	//printf ( "  SAXPY ( N, %d, X, 1, Y, 1 )\n", da );
	//printf ( "\n" );
	//printf ( "  Y =\n" );
	//printf ( "\n" );
  	for(i=0;i<N;i++ )
  	{
		//printf ("  %6d  %14d\n", i+1, y[i]);
	}

	for(i=0;i<N;i++)
	{
		y[i] = (int32_t)(100 *(i+1));
	}

	da = 3.0;
	saxpy_int32(3, da, x, 2, y, 1);
	//printf("\n");
	//printf("SAXPY (3, %5d, X, 2, Y, 1 )\n", da);
	//printf("\n");
	//printf("Y =\n" );
	//printf("\n");
	for(i=0;i<N;i++ )
	{
		//printf( "%6d  %5d\n", i+1, y[i]);
	}

	for(i=0;i<N;i++)
	{
		y[i] = (int32_t) (100 * (i+1));
	}

	da = -4.0;
	saxpy_int32(3,da,x,1,y,2);
	//printf("\n");
	//printf(" SAXPY( 3, %5d, X, 1, Y, 2 )\n", da);
	//printf("\n");
	//printf(" Y =\n");
	//printf("\n");
	for(i=0;i<N;i++)
	{
		//printf("  %6d  %5d\n", i+1, y[i]);
	}

	return;
	# undef N
}

void test_scopy_int32( )
{

	# define N 10

	int32_t a[5*5];
	int32_t i;
	int32_t j;
	int32_t x[N];
	int32_t y[N];

	//printf ( "  SCOPY copies one vector into another.\n" );
	//printf ( "\n" );

	for(i=0;i<N;i++)
	{
		x[i]=(int32_t)(i+1);
	}

	for(i=0;i<N;i++)
	{
		y[i] = (int32_t)(10 *(i+1));
	}

	for(i=0;i<5;i++)
	{
		for(j=0;j<5;j++)	
		{
			a[i+j*5] =(int32_t)(10 *(i+1) + j+1);
    		}
  	}
  	//printf("X=\n");
  	//printf ( "\n" );
  	for(i=0;i<N;i++)
  	{
    		//printf("%6d%14d\n", i+1,x[i]);
  	}
  	//printf("\n");
  	//printf("Y =\n");
  	//printf("\n");
  	for(i=0;i<N;i++)
  	{
    		//printf("%6d%14d\n", i+1, y[i]);
  	}
  	//printf("\n");
  	//printf("A =\n");
  	//printf("\n");
  	for(i=0;i<5;i++)
  	{
    		for(j =0; j<5;j++)
    		{
      			//printf(" %14d", a[i+j*5]);
    		}
      		//printf("\n");
 	 }

  	scopy_int32(5, x, 1, y, 1);

	//printf("\n");
  	//printf("SCOPY(5, X, 1, Y, 1 )\n");
  	for(i=0;i<N;i++)
  	{
    		//printf(" %6d %14d\n", i+1, y[i]);
 	}

	for(i = 0;i< N;i++)
  	{
    		y[i] = (int32_t)(10 * (i+1));
  	}

  	scopy_int32(5,x,2,y,3 );

  	//printf(" SCOPY(5,X,2,Y,3)\n");
  	for(i = 0;i < N;i++)
  	{
    		//printf(" %6d %14d\n", i+1, y[i]);
 	}

	scopy_int32( 5, x, 1, a, 1);
  	//printf("\n");
  	//printf("SCOPY (5, X, 1, A, 1 )\n");

  	//printf(" A =\n");
  	//printf("\n");
  	for(i=0;i<5;i++)
  	{
    		for(j=0;j<5;j++)
    		{
      			//printf(" %14d", a[i+j*5]);
   		}
      		//printf("\n");
  	}

  	for(i=0;i<5;i++)
  	{
    		for(j=0;j<5;j++ )
    		{
      			a[i+j*5] = (int32_t) (10 * (i+1)+j+1);
    		}
  	}
                    
  	scopy_int32(5, x, 2, a, 5);
  	//printf("\n");
  	//printf(" scopy(5,X,2,A,5)\n");
  	//printf("\n");
  	//printf("A =\n");
  	//printf("\n");
  	for(i=0;i<5;i++)
  	{
    		for(j=0;j<5;j++)
    		{
      			//printf("%14d",a[i+j*5]);
    		}
      		//printf("\n");
  	} 

  	return;
	# undef N
}

void test_sdot_int32 ( )
{
	# define N 10
	# define LDA 10
	# define LDB 7
	# define LDC 6

  	int32_t a[LDA*LDA];
  	int32_t b[LDB*LDB];
  	int32_t c[LDC*LDC];
  	int32_t i;
  	int32_t j;
  	int32_t sum1;
  	int32_t x[N];
  	int32_t y[N];

  	//printf ("\n");
  	//printf ("test_SDOT\n");
  	//printf ("SDOT computes the dot product of vectors.\n");
  	//printf ("\n");

  	for(i=0;i<N;i++)
  	{
    		x[i] = (int32_t)(i+1);
  	}

  	for(i=0;i<N;i++)
  	{
   		 y[i]=-(int32_t)(i+1);
  	}

	for(i=0;i<N;i++)
	{
		//printf("%14d\n",x[i]);
	}
	for(i=0;i<N;i++)
	{
		//printf("%14d\n",y[i]);
	}

  	for(i=0;i<N;i++)
  	{
    		for(j=0;j<N;j++)
    		{
      			a[i+j*LDA] = (int32_t) (i+1 + j+1);
    		}
  	}

  	for(i=0;i<N;i++)
  	{
    		for(j=0;j<N;j++)
    		{
      			b[i+j*LDB] = (int32_t) ((i+1)-(j+1));
    		}
  	}

  	sum1 = sdot_int32(N,x,1,y,1);

  	//printf("\n");
  	//printf("  Dot product of X and Y is %d\n", sum1);


	/* To multiply a ROW of a matrix A times a vector X, we need to
  	specify the increment between successive entries of the row of A: */

  	sum1 = sdot_int32(N,a+1+0*LDA,LDA,x,1);

  	//printf("\n");
  	//printf (" Product of row 2 of A and X is %14d\n", sum1);
	/*Product of a column of A and a vector is simpler:*/
  	sum1 = sdot_int32(N,a+0+1*LDA,1,x,1);

  	//printf ("\n");
  	//printf ("Product of column 2 of A and X is %14d\n", sum1);

	/*Here's how matrix multiplication, c = a*b, could be done with SDOT:*/
  	for(i=0;i<N;i++)
  	{
    		for(j=0;j<N;j++)
    		{
      			c[i+j*LDC] = sdot_int32(N,a+i,LDA,b+0+j*LDB,1);
    		}
  	}

  	//printf("\n");
  	//printf(" Matrix product computed with SDOT:\n");
  	//printf("\n");
  	for(i=0;i<N;i++)
  	{
    		for(j=0;j<N;j++)
    		{
      			//printf("%14d",c[i+j*LDC]);
    		}
    		//printf("\n");
  	}

  	return;
	# undef N
	# undef LDA
	# undef LDB
	# undef LDC
}

void test_snrm2_int32( )
{
	# define N 5
	# define LDA 10
/*These parameters illustrate the fact that matrices are typically dimensioned with more space than the user requires. */

  	int32_t a[LDA*LDA];
  	int32_t i;
  	int32_t incx;
  	int32_t j;
  	int32_t sum1;
  	int32_t x[N];

  	//printf("\n");
 	//printf("test_SNRM2\n");
  	//printf("SNRM2 computes the Euclidean norm of a vector.\n");
  	//printf("\n");

/*Compute the euclidean norm of a vector:*/


  	for(i=0;i<N;i++)
  	{
   	 	x[i] =(int32_t)(i+1);
 	}

  	//printf("\n");
  	//printf(" X=\n");
  	//printf("\n");
  	for(i=0;i<N;i++)
  	{
    		//printf(" %6d%14d\n",i+1,x[i]);
 	}
		int temp = snrm2_int32(N,x,1);
  	//printf("\n");
  	//printf(" The 2-norm of X is %d\n", snrm2_int32(N,x,1));
/*Compute the euclidean norm of a row or column of a matrix:*/
  	for(i=0;i<N;i++)
  	{
    		for(j=0;j<N;j++)
    		{
      			a[i+j*LDA] =(int32_t)(i+1 + j+1);
    		}
  	}
     temp = snrm2_int32(N, a+1+0*LDA, LDA);
		 temp = snrm2_int32(N,a+0+1*LDA,1);
		 temp = temp;
  	//printf("\n");
  	//printf("The 2-norm of row 2 of A is %d\n", snrm2_int32(N, a+1+0*LDA, LDA));

  	//printf("\n");
  	//printf(" The 2-norm of column 2 of A is %d\n" ,snrm2_int32(N,a+0+1*LDA,1));

  	return;
	# undef N
	# undef LDA
}

void test_sscal_int32( )
{
	# define N 100

  	int32_t da;
  	int32_t i;
  	int32_t x[N];

  	for(i=0;i<N;i++)
  	{
    		x[i] =(int32_t)(i+1);
 	}

  	//printf("\n");
  	//printf("test_SSCAL\n");
  	//printf("SSCAL multiplies a vector by a scalar.\n");
  	//printf("\n");
  	//printf(" X =\n");
  	//printf("\n");
  	for(i=0;i<N;i++)
  	{
    		//printf(" %6d  %14d\n",i+1, x[i]);
  	}

  	da = 5;
  	sscal_int32(N,da,x,1);
  	//printf("\n");
  	//printf(" SSCAL(N, %d, X, 1 )\n", da);
  	//printf("\n");
  	for(i=0;i<N;i++)
  	{
    		//printf("%6d  %14d\n", i+1, x[i]);
  	}

  	for(i=0; i<N; i++)
  	{
    		x[i] = (int32_t)(i+1);
  	}

  	da = -2;
  	sscal_int32(20, da, x, 2);
  	//printf("\n");
  	//printf(" SSCAL (20, %d, X, 2 )\n", da);
  	//printf("\n");
  	for(i=0;i<N;i++)
  	{
    		//printf("%6d  %14d\n", i+1, x[i]);
 	 }

  return;
# undef N
}

void test_sswap_int32( )
{
	  # define N 100

	  int32_t i;
	  int32_t x[N];
	  int32_t y[N];

	  for(i=0;i<N;i++)
	  {
	    x[i] =(int32_t)(i+1);
	  }

	  for(i=0;i <N;i++)
	  {
	    y[i] = (int32_t)(100 *(i+1));
	  }

	  //printf("\n");
	  //printf("test_SSWAP\n");
	  //printf("SSWAP swaps two vectors.\n");
	  //printf("\n");
	  //printf("X and Y:\n");
	  //printf("\n");
	  for(i = 0;i<N;i++)
	  {
	    //printf("%6d  %14d  %14d\n",i+1, x[i], y[i] );
	  }

	  sswap_int32(N,x,1,y,1);
	  //printf("\n");
	  //printf(" SSWAP ( N, X, 1, Y, 1 )\n");
	  //printf("\n");
	  //printf(" X and Y:\n");
	  //printf("\n");
	  for(i=0;i< N;i++)
	  {
	    //printf ( " %6d %14d  %14d\n", i+1,x[i],y[i] );
	  }

	  for(i=0;i<N;i++)
	  {
	    x[i] = (int32_t)(i + 1);
	  }

	  for(i=0;i<N;i++)
	  {
	    y[i] = ( int32_t) (100 * (i + 1));
	  }

	  sswap_int32( 50, x, 1, y, 1 );
	  //printf("\n");
	  //printf(" SSWAP ( 2, X, 1, Y, 1 )\n");

	  //printf( "\n" );
	  //printf( " X and Y:\n" );
	  //printf( "\n" );
	  for(i=0;i<N;i++)
	  {
	    //printf ( "  %6d  %14d  %14d\n", i+1, x[i], y[i]);
	  }

	  return;
	# undef N
}

void test_scnrm2_int32( )
{
	# define N 5

  	int32_t i;
  	int32_t incx;
  	int32_t norm;
  	float complex x[N] = {2.0 - 1.0 * I,-4.0 - 2.0 * I,3.0 + 1.0 * I, 2.0 + 2.0 * I, -1.0 - 1.0 * I };

  	//printf("\n");
  	//printf("test_scnrm2\n");
  	//printf(" SCNRM2 returns the Euclidean norm of a complex vector.\n");

  	//printf("\n");
  	//printf("The vector X:\n");
  	//printf("\n");
  	for(i=0;i<N;i++)
  	{
    		//printf("%6d  %6f  %6f\n",i, creal (x[i]), cimag(x[i]));
  	}

  	incx = 1;
  	norm = scnrm2_int32(N, x, incx);
    int temp = norm;
  	//printf ( "\n" );
  	//printf ( "  The euclidean norm of X is %d\n", norm );

  	return;
	# undef N
}


void test_sdsdot_int32()
{
	# define N 10
	# define LDA 10
	# define LDB 7
	# define LDC 6

  	int32_t a[LDA*LDA];
  	int32_t b[LDB*LDB];
  	int32_t c[LDC*LDC];
  	int32_t i;
  	int32_t j;
  	int32_t sum1;
  	int32_t x[N];
  	int32_t y[N];
  	int32_t sb=2;

  	//printf("\n");
  	//printf("test_SDSDOT\n");
  	//printf(" SDSDOT computes the inner product of two vectors with extended prescision accumulation\n" );
  	//printf("\n");

  	for(i=0;i<N;i++)
  	{
    		x[i] = (int32_t)(i + 1);
  	}

  	for(i=0;i<N;i++)
  	{
    		y[i] = -(int32_t)(i+1);
  	}
 	for(i=0;i<N;i++)
  	{
    		for(j=0;j<N;j++)
    		{
      			a[i+j*LDA] = (int32_t)(i+1 + j+1);
    		}
  	}

  	for(i=0;i<N;i++)
  	{
    		for(j=0;j<N;j++)
   		{
      			b[i+j*LDB] = (int32_t)((i + 1) - (j + 1));
    		}
  	}

	sum1 = sdsdot_int32( N,sb, x, 1, y, 1 );
	int temp = sum1;
	//printf("\n");
  	//printf("  scalar  added to the Product of x and y is %d\n", sum1);
  }


