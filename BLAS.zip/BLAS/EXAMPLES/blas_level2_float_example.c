/*******************************************************************
BLAS: Basic Linear Algebra Subprograms
Level-2:mateix -vector operations
datatype:Float
version-1.0
*********************************************************************/
#include<stdio.h>
#include<stdlib.h>
#include "blas_level2_float.h"
#include "blas_basic_funs.h"
int main ( );

void test_sspmv();
void test_sgbmv();
void test_ssymv();
void test_ssbmv();
void test_sgemv();
void test_strmv();
void test_sger();
int main()
{
  
  //printf ( "BlAS lEVEl-2 - float data type:\n" );
  //printf ( "  C version\n" );
  //printf ( "  test the BlAS level-2 library.\n" );
  test_sspmv();
  test_sgbmv();
  test_ssymv();
  test_ssbmv();
  test_sgemv();
	test_strmv();
  test_sger();
   return 0;
}
/**************************************************************************
SSPMV:symmetric packed matrix vector multiply, Y = alpha * A * X + beta * Y
***************************************************************************/
void test_sspmv()
{
	//void sspmv(char uplo, int n, float alpha,float  ap[],float  x[],int incx,float  beta,float  y[],int incy);
	char uplo = 'u';
	float alpha = 1.0;;
	int incx = -2;
  float beta =2.0;
  int incy =	1;	
	int h,i,j,n=3;
        float A[3][3]={{8.0,4.0,2.0},{4.0,6.0,7.0},{2.0,7.0,3.0}};
	//printf("TEST_sspmv \n\n\n");
        //printf("sspmv performs Y = alpha * A * X + beta * Y:\n\n");
        
        //printf("Matrix A is:\n");
        for(i=0;i<n;i++){
        	for(j=0;j<n;j++){
                 //printf("%.1f " ,A[i][j]);
		}
    	      //printf("\n");
	}
        //printf("\n");
	float ap[]={8.0,4.0,6.0,2.0,7.0,3.0};   //
	
	//printf("sspmv performs Y = alpha * A * X + beta * Y:\n\n");
	//printf(" AP vlaues is(passing lower values or upper values of a matrix A):\n");
	for(i=0;i<6;i++);
	//printf("%.1f ",ap[i]);
        //printf("\n\n");

	
        

	float x[]={4.0,0,2.0,0,1.0};
        //printf("vector X is:\n");
        for(i=0;i<5;i++);
        //printf("%.1f\n",x[i]);
	 //printf("\n\n");
       
   	float y[]={6.0,5.0,4.0};
        
          //printf("vector Y is:\n");
        for(i=0;i<3;i++);
        //printf("%.1f\n",y[i]);
	 //printf("\n\n");
		//void sspmv(char uplo, int n, float alpha,float  ap[],float  x[],int incx,float  beta,float  y[],int incy);
   	//printf("sspmv('uplo',3,1.0,ap,x,-2,2.0,y,1):\n\n");
        sspmv(uplo,n,alpha,ap,x,incx,beta,y,incy);
	//printf("Result:\n");
        //printf("Y = alpha * A * X + beta * Y:\n");
        for(h=0;h<3;h++);
		//printf("%.1f \n",y[h]);
		//printf("\n\n");
	
}
/**************************************************************************
SSYMV:symmetric matrix-vector multiply Y = alpha * A * X + beta * Y
***************************************************************************/
void test_ssymv()
{
	int h,i,j;
	float a[3][3]={{8,4,2},{4,6,7},{2,7,3}};
	//printf("tESt_ssymv \n\n\n");
	 //printf("ssymv performs Y = alpha * A * X + beta * Y:\n\n");
        //printf("Matrix A is:\n");
        for(i=0;i<3;i++){
        	for(j=0;j<3;j++){
                 //printf("%.1f " ,a[i][j]);
		}
    	      //printf("\n");
	}
        //printf("\n");
	 
	
	//printf("ssymv performs Y = alpha * A * X + beta * Y:\n\n");
	float x[]={4.0,0,2.0,0,1.0}, y[]={6.0,5.0,4.0};
        //printf("vector X is:\n");
        for(i=0;i<3;i++);
        //printf("%.1f\n",x[i]);
	 //printf("\n\n");
       
   
        
          //printf("vector Y is:\n");
        for(i=0;i<3;i++);
        //printf("%.1f\n",y[i]);
	 //printf("\n\n");
   	//printf("ssymv('u',3,1.0,a,4,x,-2,2.0,y,1):\n\n");
        
	//printf("Result:\n");
        //printf("Y = alpha * A * X + beta * Y:\n");
	
	ssymv('u',3,1.0,a,4,x,-2,2.0,y,1);
	for(h=0;h<3;h++);
		//printf("%.1f \n",y[h]);
		//printf("\n\n");
	
	
}
/**************************************************************************
SGBMV:banded matrix-vector multiply Y = alpha * A * X + beta * Y
***************************************************************************/
void test_sgbmv()
{
	int h,i,j;
	int a_rows = 5;
	int a_cols = 4; 
	float a[][4]={{0.0,0.0,1.0,2.0},
		      {0.0,1.0,2.0,3.0},
		      {1.0,2.0,3.0,4.0},
		      {2.0,3.0,4.0,5.0},
		      {3.0,4.0,5.0,0.0},
		      {4.0,5.0,0.0,0.0},
		      {0.0,0.0,0.0,0.0},
		      {0.0,0.0,0.0,0.0}};  

  	//printf("tESt_sgbmv \n\n\n");
        //printf("sgbmv performs Y = alpha * A * X + beta * Y:\n\n");
        //printf("Matrix A is:\n");
        for(i=0;i<8;i++){
        	for(j=0;j<4;j++){
                 //printf("%.1f " ,a[i][j]);
		}
    	      //printf("\n");
	}
        //printf("\n");
	 
	
	//printf("sgbmv performs Y = alpha * A * X + beta * Y:\n\n");
	int x_size = 4;
	int y_size = 10;
	float x[]={1.0,2.0,3.0,4.0}, y[]={1.0,0.0,2.0,0.0,3.0,0.0,4.0,0.0,5.0,0.0};
     
   	//printf("sgbmv('n',5,4,3,2,2,a,8,x,1,10,y,2):\n\n");
        
	//printf("Result:\n");
        //printf("Y = alpha * A * X + beta * Y:\n");
	
	int ml = 3;
	int mu = 2;
	float alpha = 2.0;
	int lda = 8;
	int incx = 1;
	float beta = 10.0;
	int incy = 2;
	sgbmv('n',a_rows,a_cols,ml,mu,alpha,a,lda,x,incx,beta,y,incy);
	
	for(h=0;h<y_size;h++);
		//printf("%.1f \n",y[h]);
		//printf("\n\n");
		
		
	
	
}
/**************************************************************************
SSBMV:symmetric banded  matrix-vector multiply Y = alpha * A * X + beta * Y
***************************************************************************/

void test_ssbmv()
{
	
	char uplo = 'u';
	int n = 7;
	int k = 3;
	float  alpha = 2.0;
	int lda = 5;
	int incx = 1;
	float beta = 10.0;
	int incy = 2;
	int h,i,j;
	float a[][7]={{0.0,0.0,0.0,1.0,2.0,3.0,4.0},
			{0.0,0.0,1.0,2.0,3.0,4.0,5.0},
			{0.0,1.0,2.0,3.0,4.0,5.0,6.0},
			{1.0,2.0,3.0,4.0,5.0,6.0,7.0},
			{0.0,0.0,0.0,0.0,0.0,0.0,0.0}};
	//printf("tESt_ssbmv \n\n\n");
	//printf("ssbmv performs Y = alpha * A * X + beta * Y:\n\n");
        //printf("Matrix A is:\n");
        for(i=0;i<5;i++){
        	for(j=0;j<7;j++){
                 //printf("%.1f " ,a[i][j]);
		}
    	      //printf("\n");
	}
        //printf("\n");
	 
	
	//printf("ssbmv performs Y = alpha * A * X + beta * Y:\n\n");
	float x[]={1.0,2.0,3.0,4.0,5.0,6.0,7.0}, y[]={1.0,0,2.0,0,3.0,0,4.0,0,5.0,0,6.0,0,7.0};
        //printf("vector X is:\n");
        for(i=0;i<7;i++);
        //printf("%.1f\n",x[i]);
	//printf("\n\n");
        //printf("vector Y is:\n");
        for(i=0;i<13;i++);
        //printf("%.1f\n",y[i]);
	//printf("\n\n");
   	//printf("ssbmv('u',7,3,2.0,a,5,x,1,10.0,y,2):\n\n");
        
	//printf("Result:\n");
        //printf("Y = alpha * A * X + beta * Y:\n");
                       
	
	ssbmv(uplo,n,k,alpha,a,lda,x,incx,beta,y,incy);
	for(h=0;h<14;h++);
		//printf("%.1f \n",y[h]);
		
	
	
}
/**************************************************************************
SGEMV: matrix-vector multiply Y = alpha * A * X + beta * Y
***************************************************************************/
void test_sgemv()
{
	//void sgemv(char trans,int m,int n,float alpha,float a[][3],int lda,float x[],int incx,float beta,float y[],int incy);
		//sgemv('n',4,3,1.0,a,10,x,1,1.0,y,2);
	char trans = 'n';
	int m = 4;
	int n = 3;
	float alpha = 1.0;
	int lda = 10;
	int incx = 1;
	float beta=1.0;
	int incy =  2;
		
        int h,i,j;
	float a[10][3]={{1.0,2.0,3.0},
                        {2.0,2.0,4.0},
			{3.0,2.0,2.0},
			{4.0,2.0,1.0},     
			{0.0,0.0,0.0},
			{0.0,0.0,0.0},
                        {0.0,0.0,0.0},
                        {0.0,0.0,0.0},
                        {0.0,0.0,0.0},
                        {0.0,0.0,0.0}};
	 //printf("sgemv performs Y = alpha * A * X + beta * Y:\n\n");
        //printf("Matrix A is:\n");
        for(i=0;i<10;i++){
        	for(j=0;j<3;j++){
                 //printf("%.1f " ,a[i][j]);
		}
    	      //printf("\n");
	}
        //printf("\n");
	 
	
	//printf("sgemv performs Y = alpha * A * X + beta * Y:\n\n");
	float x[]={3.0,2.0,1.0}, y[]={4.0,0,5.0,0,2.0,0,3.0};
        //printf("vector X is:\n");
        for(i=0;i<3;i++);
        //printf("%.1f\n",x[i]);
	 //printf("\n\n");
       
   
        
          //printf("vector Y is:\n");
        for(i=0;i<7;i++);
        //printf("%.1f\n",y[i]);
	 //printf("\n\n");
   	//printf("sgemv('N',4,3,1.0,a,10,x,1,1.0,y,2):\n\n");
        
	//printf("Result:\n");
        //printf("Y = alpha * A * X + beta * Y:\n");
	
	sgemv(trans,m,n,alpha,a,lda,x,incx,beta,y,incy);
	for(h=0;h<7;h++);
		//printf("%.1f \n",y[h]);
	
	
}
/******************************************************************************/

void test_sger()

/******************************************************************************/

{
  float *a;
  float alpha;
  int i;
  int incx;
  int incy;
  int lda;
  int m;
  int n;
  char trans;
  float *x;
  float *y;

 // printf ( "\n" );
 // printf ( "SGER\n" );
 // printf ( "  For a general matrix A,\n" );
 // printf ( "  sger computes A := A + alpha * x * y'\n" );

  m = 5;
  n = 4;
  alpha = 2.0;
  trans = 'N';
  lda = m;
  a = r8mat_test ( trans, lda, m, n );

  x = ( float * ) malloc ( m * sizeof ( float ) );
  for ( i = 0; i < m; i++ )
  {
    x[i] = ( float ) ( i + 1 );
  }
  incx = 1;

  y = ( float * ) malloc ( n * sizeof ( float ) );
  for ( i = 0; i < n; i++ )
  {
    y[i] = ( float ) ( 10 * ( i + 1 ) );
  }
  incy = 1;

  r8mat_print ( m, n, a, "  Matrix A:" );
  r8vec_print ( m, x, "  Vector X:" );
  r8vec_print ( n, y, "  Vector Y:" );

  sger ( m, n, alpha, x, incx, y, incy, a, lda );

  r8mat_print ( m, n, a, "  Result A = A + alpha * x * y" );

  free ( a );
  free ( x );
  free ( y );

  return;
}
/******************************************************************************/

void test_strmv( )

/******************************************************************************/

{
  float *a;
  char diag;
  int i;
  int incx;
  int j;
  int lda = 5;
  int m = 5;
  int n = 5;
  int test;
  char trans;
  char uplo;
  float *x;

  a = ( float * ) malloc ( lda * n * sizeof ( float ) );
  x = ( float * ) malloc ( n * sizeof ( float ) );

 // printf ( "\n" );
 // printf ( "STRMV\n" );
 // printf ( "  For a triangular matrix A,\n" );
 // printf ( "  strmv computes y := A * x or y := A' * x\n" );

  for ( test = 1; test <= 2; test++ )
  {
    uplo = 'U';

    if ( test == 1 )
    {
      trans = 'N';
    }
    else
    {
      trans = 'T';
    }

    diag = 'N';

    for ( j = 0; j < n; j++ )
    {
      for ( i = 0; i <= j; i++ )
      {
        a[i+j*m] = ( float ) ( i + j + 2 );
      }
      for ( i = j + 1; i < m; i++ )
      {
        a[i+j*m] = 0.0;
      }
    }

    incx = 1;
    for ( i = 0; i < n; i++ )
    {
      x[i] = ( float ) ( i + 1 );
    }

    strmv ( uplo, trans, diag, n, a, lda, x, incx );

    if ( trans == 'N' )
    {
      r8vec_print ( n, x, "  Result y = A * x" );
    }
    else
    {
      r8vec_print ( n, x, "  Result y = A' * x" );
    }
  }

  free ( a );
  free ( x );

  return;
}


