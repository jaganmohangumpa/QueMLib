#include<stdio.h>
#include<stdint.h>
#include "blas_level2_int_16.h"
int main ( );

void test_sspmv();
void test_sgbmv();
void test_ssymv();
void test_ssbmv();
void test_sgemv();
int main()
{
  
  //printf ( "BlAS lEVEl-2 :\n" );
  //printf ( "  C version\n" );
  //printf ( "  test the BlAS level-2 library.\n" );
  test_sspmv();
  test_sgbmv();
  test_ssymv();
  test_ssbmv();
  test_sgemv();
  //printf ( "\n" );
  //printf ( "end of execution.\n" );
  //printf ( "\n" );
 

  return 0;
}

void test_sspmv()
{
	int16_t h,i,j,n=3;
        int16_t A[3][3]={{8,4,2},{4,6,7},{2,7,3}};
	//printf("tESt_sspmv \n\n\n");
        //printf("sspmv performs Y = alpha * A * X + beta * Y:\n\n");
        
        //printf("Matrix A is:\n");
        for(i=0;i<n;i++){
        	for(j=0;j<n;j++){
                 //printf("%d " ,A[i][j]);
		}
    	      //printf("\n");
	}
        //printf("\n");
	int16_t ap[]={8,4,6,2,7,3};   //
	//printf("*******************************************************************\n");
	//printf("1).sspmv performs Y = alpha * A * X + beta * Y:\n\n");
	//printf("*******************************************************************\n");
	//printf(" AP vlaues is(passing lower values or upper values of a matrix A):\n");
	for(i=0;i<6;i++);
	//printf("%d ",ap[i]);
        //printf("\n\n");

	
        

	int16_t x[]={4,0,2,0,1};
        //printf("vector X is:\n");
        for(i=0;i<5;i++);
        //printf("%d\n",x[i]);
	 //printf("\n\n");
       
   	int16_t y[]={6,5,4};
        
          //printf("vector Y is:\n");
        for(i=0;i<3;i++);
        //printf("%d\n",y[i]);
	 //printf("\n\n");
   	//printf("sspmv('u',3,1,ap,x,-2,2,y,1):\n\n");
        sspmv('u',3,1,ap,x,-2,2,y,1);
	//printf("*******************************************************************\n");
	//printf("Result:\n");
	//printf("*******************************************************************\n");
        //printf("Y = alpha * A * X + beta * Y:\n");
        for(h=0;h<3;h++);
		//printf("%d \n",y[h]);
		//printf("\n\n");
	
}
void test_ssymv()
{
	int16_t h,i,j;
	int16_t a[3][3]={{8,4,2},{4,6,7},{2,7,3}};
	//printf("tESt_ssymv \n\n\n");
	//printf("*******************************************************************\n");
	 //printf("2).ssymv performs Y = alpha * A * X + beta * Y:\n\n");
	//printf("*******************************************************************\n");
        //printf("Matrix A is:\n");
        for(i=0;i<3;i++){
        	for(j=0;j<3;j++){
                 //printf("%d " ,a[i][j]);
		}
    	      //printf("\n");
	}
        //printf("\n");
	 
	
	//printf("ssymv performs Y = alpha * A * X + beta * Y:\n\n");
	int16_t x[]={4,0,2,0,1}, y[]={6,5,4};
        //printf("vector X is:\n");
        for(i=0;i<3;i++)
        //printf("%d\n",x[i]);
	 //printf("\n\n");
       
   
        
          //printf("vector Y is:\n");
        for(i=0;i<3;i++);
        //printf("%d\n",y[i]);
	 //printf("\n\n");
   	//printf("ssymv('u',3,1,a,4,x,-2,2,y,1):\n\n");
	//printf("*******************************************************************\n");
        //printf("Result:\n");
	//printf("*******************************************************************\n");
        //printf("Y = alpha * A * X + beta * Y:\n");
	
	ssymv('u',3,1,a,4,x,-2,2,y,1);
	for(h=0;h<3;h++);
		//printf("%d \n",y[h]);
		//printf("\n\n");
	
	
}
void test_sgbmv()
{
	int16_t h,i,j;
	int16_t a_rows = 5;
	int16_t a_cols = 4; 
	int16_t a[][4]={
			{  0 ,   0,   1,  2 },
			{  0 ,  1,  2,  3 },
			{ 1,  2, 3,  4},
			{ 2,  3,  4,  5 },
			{ 3,  4,  5,   0  },
			{ 4,  5,   0 ,   0  },
			{  0 ,   0 ,   0 ,   0  },
			{  0 ,   0 ,   0 ,   0  }
       		   };
       
  	//printf("tESt_sgbmv \n\n\n");
	//printf("*******************************************************************\n");
        //printf("sgbmv performs Y = alpha * A * X + beta * Y:\n\n");
	//printf("*******************************************************************\n");
     
	int16_t x_size = 4;
	int16_t y_size = 10;

	int16_t x[]={1,2,3,4,}, y[]={1,0,2,0,3,0,4,0,5,0};
     
   	//printf("3).sgbmv('n',5,4,3,2,2,a,8,x,1,10,y,2):\n\n");
        //printf("*******************************************************************\n");
	//printf("Result:\n");
	//printf("*******************************************************************\n");
        //printf("Y = alpha * A * X + beta * Y:\n");
	
	int16_t ml = 3;
	int16_t mu = 2;
	int16_t alpha = 2;
	int16_t lda = 8;
	int16_t incx = 1;
	int16_t beta = 10;
	int16_t incy = 2;
	sgbmv('n',a_rows,a_cols,ml,mu,alpha,a,lda,x,incx,beta,y,incy);
	
	for(h=0;h<y_size;h++);
		//printf("%d \n",y[h]);
		//printf("\n\n");
		
	
	
}

void test_ssbmv()
{
	int16_t h,i,j;
	int16_t a[][7]={{0,0,0,1,2,3,4},
			{0,0,1,2,3,4,5},
			{0,1,2,3,4,5,6},
			{1,2,3,4,5,6,7},
			{0,0,0,0,0,0,0}};
	//printf("tESt_ssbmv \n\n\n");
	//printf("*******************************************************************\n");
	//printf("4).ssbmv performs Y = alpha * A * X + beta * Y:\n\n");
	//printf("*******************************************************************\n");
        //printf("Matrix A is:\n");
        for(i=0;i<5;i++){
        	for(j=0;j<7;j++){
                 //printf("%d " ,a[i][j]);
		}
    	      //printf("\n");
	}
        //printf("\n");
	 
	
	//printf("ssbmv performs Y = alpha * A * X + beta * Y:\n\n");
	int16_t x[]={1,2,3,4,5,6,7}, y[]={1,0,2,0,3,0,4,0,5,0,6,0,7};
        //printf("vector X is:\n");
        for(i=0;i<7;i++)
        //printf("%d\n",x[i]);
	//printf("\n\n");
        //printf("vector Y is:\n");
        for(i=0;i<13;i++);
        //printf("%d\n",y[i]);
	//printf("\n\n");
   	//printf("ssbmv('u',7,3,2,a,5,x,1,10,y,2):\n\n");

        //printf("*******************************************************************\n");
	//printf("Result:\n");
	//printf("*******************************************************************\n");
        //printf("Y = alpha * A * X + beta * Y:\n");
                       
	
	ssbmv('u',7,3,2,a,5,x,1,10,y,2);
	for(h=0;h<14;h++);
		//printf("%d \n",y[h]);
		
	
	
}
void test_sgemv()
{
        int16_t h,i,j;
	int16_t a[10][3]={{1,2,3},
                        {2,2,4},
			{3,2,2},
			{4,2,1},     
			{0,0,0},
			{0,0,0},
                        {0,0,0},
                        {0,0,0},
                        {0,0,0},
                        {0,0,0}};
	 //printf("sgemv performs Y = alpha * A * X + beta * Y:\n\n");
        //printf("Matrix A is:\n");
        for(i=0;i<10;i++){
        	for(j=0;j<3;j++){
                 //printf("%d " ,a[i][j]);
		}
    	      //printf("\n");
	}
        //printf("\n");
	 
	//printf("*******************************************************************\n");
	//printf("5).sgemv performs Y = alpha * A * X + beta * Y:\n\n");
	//printf("*******************************************************************\n");
	int16_t x[]={3,2,1}, y[]={4,0,5,0,2,0,3};
        //printf("vector X is:\n");
        for(i=0;i<3;i++);
        //printf("%.1d\n",x[i]);
	 //printf("\n\n");
       
   
        
          //printf("vector Y is:\n");
        for(i=0;i<7;i++);
        //printf("%.1d\n",y[i]);
	 //printf("\n\n");
   	//printf("sgemv('N',4,3,1,a,10,x,1,1,y,2):\n\n");
        //printf("*******************************************************************\n");
	//printf("Result:\n");
	//printf("*******************************************************************\n");
        //printf("Y = alpha * A * X + beta * Y:\n");
	
	sgemv('n',4,3,1,a,10,x,1,1,y,2);
	for(h=0;h<7;h++);
		//printf("%d \n",y[h]);
	
	
	
}
